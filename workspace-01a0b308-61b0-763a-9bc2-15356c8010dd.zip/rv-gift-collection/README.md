# RV Gift Collection

Premium, India-first personalized gifting e-commerce — built with **Next.js App Router, React, TypeScript, Tailwind CSS** on a **Supabase** (PostgreSQL + Auth + Storage) architecture, with **hosted payment checkout** (Razorpay-compatible flow).

> **Make Every Gift Personal.** — personalized mugs, frames, cushions, keychains, lamps, stationery and gift hampers.

---

## Quick start

```bash
cp .env.example .env.local      # placeholders only — fill with real values for production
npm install
npm run dev                     # http://localhost:3000
```

### Demo mode vs. production mode

With placeholder credentials (the default), the app runs in a **clearly-labelled demo mode**:

| Concern        | Demo mode                              | Production |
|----------------|----------------------------------------|------------|
| Data           | In-memory store with identical shapes  | Supabase PostgreSQL (migrations in `supabase/migrations`) |
| Auth           | Demo sessions (cookie)                 | Supabase Auth + `staff_roles` + MFA |
| Payments       | Simulated hosted checkout that drives the **real signed-webhook code path** | Razorpay hosted checkout + verified webhooks |
| Uploads        | Server re-validates and stores in memory (private) | Private `customer-uploads` bucket + signed URLs |
| Jobs           | In-process queue with leases/backoff/idempotency | `outbox_events` + `job_attempts` worker (`FOR UPDATE SKIP LOCKED`) |

Every security-critical path (pricing, reservation, webhook verification, idempotency, upload validation, authorization) is implemented for real and shared between both modes.

---

## The complete flow (testable end to end)

Home → Browse (`/collections`) → Product → Variant → PIN check → Personalization → Photo upload → Preview → **Approval** → Cart → Checkout → Quote → Hosted payment → **Verified confirmation** → Production → Dispatch → Tracking.

Try these edge cases in the demo:

- **Invalid upload** — wrong type / >10 MB / undersized photo / non-image bytes → `UPLOAD_REJECTED`
- **Out-of-stock** — the 16" Photo Cushion variant has 2 units; add 3 and checkout fails with `OUT_OF_STOCK`
- **Expired quote** — quotes expire in 10 minutes; ordering then returns `QUOTE_EXPIRED` with a refreshed quote
- **Invalid coupon** — `EXPIRED50` is seeded as expired/limit-reached; valid: `RVWELCOME`, `FESTIVE10`
- **Unsupported PIN** — PINs starting `799` or `110099` are blocked in Admin → Delivery
- **Duplicate webhook** — the provider `event_id` is recorded once; duplicates are 200 no-ops
- **Payment interruption** — “Abandon payment” on the hosted page → status page reports pending/abandoned, never confirms
- **Guest order security** — `/order/RV-XXXX-XXXX` without its secret token → 403
- **Cross-user access** — account orders are filtered server-side; tokens never leak across orders
- **Admin authorization** — every `/api/admin/*` route re-checks the staff session server-side
- **Concurrent last-item** — reservation is an atomic check-and-hold; only one checkout can win the final unit

---

## Architecture

```
src/
├── app/                    # App Router pages + /api route handlers
│   ├── api/
│   │   ├── products/            # public catalogue (published only)
│   │   ├── delivery/check/      # PIN code availability engine
│   │   ├── uploads/             # authorise → complete → signed staff access
│   │   ├── checkout/quote/      # server-authoritative pricing (paise)
│   │   ├── orders/              # create (quote-driven) + secure lookup
│   │   ├── payments/            # create, status, demo provider bridge
│   │   ├── webhooks/payment/    # signature + amount + idempotency checks
│   │   ├── auth/                # demo auth (Supabase Auth in production)
│   │   ├── account/             # owner-scoped orders & addresses
│   │   ├── support/             # case references
│   │   └── admin/               # staff-only: orders, refunds, products,
│   │                            # inventory, coupons, delivery rules,
│   │                            # templates, jobs, tickets, reports, audit
│   ├── admin/              # 15-section protected dashboard
│   ├── product/[slug]/     # PDP: gallery, variants, PIN check, studio
│   ├── occasion/[slug]/    # SEO landing pages
│   ├── order/[reference]/  # token-protected confirmation + tracking
│   └── …                   # cart, checkout, account, policies, etc.
├── components/             # design-system UI, personalization studio,
│                           # preview canvas, cart/checkout clients, admin
└── lib/
    ├── store.ts            # demo store (shape-matched to Supabase tables)
    ├── pricing.ts          # quote engine — integer paise, server-only totals
    ├── inventory.ts        # atomic reservations with expiry
    ├── delivery.ts         # zones, business days, cut-off, capacity
    ├── coupons.ts          # server-side coupon enforcement
    ├── orders.ts           # snapshots, references, secure access
    ├── payments.ts         # webhook verification + idempotent confirmation
    ├── uploads.ts          # magic-byte/dimension validation, signed media
    ├── jobs.ts             # lease/backoff/idempotency job queue
    └── supabase.ts         # browser (anon) vs. server (service) clients
supabase/migrations/
├── 0001_schema.sql         # all 28 tables, functions, UUIDs, paise money
└── 0002_rls_storage.sql    # RLS on every table + 4 storage buckets
```

### Money & pricing

All money is **integer paise**, computed **only on the server**. The browser sends line references; the server recomputes subtotal, coupon discount, GST-inclusive split, delivery fee and total. Quotes expire (10 min); order creation re-validates and rejects stale totals with `QUOTE_EXPIRED` / `PRICE_CHANGED`, forcing the customer to review the updated amount.

### Payments

Cart → Quote → Create order (reserve stock) → Create payment → **Hosted checkout** → Provider webhook → Verify signature, provider order id, payment id, amount, currency, captured state, unique event id → Confirm order → Fulfilment. Browser redirects are **never** proof of payment.

### Uploads (customer photos)

JPEG/PNG only · ≤10 MB · file-signature validation · image decode · pixel-dimension validation against the product template · file-count validation · canvas re-encode strips EXIF/metadata · stored privately · staff access only via short-lived signed URLs. No SVG or document uploads.

### Personalization

Per-product templates define required fields, character limits, photo count, print dimensions, layout and preview configuration. The 2D preview shows the **exact crop** the customer approves (no silent auto-crop), with explicit “approximate preview” labelling. The **Review Your Personalization** step requires an explicit approval checkbox before Add to Cart; templates are versioned and paid orders keep their approved version.

---

## Security model

- Supabase **RLS on every table** (ownership checks, staff roles, no guest order leakage)
- Browser is untrusted: prices, roles, file metadata and payment status are always re-verified server-side
- Service-role keys and payment secrets are **server-only** (never `NEXT_PUBLIC_*`)
- Private customer media; opaque object paths; short-lived signed URLs
- Admin MFA + protected staff roles in production; every admin mutation is audited
- Safe error codes only (`OUT_OF_STOCK`, `QUOTE_EXPIRED`, `UPLOAD_REJECTED`, `PAYMENT_PENDING`, …) — no stack traces to customers

## Content policy

No invented testimonials, reviews, sales figures, bestseller rankings, delivery guarantees, supplier info, legal details or contact details. Owner-supplied slots are registered as placeholders (Admin → Content).

## Production checklist

1. Create a Supabase project; run both migrations; enable email auth + MFA for staff.
2. Fill `.env.local` with real values (Supabase keys, Razorpay keys + webhook secret, email provider).
3. Configure Razorpay webhook → `POST /api/webhooks/payment` with the shared secret.
4. Deploy the background worker that leases from `job_attempts` (email, image validation, reservation expiry, reconciliation, courier sync, upload retention).
5. Seed catalogue from Admin → Catalogue; upload photography to the `product-images` bucket.
