import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST() {
  const id = cookies().get('rv_session')?.value;
  if (id) store.sessions.delete(id);
  const res = NextResponse.json({ ok: true });
  res.cookies.set('rv_session', '', { httpOnly: true, path: '/', maxAge: 0 });
  return res;
}
