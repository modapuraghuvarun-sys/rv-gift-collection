import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { getSession, store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/auth/me — current session + profile. */
export async function GET() {
  const session = getSession(cookies().get('rv_session')?.value);
  if (!session) return NextResponse.json({ authenticated: false });
  if (session.role === 'staff') {
    return NextResponse.json({ authenticated: true, role: 'staff', name: 'Demo Staff' });
  }
  const profile = store.profiles.find((p) => p.id === session.userId);
  if (!profile) return NextResponse.json({ authenticated: false });
  return NextResponse.json({
    authenticated: true,
    role: 'customer',
    profile: { id: profile.id, name: profile.name, email: profile.email, phone: profile.phone, addresses: profile.addresses },
  });
}
