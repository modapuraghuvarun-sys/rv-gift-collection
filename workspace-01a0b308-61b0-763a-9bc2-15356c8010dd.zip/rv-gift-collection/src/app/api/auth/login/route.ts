import { NextRequest, NextResponse } from 'next/server';
import { createSession, store } from '@/lib/store';
import { createHash } from 'crypto';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** POST /api/auth/login — demo mode. Production: Supabase Auth. */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const { email, password } = (body ?? {}) as { email?: string; password?: string };
  const cleanEmail = String(email ?? '').trim().toLowerCase();
  const profile = store.profiles.find((p) => p.email === cleanEmail);
  const hash = createHash('sha256').update(String(password ?? '')).digest('hex');
  if (!profile || profile.passwordHash !== hash) {
    return NextResponse.json({ error: 'INVALID_CREDENTIALS', message: 'Email or password is incorrect.' }, { status: 401 });
  }
  const session = createSession('customer', profile.id);
  const res = NextResponse.json({ ok: true, profile: { id: profile.id, name: profile.name, email: profile.email } });
  res.cookies.set('rv_session', session.id, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 60 * 60 * 24 * 30 });
  return res;
}
