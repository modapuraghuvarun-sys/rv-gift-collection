import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { createSession, store } from '@/lib/store';
import { isValidEmail, isValidPhone, uid } from '@/lib/utils';
import { createHash } from 'crypto';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/auth/signup — demo credential store.
 * Production: Supabase Auth (no custom password tables), MFA available.
 */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const { name, email, phone, password } = (body ?? {}) as {
    name?: string;
    email?: string;
    phone?: string;
    password?: string;
  };
  const cleanEmail = String(email ?? '').trim().toLowerCase();
  if (!name || String(name).trim().length < 2) {
    return NextResponse.json({ error: 'VALIDATION', message: 'Please enter your name.' }, { status: 422 });
  }
  if (!isValidEmail(cleanEmail)) {
    return NextResponse.json({ error: 'VALIDATION', message: 'Please enter a valid email.' }, { status: 422 });
  }
  if (phone && !isValidPhone(String(phone))) {
    return NextResponse.json({ error: 'VALIDATION', message: 'Please enter a valid 10-digit phone number.' }, { status: 422 });
  }
  if (!password || String(password).length < 8) {
    return NextResponse.json({ error: 'VALIDATION', message: 'Password must be at least 8 characters.' }, { status: 422 });
  }
  if (store.profiles.some((p) => p.email === cleanEmail)) {
    return NextResponse.json({ error: 'EMAIL_EXISTS', message: 'An account with this email already exists. Please log in.' }, { status: 409 });
  }

  const profile = {
    id: uid('usr'),
    name: String(name).trim(),
    email: cleanEmail,
    phone: phone ? String(phone).replace(/\D/g, '') : undefined,
    passwordHash: createHash('sha256').update(String(password)).digest('hex'),
    createdAt: new Date().toISOString(),
    addresses: [],
  };
  store.profiles.push(profile);

  const session = createSession('customer', profile.id);
  const res = NextResponse.json({ ok: true, profile: { id: profile.id, name: profile.name, email: profile.email } });
  res.cookies.set('rv_session', session.id, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 60 * 60 * 24 * 30 });
  return res;
}
