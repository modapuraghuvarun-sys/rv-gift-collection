import { NextResponse } from 'next/server';
import { audit, createSession } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/auth/staff — DEMO MODE staff session only.
 *
 * Production: staff sign in with Supabase Auth, hold protected `staff_roles`
 * rows, and MFA is enforced. Browser claims of staff status are never trusted;
 * every admin route re-checks the server-side session role.
 */
export async function POST() {
  if (process.env.DEMO_STAFF_ENABLED === 'false') {
    return NextResponse.json({ error: 'DISABLED', message: 'Demo staff access is disabled.' }, { status: 403 });
  }
  const session = createSession('staff');
  audit('demo-staff', 'staff.session.started', 'Demo staff session enabled from /admin');
  const res = NextResponse.json({ ok: true });
  res.cookies.set('rv_session', session.id, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 60 * 60 * 4 });
  return res;
}
