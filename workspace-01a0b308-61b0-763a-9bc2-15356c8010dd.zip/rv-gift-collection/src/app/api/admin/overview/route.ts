import { NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/admin/overview — dashboard cards + queues (staff only). */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  const paidAwaitingAction = store.orders.filter((o) => ['CONFIRMED', 'PERSONALISATION_REVIEW'].includes(o.status)).length;
  const onHold = store.orders.filter((o) => o.status === 'CORRECTION_HOLD').length;
  const overdueProduction = store.orders.filter((o) => {
    if (!['IN_PRODUCTION', 'PERSONALISATION_REVIEW'].includes(o.status)) return false;
    const entered = [...o.history].reverse().find((h) => ['IN_PRODUCTION', 'PERSONALISATION_REVIEW'].includes(h.status));
    return entered ? Date.now() - new Date(entered.at).getTime() > 48 * 3600000 : false;
  }).length;

  let lowStock = 0;
  for (const rec of store.inventory.values()) {
    if (rec.onHand - rec.reserved <= 3) lowStock += 1;
  }

  const pendingPayments = store.payments.filter((p) => p.status === 'CREATED').length;
  const refundExceptions = store.orders.filter(
    (o) => o.status === 'CANCELLED' && o.history.some((h) => (h.note ?? '').toLowerCase().includes('refund')),
  ).length;
  const failedJobs = store.jobs.filter((j) => j.state === 'failed').length;

  return NextResponse.json({
    cards: {
      paidAwaitingAction,
      onHold,
      overdueProduction,
      lowStock,
      pendingPayments,
      refundExceptions,
      failedJobs,
    },
    recentOrders: store.orders.slice(0, 8).map((o) => ({
      id: o.id,
      reference: o.reference,
      createdAt: o.createdAt,
      status: o.status,
      total: o.total,
      buyer: o.buyer.name,
    })),
    jobs: [...store.jobs].reverse().slice(0, 20).map((j) => ({
      id: j.id,
      type: j.type,
      state: j.state,
      attempts: j.attempts,
      lastError: j.lastError,
      createdAt: j.createdAt,
    })),
  });
}
