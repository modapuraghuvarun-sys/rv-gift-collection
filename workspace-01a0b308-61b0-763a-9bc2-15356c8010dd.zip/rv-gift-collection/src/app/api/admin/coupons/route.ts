import { NextRequest, NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { audit, store } from '@/lib/store';
import type { Coupon } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/admin/coupons — list (staff only). */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });
  return NextResponse.json({ coupons: store.coupons });
}

/** POST /api/admin/coupons — create/update coupon (staff only). */
export async function POST(req: NextRequest) {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const input = (body ?? {}) as Partial<Coupon> & { code?: string };
  const code = String(input.code ?? '').trim().toUpperCase();
  if (!/^[A-Z0-9]{3,20}$/.test(code)) {
    return NextResponse.json({ error: 'VALIDATION', message: 'Coupon code must be 3–20 letters/numbers.' }, { status: 422 });
  }
  const kind = input.kind === 'percent' ? 'percent' : 'flat';
  const value = Number(input.value ?? 0);
  if (value <= 0 || (kind === 'percent' && value > 90)) {
    return NextResponse.json({ error: 'VALIDATION', message: 'Invalid discount value.' }, { status: 422 });
  }

  const existing = store.coupons.find((c) => c.code === code);
  const coupon: Coupon = {
    code,
    description: String(input.description ?? '').slice(0, 200),
    kind,
    value: kind === 'flat' ? Math.round(value) : value,
    maxDiscount: input.maxDiscount ? Math.round(Number(input.maxDiscount)) : undefined,
    minSubtotal: Math.round(Number(input.minSubtotal ?? 0)),
    startsAt: input.startsAt ? new Date(input.startsAt).toISOString() : new Date().toISOString(),
    expiresAt: input.expiresAt ? new Date(input.expiresAt).toISOString() : new Date(Date.now() + 60 * 86400000).toISOString(),
    usageLimit: Math.max(1, Math.round(Number(input.usageLimit ?? 1000))),
    perCustomerLimit: Math.max(1, Math.round(Number(input.perCustomerLimit ?? 1))),
    redeemed: existing?.redeemed ?? 0,
    active: input.active ?? true,
  };

  if (existing) {
    Object.assign(existing, coupon);
  } else {
    store.coupons.push(coupon);
  }
  audit(auth.actor, 'coupon.saved', `${code} (${kind} ${value})`);
  return NextResponse.json({ ok: true, coupon });
}
