import { NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/admin/products — all products incl. drafts/archived (staff). */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });
  return NextResponse.json({
    products: store.products.map((p) => ({
      id: p.id,
      slug: p.slug,
      name: p.name,
      category: p.category,
      status: p.status,
      featured: p.featured,
      leadTimeDays: p.leadTimeDays,
      collections: p.collections,
      personalisable: Boolean(p.personalisation),
      image: p.images[0],
      variants: p.variants.map((v) => {
        const rec = store.inventory.get(v.sku);
        return {
          ...v,
          onHand: rec?.onHand ?? 0,
          reserved: rec?.reserved ?? 0,
          availableCount: rec ? rec.onHand - rec.reserved : 0,
        };
      }),
    })),
    collections: store.collections,
  });
}
