import { NextRequest, NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { audit, store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * PATCH /api/admin/products/:id — staff-only catalogue edits
 * (status, lead time, featured, price, variant availability).
 */
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const input = (body ?? {}) as {
    status?: string;
    featured?: boolean;
    leadTimeDays?: number;
    name?: string;
    variantId?: string;
    variantPrice?: number;
    variantAvailable?: boolean;
  };

  const product = store.products.find((p) => p.id === params.id);
  if (!product) return NextResponse.json({ error: 'NOT_FOUND' }, { status: 404 });

  if (input.status && ['draft', 'published', 'archived'].includes(input.status)) {
    product.status = input.status as typeof product.status;
    audit(auth.actor, 'product.status', `${product.slug} → ${input.status}`);
  }
  if (typeof input.featured === 'boolean') product.featured = input.featured;
  if (typeof input.leadTimeDays === 'number' && input.leadTimeDays >= 0 && input.leadTimeDays <= 30) {
    product.leadTimeDays = Math.round(input.leadTimeDays);
  }
  if (typeof input.name === 'string' && input.name.trim().length >= 3) {
    product.name = input.name.trim();
  }
  if (input.variantId) {
    const variant = product.variants.find((v) => v.id === input.variantId);
    if (variant) {
      if (typeof input.variantPrice === 'number' && input.variantPrice > 0) {
        variant.price = Math.round(input.variantPrice);
        audit(auth.actor, 'variant.price', `${variant.sku} → ₹${(variant.price / 100).toFixed(2)}`);
      }
      if (typeof input.variantAvailable === 'boolean') {
        variant.available = input.variantAvailable;
        audit(auth.actor, 'variant.availability', `${variant.sku} → ${input.variantAvailable ? 'available' : 'unavailable'}`);
      }
    }
  }

  return NextResponse.json({ ok: true, product: { id: product.id, status: product.status, featured: product.featured, leadTimeDays: product.leadTimeDays } });
}
