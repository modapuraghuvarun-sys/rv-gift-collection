import { NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { store } from '@/lib/store';
import { refunds } from '@/lib/refunds';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/admin/reports — factual metrics only. No profit calculation until
 * real material/packaging/shipping/gateway costs exist (PRD §26).
 */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  const paid = store.orders.filter((o) => o.status !== 'PAYMENT_PENDING' && o.status !== 'CANCELLED');
  const paidSales = paid.reduce((a, o) => a + o.total, 0);
  const discounts = paid.reduce((a, o) => a + o.discount, 0);
  const tax = paid.reduce((a, o) => a + o.taxIncluded, 0);
  const shipping = paid.reduce((a, o) => a + o.deliveryFee, 0);
  const refundTotal = refunds.reduce((a, r) => a + r.amount, 0);

  const statusCounts = new Map<string, number>();
  for (const o of store.orders) statusCounts.set(o.status, (statusCounts.get(o.status) ?? 0) + 1);

  const fulfilled = store.orders.filter((o) => ['SHIPPED', 'DELIVERED'].includes(o.status)).length;
  const lowStock: { sku: string; available: number }[] = [];
  for (const rec of store.inventory.values()) {
    const available = rec.onHand - rec.reserved;
    if (available <= 3) lowStock.push({ sku: rec.sku, available });
  }

  return NextResponse.json({
    paidOrders: paid.length,
    paidSales,
    discounts,
    taxIncluded: tax,
    shippingCollected: shipping,
    refunds: { count: refunds.length, total: refundTotal, list: refunds },
    statusCounts: Object.fromEntries(statusCounts),
    fulfilment: { total: store.orders.length, fulfilled },
    lowStock,
    couponRedemptions: store.couponRedemptions.length,
    emailsSent: store.emails.length,
  });
}
