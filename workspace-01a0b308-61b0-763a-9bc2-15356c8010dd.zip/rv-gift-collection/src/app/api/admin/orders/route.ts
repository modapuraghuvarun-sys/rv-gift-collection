import { NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { STATUS_LABELS } from '@/lib/orders';
import { store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/admin/orders — full order list with snapshots (staff). */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });
  return NextResponse.json({
    orders: store.orders.map((o) => ({
      id: o.id,
      reference: o.reference,
      createdAt: o.createdAt,
      status: o.status,
      statusLabel: STATUS_LABELS[o.status],
      buyer: o.buyer,
      recipient: o.recipient,
      address: o.address,
      items: o.items,
      subtotal: o.subtotal,
      discount: o.discount,
      couponCode: o.couponCode,
      taxIncluded: o.taxIncluded,
      deliveryFee: o.deliveryFee,
      total: o.total,
      deliveryWindow: o.deliveryWindow,
      shipment: o.shipment ?? null,
      history: o.history,
    })),
  });
}
