import { NextRequest, NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { audit, store } from '@/lib/store';
import { enqueueJob } from '@/lib/jobs';
import { createRefund } from '@/lib/refunds';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** POST /api/admin/orders/:id/refunds — initiate refund (staff only). */
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const { amount, reason } = (body ?? {}) as { amount?: number; reason?: string };
  const order = store.orders.find((o) => o.id === params.id);
  if (!order) return NextResponse.json({ error: 'NOT_FOUND' }, { status: 404 });

  const amt = Number(amount ?? order.total);
  if (!Number.isInteger(amt) || amt <= 0 || amt > order.total) {
    return NextResponse.json({ error: 'VALIDATION', message: 'Refund amount must be between 1 and the order total (paise).' }, { status: 422 });
  }

  const refund = createRefund(order.id, amt, String(reason ?? 'Customer request').slice(0, 300), auth.actor);
  audit(auth.actor, 'refund.initiated', `Refund of ₹${(amt / 100).toFixed(2)} initiated for order ${order.reference}`);

  enqueueJob('refund_reconciliation', { refundId: refund.id }, { idempotencyKey: `refund:${refund.id}` });
  enqueueJob('send_email', {
    to: order.buyer.email,
    template: 'exception_notification',
    subject: `Refund initiated for order ${order.reference}`,
  }, { idempotencyKey: `email:refund:${refund.id}` });

  return NextResponse.json({ ok: true, refund });
}
