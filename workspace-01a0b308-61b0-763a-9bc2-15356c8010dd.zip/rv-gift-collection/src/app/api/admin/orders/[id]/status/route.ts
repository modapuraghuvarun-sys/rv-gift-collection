import { NextRequest, NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { STATUS_LABELS, updateOrderStatus } from '@/lib/orders';
import type { OrderStatus } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ALLOWED: OrderStatus[] = Object.keys(STATUS_LABELS) as OrderStatus[];

/** PATCH /api/admin/orders/:id/status — staff-only status transitions. */
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const { status, note } = (body ?? {}) as { status?: string; note?: string };
  if (!status || !ALLOWED.includes(status as OrderStatus)) {
    return NextResponse.json({ error: 'VALIDATION', message: 'Invalid status.' }, { status: 422 });
  }
  const ok = updateOrderStatus(params.id, status as OrderStatus, String(note ?? 'Updated by staff'), auth.actor);
  if (!ok) return NextResponse.json({ error: 'NOT_FOUND' }, { status: 404 });
  return NextResponse.json({ ok: true });
}
