import { NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/admin/inventory — stock, reservations, adjustments (staff). */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  const skuToProduct = new Map<string, string>();
  for (const p of store.products) for (const v of p.variants) skuToProduct.set(v.sku, p.name);

  return NextResponse.json({
    stock: Array.from(store.inventory.values()).map((s) => ({
      ...s,
      available: s.onHand - s.reserved,
      product: skuToProduct.get(s.sku) ?? s.sku,
    })),
    reservations: [...store.reservations].reverse().slice(0, 50),
    adjustments: store.stockAdjustments.slice(0, 50),
  });
}
