import { NextRequest, NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { audit, store } from '@/lib/store';
import { uid } from '@/lib/utils';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** POST /api/admin/inventory/adjust — manual stock adjustment (staff only). */
export async function POST(req: NextRequest) {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const { sku, delta, reason } = (body ?? {}) as { sku?: string; delta?: number; reason?: string };
  const rec = store.inventory.get(String(sku ?? ''));
  if (!rec) return NextResponse.json({ error: 'NOT_FOUND', message: 'Unknown SKU.' }, { status: 404 });
  const d = Number(delta ?? 0);
  if (!Number.isInteger(d) || d === 0) {
    return NextResponse.json({ error: 'VALIDATION', message: 'Delta must be a non-zero integer.' }, { status: 422 });
  }
  if (rec.onHand + d < rec.reserved) {
    return NextResponse.json(
      { error: 'VALIDATION', message: `Cannot reduce below reserved quantity (${rec.reserved}).` },
      { status: 422 },
    );
  }
  rec.onHand += d;
  store.stockAdjustments.unshift({
    id: uid('adj'),
    sku: rec.sku,
    delta: d,
    reason: String(reason ?? 'Manual adjustment').slice(0, 200),
    at: new Date().toISOString(),
    by: auth.actor,
  });
  audit(auth.actor, 'inventory.adjusted', `${rec.sku} ${d > 0 ? '+' : ''}${d} (${reason ?? 'manual'})`);
  return NextResponse.json({ ok: true, stock: rec });
}
