import { NextRequest, NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { audit, store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/admin/delivery-rules — current delivery configuration (staff). */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });
  return NextResponse.json({
    rules: store.deliveryRules,
    bookings: Object.fromEntries(store.capacityBookings),
  });
}

/** PATCH /api/admin/delivery-rules — update zones/pins/cut-off (staff). */
export async function PATCH(req: NextRequest) {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const input = (body ?? {}) as {
    addUnsupportedPin?: string;
    removeUnsupportedPin?: string;
    cutoffHour?: number;
    capacityPerDay?: number;
    zoneId?: string;
    fee?: number;
    transitMin?: number;
    transitMax?: number;
  };

  if (input.addUnsupportedPin && /^\d{3,6}$/.test(input.addUnsupportedPin)) {
    if (!store.deliveryRules.unsupportedPins.includes(input.addUnsupportedPin)) {
      store.deliveryRules.unsupportedPins.push(input.addUnsupportedPin);
      audit(auth.actor, 'delivery.pin.blocked', input.addUnsupportedPin);
    }
  }
  if (input.removeUnsupportedPin) {
    store.deliveryRules.unsupportedPins = store.deliveryRules.unsupportedPins.filter((p) => p !== input.removeUnsupportedPin);
    audit(auth.actor, 'delivery.pin.unblocked', input.removeUnsupportedPin);
  }
  if (typeof input.cutoffHour === 'number' && input.cutoffHour >= 0 && input.cutoffHour <= 23) {
    store.deliveryRules.cutoffHour = Math.round(input.cutoffHour);
  }
  if (typeof input.capacityPerDay === 'number' && input.capacityPerDay >= 1) {
    store.deliveryRules.capacityPerDay = Math.round(input.capacityPerDay);
  }
  if (input.zoneId) {
    const zone = store.deliveryRules.zones.find((z) => z.id === input.zoneId);
    if (zone) {
      if (typeof input.fee === 'number' && input.fee >= 0) zone.fee = Math.round(input.fee);
      if (typeof input.transitMin === 'number' && typeof input.transitMax === 'number' && input.transitMin >= 1 && input.transitMax >= input.transitMin) {
        zone.transitDays = [Math.round(input.transitMin), Math.round(input.transitMax)];
      }
      audit(auth.actor, 'delivery.zone.updated', zone.id);
    }
  }

  return NextResponse.json({ ok: true, rules: store.deliveryRules });
}
