import { NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { store } from '@/lib/store';
import { signMediaUrl } from '@/lib/uploads';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/admin/misc — audit log, emails, content placeholders (staff). */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });
  return NextResponse.json({
    audit: store.audit.slice(0, 100),
    emails: store.emails.slice(0, 50),
    uploads: Array.from(store.uploads.values())
      .filter((u) => u.status !== 'authorised')
      .map((u) => ({ id: u.id, status: u.status, size: u.size, width: u.width, height: u.height, url: `/api/uploads/${u.id}/file?token=${signMediaUrl(u.id)}` })),
    contentPlaceholders: [
      { key: 'contact-details', label: 'Contact details (phone/email/WhatsApp)', location: 'Contact page + footer', status: 'owner input needed' },
      { key: 'about-story', label: 'Founding story & team photos', location: 'About page', status: 'owner input needed' },
      { key: 'legal-entity', label: 'Registered legal entity & jurisdiction', location: 'Terms / Privacy', status: 'owner input needed' },
      { key: 'return-window', label: 'Exact return window (days)', location: 'Returns policy', status: 'owner input needed' },
      { key: 'social-links', label: 'Social media profiles', location: 'Footer', status: 'not configured' },
    ],
  });
}
