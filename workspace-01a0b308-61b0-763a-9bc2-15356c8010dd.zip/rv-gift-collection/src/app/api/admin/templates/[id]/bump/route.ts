import { NextRequest, NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { audit, store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/admin/templates/:id/bump — publish a new template version.
 *
 * Versioning rule: existing PAID orders keep the approved template version
 * snapshotted at purchase time. Only new carts pick up the bumped version.
 */
export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  for (const product of store.products) {
    if (product.personalisation?.id === params.id) {
      product.personalisation.version += 1;
      store.templateVersions.set(params.id, product.personalisation.version);
      audit(auth.actor, 'template.version.bumped', `${params.id} → v${product.personalisation.version}`);
      return NextResponse.json({ ok: true, templateId: params.id, version: product.personalisation.version });
    }
  }
  return NextResponse.json({ error: 'NOT_FOUND' }, { status: 404 });
}
