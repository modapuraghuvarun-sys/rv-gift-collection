import { NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/admin/templates — personalization template configs (staff). */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });
  return NextResponse.json({
    templates: store.products
      .filter((p) => p.personalisation)
      .map((p) => ({
        productId: p.id,
        product: p.name,
        template: p.personalisation,
      })),
  });
}
