import { NextRequest, NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { audit, store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/admin/tickets — list. PATCH /:id — update status. */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });
  return NextResponse.json({ tickets: store.tickets });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const { status } = (body ?? {}) as { status?: string };
  const ticket = store.tickets.find((t) => t.id === params.id);
  if (!ticket) return NextResponse.json({ error: 'NOT_FOUND' }, { status: 404 });
  if (status && ['open', 'in_progress', 'resolved'].includes(status)) {
    ticket.status = status as typeof ticket.status;
    audit(auth.actor, 'ticket.updated', `${ticket.reference} → ${status}`);
  }
  return NextResponse.json({ ok: true, ticket });
}
