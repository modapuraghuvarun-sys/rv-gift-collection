import { NextRequest, NextResponse } from 'next/server';
import { requireStaff } from '@/lib/admin';
import { retryFailedJob, runDueJobs } from '@/lib/jobs';
import { store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/admin/jobs — job queue (staff). */
export async function GET() {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });
  return NextResponse.json({ jobs: [...store.jobs].reverse().slice(0, 100) });
}

/** POST /api/admin/jobs — body {action:'run'} or {action:'retry', jobId}. */
export async function POST(req: NextRequest) {
  const auth = requireStaff();
  if (!auth.ok) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: auth.status });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    body = {};
  }
  const { action, jobId } = (body ?? {}) as { action?: string; jobId?: string };
  if (action === 'retry' && jobId) {
    const ok = retryFailedJob(jobId);
    return NextResponse.json({ ok });
  }
  const processed = runDueJobs();
  return NextResponse.json({ ok: true, processed });
}
