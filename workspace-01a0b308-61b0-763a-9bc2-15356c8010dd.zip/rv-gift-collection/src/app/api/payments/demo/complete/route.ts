import { NextRequest, NextResponse } from 'next/server';
import { getPayment, processWebhook, signPayload, type WebhookPayload } from '@/lib/payments';
import { randomToken } from '@/lib/utils';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/payments/demo/complete
 * Demo-only bridge that simulates the provider side of the webhook. It builds
 * a properly signed webhook payload and runs it through the EXACT production
 * webhook processor (signature verification + idempotency included), so there
 * is a single code path for payment confirmation.
 *
 * In production this route does not exist — Razorpay calls
 * /api/webhooks/payment directly, server to server.
 */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const { paymentId, outcome } = (body ?? {}) as { paymentId?: string; outcome?: 'success' | 'failed' };
  const payment = paymentId ? getPayment(paymentId) : undefined;
  if (!payment) {
    return NextResponse.json({ error: 'PAYMENT_NOT_FOUND' }, { status: 404 });
  }
  if (payment.status === 'CAPTURED') {
    return NextResponse.json({ status: 'ALREADY_CAPTURED', reference: undefined });
  }

  const payload: WebhookPayload = {
    event_id: `evt_${randomToken(8)}`,
    provider_order_id: payment.providerOrderId,
    payment_id: `pay_${randomToken(8)}`,
    amount: payment.amount,
    currency: 'INR',
    status: outcome === 'failed' ? 'failed' : 'captured',
  };
  // Re-derive the signature exactly as the provider would.
  const signature = signPayload(payload);
  const { verifySignature } = await import('@/lib/payments');
  if (!verifySignature(JSON.stringify(payload), signature)) {
    return NextResponse.json({ error: 'BAD_SIGNATURE' }, { status: 401 });
  }

  const result = processWebhook(payload);
  if (!result.ok) {
    return NextResponse.json({ error: result.code, message: result.message }, { status: 422 });
  }
  return NextResponse.json({ ok: true, outcome: payload.status });
}
