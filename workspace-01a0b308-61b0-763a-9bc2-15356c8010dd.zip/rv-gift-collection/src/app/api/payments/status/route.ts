import { NextRequest, NextResponse } from 'next/server';
import { getPayment } from '@/lib/payments';
import { store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/payments/status?payment=…&token=… */
export async function GET(req: NextRequest) {
  const paymentId = req.nextUrl.searchParams.get('payment') ?? '';
  const token = req.nextUrl.searchParams.get('token') ?? '';
  const payment = getPayment(paymentId);
  if (!payment) {
    return NextResponse.json({ error: 'NOT_FOUND' }, { status: 404 });
  }
  const order = store.orders.find((o) => o.id === payment.orderId);
  if (!order || order.trackingToken !== token) {
    return NextResponse.json({ error: 'FORBIDDEN' }, { status: 403 });
  }
  return NextResponse.json({
    paymentStatus: payment.status,
    orderStatus: order.status,
    reference: order.reference,
    trackingToken: order.trackingToken,
    amount: payment.amount,
  });
}
