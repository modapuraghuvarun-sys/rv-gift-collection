import { NextRequest, NextResponse } from 'next/server';
import { store } from '@/lib/store';
import { getPayment } from '@/lib/payments';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/payments/create
 * In production this creates a Razorpay order (server-side, using the secret
 * key) and returns the provider order id for the hosted checkout. Demo mode
 * returns the already-created payment and points at the simulated hosted
 * checkout page.
 */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const { paymentId } = (body ?? {}) as { paymentId?: string };
  const payment = paymentId ? getPayment(paymentId) : undefined;
  if (!payment || payment.status !== 'CREATED') {
    return NextResponse.json({ error: 'PAYMENT_NOT_FOUND', message: 'No active payment found.' }, { status: 404 });
  }
  const order = store.orders.find((o) => o.id === payment.orderId);
  if (!order) {
    return NextResponse.json({ error: 'ORDER_NOT_FOUND' }, { status: 404 });
  }

  // Production: razorpay.orders.create({ amount: payment.amount, currency: 'INR' })
  // and return the hosted checkout session. Demo: simulated hosted page.
  return NextResponse.json({
    mode: 'demo',
    paymentId: payment.id,
    providerOrderId: payment.providerOrderId,
    amount: payment.amount,
    currency: payment.currency,
    checkoutUrl: `/payment/demo?payment=${payment.id}`,
    reference: order.reference,
  });
}
