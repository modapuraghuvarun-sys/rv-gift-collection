import { NextRequest, NextResponse } from 'next/server';
import { completeUpload } from '@/lib/uploads';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/uploads/:id/complete — binary body.
 * Step 2: the (metadata-stripped, re-encoded) image bytes are delivered and
 * re-validated server-side (magic bytes, size) before being stored privately.
 */
export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const buf = Buffer.from(await req.arrayBuffer());
  const result = completeUpload(params.id, buf);
  if (!result.ok) {
    const status = result.code === 'UPLOAD_NOT_FOUND' ? 404 : 422;
    return NextResponse.json({ error: result.code, message: result.message }, { status });
  }
  return NextResponse.json({ assetId: result.assetId, visibility: 'private' });
}
