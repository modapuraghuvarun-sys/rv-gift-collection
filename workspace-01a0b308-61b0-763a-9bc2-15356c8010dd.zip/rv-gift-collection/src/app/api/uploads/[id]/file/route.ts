import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { getSession, store } from '@/lib/store';
import { verifyMediaToken } from '@/lib/uploads';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/uploads/:id/file?token=…
 * Private customer media. Requires EITHER a staff session OR a short-lived
 * signed token. In production this maps to signed Supabase Storage URLs with
 * a short TTL.
 */
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const token = req.nextUrl.searchParams.get('token') ?? '';
  const session = getSession(cookies().get('rv_session')?.value);
  const isStaff = session?.role === 'staff';

  if (!isStaff && !verifyMediaToken(params.id, token)) {
    return NextResponse.json({ error: 'FORBIDDEN' }, { status: 403 });
  }
  const record = store.uploads.get(params.id);
  if (!record || !record.buffer) {
    return NextResponse.json({ error: 'NOT_FOUND' }, { status: 404 });
  }
  return new NextResponse(new Uint8Array(record.buffer), {
    headers: {
      'Content-Type': record.contentType,
      'Cache-Control': 'private, max-age=60',
      'X-Content-Type-Options': 'nosniff',
    },
  });
}
