import { NextRequest, NextResponse } from 'next/server';
import { authoriseUpload, MAX_UPLOAD_BYTES } from '@/lib/uploads';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/uploads/authorise
 * Step 1 of the upload pipeline. Server validates type/size/dimensions and
 * issues an upload session. In production this returns a short-lived signed
 * URL to the PRIVATE customer-uploads bucket (Supabase Storage).
 */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST', message: 'Invalid request body.' }, { status: 400 });
  }
  const input = (body ?? {}) as {
    contentType?: string;
    size?: number;
    width?: number;
    height?: number;
    productId?: string;
    photoIndex?: number;
  };
  const result = authoriseUpload({
    contentType: String(input.contentType ?? ''),
    size: Number(input.size ?? 0),
    width: Number(input.width ?? 0),
    height: Number(input.height ?? 0),
    productId: input.productId,
    photoIndex: input.photoIndex,
  });
  if (!result.ok) {
    return NextResponse.json(
      { error: result.code, message: result.message },
      { status: 422 },
    );
  }
  return NextResponse.json({
    uploadId: result.uploadId,
    maxBytes: MAX_UPLOAD_BYTES,
    acceptedTypes: ['image/jpeg', 'image/png'],
  });
}
