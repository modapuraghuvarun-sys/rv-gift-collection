import { NextRequest, NextResponse } from 'next/server';
import { checkDelivery } from '@/lib/delivery';
import { store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** POST /api/delivery/check — PIN code availability for a product. */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST', message: 'Invalid request body.' }, { status: 400 });
  }
  const { pincode, productId } = (body ?? {}) as { pincode?: string; productId?: string };
  if (!pincode || typeof pincode !== 'string') {
    return NextResponse.json({ error: 'BAD_REQUEST', message: 'PIN code is required.' }, { status: 400 });
  }
  const product = store.products.find((p) => p.id === productId);
  if (!product) {
    return NextResponse.json({ error: 'NOT_FOUND', message: 'Product not found.' }, { status: 404 });
  }
  const result = checkDelivery(pincode.trim(), product, 1);
  return NextResponse.json(result);
}
