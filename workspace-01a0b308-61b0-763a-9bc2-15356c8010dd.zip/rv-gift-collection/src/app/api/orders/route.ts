import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { createOrder } from '@/lib/orders';
import { getSession, store } from '@/lib/store';
import { isValidEmail, isValidIndianPincode, isValidPhone } from '@/lib/utils';
import type { CartLine } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/orders — create an order from a server quote.
 * Validates buyer/recipient/address server-side, reserves inventory,
 * snapshots everything at purchase time, and creates the payment.
 */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST', message: 'Invalid request body.' }, { status: 400 });
  }
  const input = (body ?? {}) as {
    quoteId?: string;
    lines?: CartLine[];
    couponCode?: string;
    deliveryOption?: string;
    buyer?: { name?: string; email?: string; phone?: string };
    recipient?: { name?: string; phone?: string; giftMessage?: string };
    address?: {
      fullName?: string;
      phone?: string;
      line1?: string;
      line2?: string;
      city?: string;
      state?: string;
      pincode?: string;
    };
  };

  const session = getSession(cookies().get('rv_session')?.value);
  const profile = session?.userId ? store.profiles.find((p) => p.id === session.userId) : undefined;

  const buyerName = String(input.buyer?.name ?? profile?.name ?? '').trim();
  const buyerEmail = String(input.buyer?.email ?? profile?.email ?? '').trim().toLowerCase();
  const buyerPhone = String(input.buyer?.phone ?? profile?.phone ?? '').replace(/\D/g, '');
  const a = input.address ?? {};

  const problems: string[] = [];
  if (buyerName.length < 2) problems.push('Please enter the buyer name.');
  if (!isValidEmail(buyerEmail)) problems.push('Please enter a valid buyer email.');
  if (!isValidPhone(buyerPhone)) problems.push('Please enter a valid 10-digit buyer phone number.');
  if (String(a.fullName ?? '').trim().length < 2) problems.push('Recipient name is required.');
  if (String(a.line1 ?? '').trim().length < 4) problems.push('Delivery address is required.');
  if (String(a.city ?? '').trim().length < 2) problems.push('City is required.');
  if (String(a.state ?? '').trim().length < 2) problems.push('State is required.');
  if (!isValidIndianPincode(String(a.pincode ?? ''))) problems.push('A valid 6-digit PIN code is required.');

  if (problems.length) {
    return NextResponse.json({ error: 'VALIDATION', message: problems.join(' ') }, { status: 422 });
  }

  const result = createOrder({
    quoteId: String(input.quoteId ?? ''),
    lines: Array.isArray(input.lines) ? input.lines : [],
    couponCode: input.couponCode,
    deliveryOption: input.deliveryOption === 'express' ? 'express' : 'standard',
    buyer: {
      userId: profile?.id,
      name: buyerName,
      email: buyerEmail,
      phone: buyerPhone,
    },
    recipient: {
      name: String(input.recipient?.name ?? a.fullName ?? '').trim(),
      phone: input.recipient?.phone ? String(input.recipient.phone).replace(/\D/g, '') : undefined,
      giftMessage: input.recipient?.giftMessage ? String(input.recipient.giftMessage).slice(0, 300) : undefined,
    },
    address: {
      fullName: String(a.fullName ?? '').trim(),
      phone: String(a.phone ?? buyerPhone).replace(/\D/g, ''),
      line1: String(a.line1 ?? '').trim(),
      line2: a.line2 ? String(a.line2).trim() : undefined,
      city: String(a.city ?? '').trim(),
      state: String(a.state ?? '').trim(),
      pincode: String(a.pincode ?? '').trim(),
    },
    isGuest: !profile,
  });

  if (!result.ok) {
    const status = result.code === 'QUOTE_NOT_FOUND' || result.code === 'QUOTE_EXPIRED' ? 410 : 422;
    return NextResponse.json(
      {
        error: result.code,
        message: result.message,
        newQuoteId: result.newQuoteId,
        newTotal: result.newTotal,
      },
      { status },
    );
  }

  // For guests we expose the tracking token once (also emailed in production).
  return NextResponse.json({
    orderId: result.order!.id,
    reference: result.order!.reference,
    trackingToken: result.order!.isGuest ? result.order!.trackingToken : undefined,
    paymentId: result.paymentId,
    total: result.order!.total,
  });
}
