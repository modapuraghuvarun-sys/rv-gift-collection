import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { accessOrder, STATUS_LABELS } from '@/lib/orders';
import { getSession } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/orders/:reference?token=…
 * Secure order lookup: requires the secret tracking token (guest links) or
 * the owning account / staff session. Reference + email alone is never enough.
 */
export async function GET(req: NextRequest, { params }: { params: { reference: string } }) {
  const token = req.nextUrl.searchParams.get('token') ?? undefined;
  const session = getSession(cookies().get('rv_session')?.value);

  const access = accessOrder(params.reference, {
    token,
    userId: session?.userId,
    staff: session?.role === 'staff',
  });

  if (!access.ok) {
    const status = access.reason === 'NOT_FOUND' ? 404 : 403;
    return NextResponse.json(
      { error: access.reason === 'NOT_FOUND' ? 'NOT_FOUND' : 'FORBIDDEN', message: 'Order not available.' },
      { status },
    );
  }

  const order = access.order!;
  return NextResponse.json({
    reference: order.reference,
    createdAt: order.createdAt,
    status: order.status,
    statusLabel: STATUS_LABELS[order.status],
    history: order.history.map((h) => ({ ...h, label: STATUS_LABELS[h.status] })),
    buyerName: order.buyer.name,
    recipient: order.recipient,
    address: order.address,
    items: order.items,
    subtotal: order.subtotal,
    discount: order.discount,
    couponCode: order.couponCode,
    taxIncluded: order.taxIncluded,
    deliveryFee: order.deliveryFee,
    deliveryOption: order.deliveryOption,
    deliveryWindow: order.deliveryWindow,
    total: order.total,
    paymentStatus: paymentStatusFor(order.paymentId),
    shipment: order.shipment ?? null,
  });
}

import { store } from '@/lib/store';

function paymentStatusFor(paymentId?: string): string {
  if (!paymentId) return 'UNKNOWN';
  const pay = store.payments.find((p) => p.id === paymentId);
  return pay?.status ?? 'UNKNOWN';
}
