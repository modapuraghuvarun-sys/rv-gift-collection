import { NextRequest, NextResponse } from 'next/server';
import { store } from '@/lib/store';
import { enqueueJob } from '@/lib/jobs';
import { generateCaseReference, isValidEmail, uid } from '@/lib/utils';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const TYPES = [
  'order-issue',
  'personalization-correction',
  'delivery-issue',
  'damaged-product',
  'incorrect-product',
  'other',
];

/** POST /api/support — create a support case with a case reference. */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const input = (body ?? {}) as {
    type?: string;
    name?: string;
    email?: string;
    orderReference?: string;
    message?: string;
  };

  const type = TYPES.includes(input.type ?? '') ? input.type! : 'other';
  const name = String(input.name ?? '').trim();
  const email = String(input.email ?? '').trim().toLowerCase();
  const message = String(input.message ?? '').trim();

  if (name.length < 2) return NextResponse.json({ error: 'VALIDATION', message: 'Please enter your name.' }, { status: 422 });
  if (!isValidEmail(email)) return NextResponse.json({ error: 'VALIDATION', message: 'Please enter a valid email.' }, { status: 422 });
  if (message.length < 10) return NextResponse.json({ error: 'VALIDATION', message: 'Please describe the issue in a little more detail.' }, { status: 422 });

  // Order-linked requests: the order reference must exist (no data is
  // returned — we only confirm existence to avoid leaking order details).
  let linkedOrderRef: string | undefined;
  if (input.orderReference) {
    const found = store.orders.find((o) => o.reference.toLowerCase() === String(input.orderReference).trim().toLowerCase());
    if (found) linkedOrderRef = found.reference;
  }

  const ticket = {
    id: uid('tkt'),
    reference: generateCaseReference(),
    createdAt: new Date().toISOString(),
    type,
    orderReference: linkedOrderRef,
    name,
    email,
    message: message.slice(0, 2000),
    status: 'open' as const,
  };
  store.tickets.unshift(ticket);

  enqueueJob('send_email', {
    to: email,
    template: 'support_acknowledgement',
    subject: `We received your request ${ticket.reference}`,
  }, { idempotencyKey: `email:tkt:${ticket.id}` });

  return NextResponse.json({ ok: true, caseReference: ticket.reference });
}
