import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { STATUS_LABELS } from '@/lib/orders';
import { getSession, store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/account/orders — the signed-in customer's own orders only. */
export async function GET() {
  const session = getSession(cookies().get('rv_session')?.value);
  if (!session?.userId) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });

  const orders = store.orders
    .filter((o) => o.buyer.userId === session.userId)
    .map((o) => ({
      reference: o.reference,
      createdAt: o.createdAt,
      status: o.status,
      statusLabel: STATUS_LABELS[o.status],
      total: o.total,
    }));
  return NextResponse.json({ orders });
}
