import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { getSession, store } from '@/lib/store';
import { isValidIndianPincode, isValidPhone, uid } from '@/lib/utils';
import type { Address } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET — list saved addresses. POST — add/update address (owner only). */
export async function GET() {
  const session = getSession(cookies().get('rv_session')?.value);
  const profile = session?.userId ? store.profiles.find((p) => p.id === session.userId) : undefined;
  if (!profile) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });
  return NextResponse.json({ addresses: profile.addresses });
}

export async function POST(req: NextRequest) {
  const session = getSession(cookies().get('rv_session')?.value);
  const profile = session?.userId ? store.profiles.find((p) => p.id === session.userId) : undefined;
  if (!profile) return NextResponse.json({ error: 'UNAUTHORIZED' }, { status: 401 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST' }, { status: 400 });
  }
  const input = (body ?? {}) as Partial<Address> & { deleteId?: string };

  if (input.deleteId) {
    profile.addresses = profile.addresses.filter((a) => a.id !== input.deleteId);
    return NextResponse.json({ ok: true, addresses: profile.addresses });
  }

  const address: Address = {
    id: input.id && profile.addresses.some((a) => a.id === input.id) ? input.id : uid('addr'),
    fullName: String(input.fullName ?? '').trim(),
    phone: String(input.phone ?? '').replace(/\D/g, ''),
    line1: String(input.line1 ?? '').trim(),
    line2: input.line2 ? String(input.line2).trim() : undefined,
    city: String(input.city ?? '').trim(),
    state: String(input.state ?? '').trim(),
    pincode: String(input.pincode ?? '').trim(),
    isDefault: Boolean(input.isDefault),
  };

  const problems: string[] = [];
  if (address.fullName.length < 2) problems.push('Name is required.');
  if (!isValidPhone(address.phone)) problems.push('Valid phone required.');
  if (address.line1.length < 4) problems.push('Address line required.');
  if (address.city.length < 2 || address.state.length < 2) problems.push('City and state required.');
  if (!isValidIndianPincode(address.pincode)) problems.push('Valid 6-digit PIN required.');
  if (problems.length) return NextResponse.json({ error: 'VALIDATION', message: problems.join(' ') }, { status: 422 });

  if (address.isDefault) profile.addresses.forEach((a) => (a.isDefault = false));
  const existingIdx = profile.addresses.findIndex((a) => a.id === address.id);
  if (existingIdx >= 0) profile.addresses[existingIdx] = address;
  else profile.addresses.push(address);

  return NextResponse.json({ ok: true, addresses: profile.addresses });
}
