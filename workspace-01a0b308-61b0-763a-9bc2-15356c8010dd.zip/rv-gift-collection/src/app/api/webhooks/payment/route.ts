import { NextRequest, NextResponse } from 'next/server';
import { processWebhook, verifySignature, type WebhookPayload } from '@/lib/payments';
import { audit } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/webhooks/payment
 *
 * Provider webhook endpoint. Security checklist (all enforced):
 *  1. Verify HMAC signature over the raw body (webhook secret)
 *  2. Verify provider order id maps to a known payment
 *  3. Verify amount + currency
 *  4. Verify captured/success state before confirming
 *  5. Idempotency on the unique provider event id — duplicates are accepted
 *     (200) but never re-applied (no duplicate payments, stock allocation or
 *     production jobs)
 *
 * A browser redirect is NEVER treated as proof of payment — this endpoint is
 * the only path that confirms an order.
 */
export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get('x-rv-signature') ?? req.headers.get('x-razorpay-signature') ?? '';

  if (!verifySignature(rawBody, signature)) {
    audit('webhook', 'payment.webhook.rejected', 'Invalid webhook signature');
    return NextResponse.json({ error: 'BAD_SIGNATURE', message: 'Invalid signature.' }, { status: 401 });
  }

  let payload: WebhookPayload;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST', message: 'Invalid payload.' }, { status: 400 });
  }

  if (!payload.event_id || !payload.provider_order_id || !payload.payment_id || typeof payload.amount !== 'number') {
    return NextResponse.json({ error: 'BAD_REQUEST', message: 'Missing webhook fields.' }, { status: 400 });
  }

  const result = processWebhook(payload);
  if (!result.ok) {
    return NextResponse.json({ error: result.code, message: result.message }, { status: 422 });
  }
  return NextResponse.json({ received: true, duplicate: Boolean(result.duplicate) });
}
