import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { buildQuote } from '@/lib/pricing';
import { getSession, store } from '@/lib/store';
import type { CartLine } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/checkout/quote
 * Server-authoritative pricing: recomputes every amount in integer paise.
 * Browser totals are never accepted.
 */
export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'BAD_REQUEST', message: 'Invalid request body.' }, { status: 400 });
  }
  const input = (body ?? {}) as {
    lines?: CartLine[];
    couponCode?: string;
    deliveryOption?: 'standard' | 'express';
    pincode?: string;
  };
  if (!Array.isArray(input.lines)) {
    return NextResponse.json({ error: 'BAD_REQUEST', message: 'Cart lines are required.' }, { status: 400 });
  }

  const session = getSession(cookies().get('rv_session')?.value);
  const profile = session?.userId ? store.profiles.find((p) => p.id === session.userId) : undefined;

  const result = buildQuote({
    lines: input.lines,
    couponCode: input.couponCode || undefined,
    deliveryOption: input.deliveryOption === 'express' ? 'express' : 'standard',
    pincode: input.pincode || undefined,
    customerEmail: profile?.email,
  });

  if (!result.ok) {
    return NextResponse.json({ error: result.code, message: result.message }, { status: 422 });
  }
  return NextResponse.json(result.quote);
}
