import { NextRequest, NextResponse } from 'next/server';
import { categories, occasions, recipients } from '@/lib/data/catalog';
import { store, ensureJobLoop } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/products
 * Public catalogue — only published products are ever returned.
 * Query params: q, category, occasion, recipient, collection, personalisable,
 * min, max, sort (featured|price-asc|price-desc|newest), page, pageSize
 */
export async function GET(req: NextRequest) {
  ensureJobLoop();
  const sp = req.nextUrl.searchParams;
  const q = (sp.get('q') ?? '').trim().toLowerCase();
  const category = sp.get('category') ?? '';
  const occasion = sp.get('occasion') ?? '';
  const recipient = sp.get('recipient') ?? '';
  const collection = sp.get('collection') ?? '';
  const personalisable = sp.get('personalisable') === 'true';
  const min = Number(sp.get('min') ?? 0) || 0; // rupees
  const max = Number(sp.get('max') ?? 0) || 0;
  const sort = sp.get('sort') ?? 'featured';
  const page = Math.max(1, Number(sp.get('page') ?? 1) || 1);
  const pageSize = Math.min(24, Math.max(1, Number(sp.get('pageSize') ?? 12) || 12));

  let items = store.products.filter((p) => p.status === 'published');

  if (q) {
    items = items.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.shortDescription.toLowerCase().includes(q) ||
        p.category.replace('-', ' ').includes(q),
    );
  }
  if (category) items = items.filter((p) => p.category === category);
  if (occasion) items = items.filter((p) => p.occasions.includes(occasion));
  if (recipient) items = items.filter((p) => p.recipients.includes(recipient));
  if (collection) items = items.filter((p) => p.collections.includes(collection));
  if (personalisable) items = items.filter((p) => Boolean(p.personalisation));
  if (min > 0) items = items.filter((p) => Math.min(...p.variants.map((v) => v.price)) >= min * 100);
  if (max > 0) items = items.filter((p) => Math.min(...p.variants.map((v) => v.price)) <= max * 100);

  const minPrice = (p: (typeof items)[number]) => Math.min(...p.variants.filter((v) => v.available).map((v) => v.price));
  switch (sort) {
    case 'price-asc':
      items = [...items].sort((a, b) => minPrice(a) - minPrice(b));
      break;
    case 'price-desc':
      items = [...items].sort((a, b) => minPrice(b) - minPrice(a));
      break;
    default:
      items = [...items].sort((a, b) => Number(b.featured) - Number(a.featured));
  }

  const total = items.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const paged = items.slice((page - 1) * pageSize, page * pageSize);

  return NextResponse.json({
    products: paged.map((p) => {
      const availableVariants = p.variants.filter((v) => v.available);
      const fromPrice = availableVariants.length
        ? Math.min(...availableVariants.map((v) => v.price))
        : Math.min(...p.variants.map((v) => v.price));
      return {
        id: p.id,
        slug: p.slug,
        name: p.name,
        category: p.category,
        shortDescription: p.shortDescription,
        image: p.images[0],
        fromPrice,
        personalisable: Boolean(p.personalisation),
        photoPersonalisable: Boolean(p.personalisation && p.personalisation.photos.count > 0),
        variantOptions: variantOptionsFor(p),
        inStock: availableVariants.length > 0,
        featured: p.featured,
      };
    }),
    total,
    page,
    totalPages,
    pageSize,
    facets: {
      categories: categories.map((c) => ({ slug: c.slug, name: c.name })),
      occasions: occasions.map((o) => ({ slug: o.slug, name: o.name })),
      recipients: recipients.map((r) => ({ slug: r.slug, name: r.name })),
    },
  });
}

function variantOptionsFor(p: (typeof store.products)[number]): { label: string; values: string[] }[] {
  const map = new Map<string, Set<string>>();
  for (const v of p.variants) {
    for (const [k, val] of Object.entries(v.attributes)) {
      if (!map.has(k)) map.set(k, new Set());
      map.get(k)!.add(val);
    }
  }
  return Array.from(map.entries()).map(([label, values]) => ({ label, values: Array.from(values) }));
}
