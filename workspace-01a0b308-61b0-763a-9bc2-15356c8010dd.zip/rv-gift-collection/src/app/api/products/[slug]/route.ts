import { NextRequest, NextResponse } from 'next/server';
import { store } from '@/lib/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** GET /api/products/:slug — single published product with live stock. */
export async function GET(_req: NextRequest, { params }: { params: { slug: string } }) {
  const product = store.products.find((p) => p.slug === params.slug);
  if (!product || product.status !== 'published') {
    return NextResponse.json({ error: 'NOT_FOUND' }, { status: 404 });
  }
  const variants = product.variants.map((v) => {
    const rec = store.inventory.get(v.sku);
    const available = rec ? rec.onHand - rec.reserved : 0;
    return {
      ...v,
      available: v.available && available > 0,
      stockAvailable: Math.max(0, available),
      lowStock: available > 0 && available <= 3,
    };
  });
  return NextResponse.json({ ...product, variants });
}
