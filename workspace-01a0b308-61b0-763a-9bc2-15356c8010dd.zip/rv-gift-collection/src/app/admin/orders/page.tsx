'use client';

import { useState } from 'react';
import { AdminTable, StatusPill, useAdminData } from '@/components/admin/AdminShell';
import { formatINR } from '@/lib/money';
import { formatDateTime } from '@/lib/utils';

const STATUSES = [
  'CONFIRMED', 'PERSONALISATION_REVIEW', 'IN_PRODUCTION', 'QUALITY_CHECKED',
  'PACKED', 'SHIPPED', 'DELIVERED', 'CORRECTION_HOLD', 'CANCELLED', 'DELIVERY_EXCEPTION',
];

interface AdminOrder {
  id: string;
  reference: string;
  createdAt: string;
  status: string;
  buyer: { name: string; email: string; phone: string };
  recipient: { name: string };
  items: { name: string; sku: string; qty: number; personalisation?: { fields: Record<string, string>; previewThumb?: string; assetIds: string[] } }[];
  total: number;
  shipment?: { courier?: string; awb?: string } | null;
}

export default function AdminOrdersPage() {
  const { data, reload } = useAdminData<{ orders: AdminOrder[] }>('/api/admin/orders');
  const [open, setOpen] = useState<string | null>(null);
  const [msg, setMsg] = useState('');
  const [filter, setFilter] = useState('all');

  if (!data) return <div className="skeleton h-64" />;

  const orders = data.orders.filter((o) => filter === 'all' || o.status === filter);

  async function setStatus(id: string, status: string) {
    const note = window.prompt('Note for this status change (shown to customer):', '') ?? '';
    setMsg('Updating…');
    const res = await fetch(`/api/admin/orders/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, note: note || 'Order update' }),
    });
    setMsg(res.ok ? 'Status updated.' : 'Update failed.');
    reload();
  }

  async function refund(id: string) {
    const reason = window.prompt('Refund reason:', 'Damaged product');
    if (reason === null) return;
    const res = await fetch(`/api/admin/orders/${id}/refunds`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason }),
    });
    setMsg(res.ok ? 'Refund initiated (see Support & Refunds).' : 'Refund failed.');
    reload();
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-2xl text-burgundy-900">Orders</h1>
        <select className="input w-auto py-2 text-xs" value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Filter orders by status">
          <option value="all">All statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
        </select>
      </div>
      <p className="text-xs text-ink-400" aria-live="polite">{msg}</p>

      <AdminTable head={['Order', 'Placed', 'Customer', 'Items', 'Total', 'Status', 'Actions']}>
        {orders.map((o) => (
          <tr key={o.id} className="align-top hover:bg-cream-50/60">
            <td className="px-4 py-3">
              <p className="font-bold text-ink-900">{o.reference}</p>
              <p className="text-[11px] text-ink-400">{o.shipment?.awb ? `AWB ${o.shipment.awb}` : ''}</p>
            </td>
            <td className="px-4 py-3 text-xs text-ink-500">{formatDateTime(o.createdAt)}</td>
            <td className="px-4 py-3">
              <p className="text-xs font-semibold text-ink-900">{o.buyer.name}</p>
              <p className="text-[11px] text-ink-400">{o.buyer.email}</p>
            </td>
            <td className="px-4 py-3">
              <button className="text-xs font-semibold text-burgundy-700 underline" onClick={() => setOpen(open === o.id ? null : o.id)}>
                {o.items.length} item{o.items.length > 1 ? 's' : ''}
              </button>
              {open === o.id && (
                <ul className="mt-2 space-y-2 rounded-lg bg-cream-50 p-3">
                  {o.items.map((it, i) => (
                    <li key={i} className="text-[11px] text-ink-500">
                      <strong className="text-ink-900">{it.name}</strong> · {it.sku} × {it.qty}
                      {it.personalisation && (
                        <span className="mt-1 block rounded bg-white p-2">
                          {Object.entries(it.personalisation.fields).filter(([, v]) => v).map(([k, v]) => (
                            <span key={k} className="mr-2"><b className="capitalize">{k}:</b> {v}</span>
                          ))}
                          {it.personalisation.assetIds.length > 0 && (
                            <span className="text-burgundy-700">· {it.personalisation.assetIds.length} private photo asset(s) — visible in Production with signed links</span>
                          )}
                        </span>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </td>
            <td className="px-4 py-3 text-sm font-bold">{formatINR(o.total)}</td>
            <td className="px-4 py-3"><StatusPill status={o.status} /></td>
            <td className="px-4 py-3">
              <div className="flex flex-col gap-1.5">
                <select
                  className="input w-40 py-1.5 text-[11px]"
                  value={o.status}
                  onChange={(e) => setStatus(o.id, e.target.value)}
                  aria-label={`Set status for ${o.reference}`}
                >
                  {STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
                </select>
                <button className="btn-ghost btn-sm text-burgundy-700" onClick={() => refund(o.id)}>Initiate refund</button>
              </div>
            </td>
          </tr>
        ))}
        {orders.length === 0 && (
          <tr><td colSpan={7} className="px-4 py-8 text-center text-sm text-ink-400">No orders match.</td></tr>
        )}
      </AdminTable>
    </div>
  );
}
