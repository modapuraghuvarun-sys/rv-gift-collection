'use client';

import Link from 'next/link';
import { useAdminData } from '@/components/admin/AdminShell';

export default function AdminCollectionsPage() {
  const { data } = useAdminData<{ products: { collections: string[] }[]; collections: { slug: string; name: string; featured: boolean }[] }>('/api/admin/products');
  if (!data) return <div className="skeleton h-64" />;

  return (
    <div className="space-y-5">
      <h1 className="font-display text-2xl text-burgundy-900">Collections</h1>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {data.collections.map((c) => {
          const count = data.products.filter((p) => p.collections.includes(c.slug)).length;
          return (
            <div key={c.slug} className="card p-5">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg text-burgundy-900">{c.name}</h2>
                {c.featured && <span className="badge-placeholder">Featured</span>}
              </div>
              <p className="mt-1 text-xs text-ink-400">/{c.slug} · {count} product{count !== 1 ? 's' : ''}</p>
              <Link href={`/collections?collection=${c.slug}`} className="mt-3 inline-block text-xs font-semibold text-burgundy-700 underline" target="_blank">
                View on storefront →
              </Link>
            </div>
          );
        })}
      </div>
      <p className="text-[11px] text-ink-400">
        Collections group products for discovery (Wedding Edit, Under ₹999, Corporate…). Managed here; products are assigned in Admin → Catalogue.
      </p>
    </div>
  );
}
