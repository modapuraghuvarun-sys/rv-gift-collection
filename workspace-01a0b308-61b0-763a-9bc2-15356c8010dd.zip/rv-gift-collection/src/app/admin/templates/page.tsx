'use client';

import { useState } from 'react';
import { useAdminData } from '@/components/admin/AdminShell';

interface TemplateRow {
  productId: string;
  product: string;
  template: {
    id: string;
    version: number;
    layout: string;
    fields: { key: string; label: string; required: boolean; maxLength: number }[];
    photos: { count: number; minPx: number };
    printArea: { w: number; h: number; shape: string };
  };
}

export default function AdminTemplatesPage() {
  const { data, reload } = useAdminData<{ templates: TemplateRow[] }>('/api/admin/templates');
  const [msg, setMsg] = useState('');

  if (!data) return <div className="skeleton h-64" />;

  async function bump(id: string) {
    setMsg('Publishing new version…');
    const res = await fetch(`/api/admin/templates/${id}/bump`, { method: 'POST' });
    const json = await res.json();
    setMsg(res.ok ? `Published ${id} → v${json.version}. Existing paid orders keep their approved version.` : 'Failed.');
    reload();
  }

  return (
    <div className="space-y-5">
      <h1 className="font-display text-2xl text-burgundy-900">Personalization Templates</h1>
      <p className="text-xs text-ink-400">
        Templates define required fields, character limits, photo counts, print dimensions and preview layout. Versioning
        is strict: paid orders retain the template version snapshotted at purchase.
      </p>
      <p className="text-xs text-ink-400" aria-live="polite">{msg}</p>
      <div className="grid gap-4 lg:grid-cols-2">
        {data.templates.map((t) => (
          <div key={t.template.id} className="card p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="text-sm font-bold text-ink-900">{t.product}</h2>
                <p className="mt-0.5 font-mono text-[11px] text-ink-400">
                  {t.template.id} · layout: {t.template.layout}
                </p>
              </div>
              <span className="rounded-full bg-burgundy-800 px-2.5 py-1 text-[11px] font-bold text-cream-50">v{t.template.version}</span>
            </div>
            <dl className="mt-3 grid grid-cols-2 gap-2 text-[11px] text-ink-500">
              <div><dt className="font-bold text-ink-700">Fields</dt><dd>{t.template.fields.map((f) => `${f.label}${f.required ? '*' : ''} (≤${f.maxLength})`).join(', ')}</dd></div>
              <div><dt className="font-bold text-ink-700">Photos</dt><dd>{t.template.photos.count > 0 ? `${t.template.photos.count} · min ${t.template.photos.minPx}px` : 'None (text only)'}</dd></div>
              <div><dt className="font-bold text-ink-700">Print area</dt><dd>{Math.round(t.template.printArea.w * 100)}% × {Math.round(t.template.printArea.h * 100)}% · {t.template.printArea.shape}</dd></div>
            </dl>
            <button className="btn-outline btn-sm mt-4" onClick={() => bump(t.template.id)}>
              Publish new version (v{t.template.version + 1})
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
