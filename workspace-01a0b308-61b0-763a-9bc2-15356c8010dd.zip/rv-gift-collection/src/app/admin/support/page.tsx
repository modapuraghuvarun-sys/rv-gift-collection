'use client';

import { AdminTable, StatusPill, useAdminData } from '@/components/admin/AdminShell';
import { formatINR } from '@/lib/money';
import { formatDateTime } from '@/lib/utils';

interface SupportData {
  tickets: { id: string; reference: string; createdAt: string; type: string; orderReference?: string; name: string; email: string; message: string; status: string }[];
}

export default function AdminSupportPage() {
  const { data, reload } = useAdminData<SupportData>('/api/admin/tickets');
  const { data: reports } = useAdminData<{ refunds: { list: { id: string; orderId: string; amount: number; reason: string; at: string; status: string }[] } }>('/api/admin/reports');

  if (!data) return <div className="skeleton h-64" />;

  async function setStatus(id: string, status: string) {
    await fetch(`/api/admin/tickets/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) });
    reload();
  }

  return (
    <div className="space-y-8">
      <h1 className="font-display text-2xl text-burgundy-900">Support & Refunds</h1>

      <section>
        <h2 className="mb-3 font-display text-lg text-burgundy-900">Support cases</h2>
        <AdminTable head={['Case', 'Type', 'Order', 'Customer', 'Message', 'Status']}>
          {data.tickets.map((t) => (
            <tr key={t.id} className="align-top hover:bg-cream-50/60">
              <td className="px-4 py-3">
                <p className="font-mono text-xs font-bold text-burgundy-800">{t.reference}</p>
                <p className="text-[11px] text-ink-400">{formatDateTime(t.createdAt)}</p>
              </td>
              <td className="px-4 py-3 text-xs capitalize">{t.type.replace(/-/g, ' ')}</td>
              <td className="px-4 py-3 font-mono text-xs">{t.orderReference ?? '—'}</td>
              <td className="px-4 py-3">
                <p className="text-xs font-semibold text-ink-900">{t.name}</p>
                <p className="text-[11px] text-ink-400">{t.email}</p>
              </td>
              <td className="max-w-xs px-4 py-3 text-xs text-ink-500">{t.message}</td>
              <td className="px-4 py-3">
                <select className="input w-36 py-1.5 text-[11px]" value={t.status} onChange={(e) => setStatus(t.id, e.target.value)} aria-label={`Set status for ${t.reference}`}>
                  <option value="open">open</option>
                  <option value="in_progress">in progress</option>
                  <option value="resolved">resolved</option>
                </select>
                <div className="mt-1.5"><StatusPill status={t.status} /></div>
              </td>
            </tr>
          ))}
          {data.tickets.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-sm text-ink-400">No support cases yet.</td></tr>}
        </AdminTable>
      </section>

      <section>
        <h2 className="mb-3 font-display text-lg text-burgundy-900">Refunds</h2>
        <AdminTable head={['Refund', 'Order', 'Amount', 'Reason', 'Initiated', 'Status']}>
          {(reports?.refunds.list ?? []).map((r) => (
            <tr key={r.id}>
              <td className="px-4 py-3 font-mono text-xs">{r.id.slice(0, 14)}…</td>
              <td className="px-4 py-3 text-xs">{r.orderId.slice(0, 10)}…</td>
              <td className="px-4 py-3 text-sm font-bold">{formatINR(r.amount)}</td>
              <td className="px-4 py-3 text-xs">{r.reason}</td>
              <td className="px-4 py-3 text-xs">{formatDateTime(r.at)}</td>
              <td className="px-4 py-3"><StatusPill status={r.status === 'initiated' ? 'in_progress' : 'resolved'} /></td>
            </tr>
          ))}
          {!reports?.refunds.list.length && <tr><td colSpan={6} className="px-4 py-8 text-center text-sm text-ink-400">No refunds initiated.</td></tr>}
        </AdminTable>
        <p className="mt-2 text-[11px] text-ink-400">Refunds reconcile through a background job; provider refund API plugs in here in production.</p>
      </section>
    </div>
  );
}
