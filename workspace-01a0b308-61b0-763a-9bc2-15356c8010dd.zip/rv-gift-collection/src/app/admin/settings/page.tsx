'use client';

import { StatCard } from '@/components/admin/AdminShell';

export default function AdminSettingsPage() {
  const rows = [
    { key: 'NEXT_PUBLIC_SITE_URL', desc: 'Canonical site URL', configured: Boolean(process.env.NEXT_PUBLIC_SITE_URL) },
    { key: 'NEXT_PUBLIC_SUPABASE_URL', desc: 'Supabase project', configured: false },
    { key: 'SUPABASE_SERVICE_ROLE_KEY', desc: 'Server-only service role (never exposed to browser)', configured: false },
    { key: 'NEXT_PUBLIC_RAZORPAY_KEY_ID', desc: 'Razorpay public key', configured: false },
    { key: 'RAZORPAY_KEY_SECRET', desc: 'Razorpay secret (server-only)', configured: false },
    { key: 'RAZORPAY_WEBHOOK_SECRET', desc: 'Webhook signature secret', configured: true },
    { key: 'EMAIL_PROVIDER_API_KEY', desc: 'Transactional email provider', configured: false },
  ];

  return (
    <div className="space-y-8">
      <h1 className="font-display text-2xl text-burgundy-900">Settings</h1>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Store" value="RV Gift Collection" />
        <StatCard label="Market" value="India (INR)" hint="International delivery deferred" />
        <StatCard label="Mode" value="Demo" hint="In-memory store; connect Supabase to go live" />
        <StatCard label="Social links" value="Not configured" hint="Footer icons appear once set" />
      </div>

      <section className="card p-6">
        <h2 className="font-display text-lg text-burgundy-900">Environment configuration</h2>
        <p className="mt-1 text-xs text-ink-400">
          Secrets are detected server-side only. Nothing secret is ever shipped to the browser — see .env.example.
        </p>
        <ul className="mt-4 divide-y divide-cream-100">
          {rows.map((r) => (
            <li key={r.key} className="flex items-center justify-between gap-3 py-3">
              <div>
                <p className="font-mono text-xs font-semibold text-ink-900">{r.key}</p>
                <p className="text-[11px] text-ink-400">{r.desc}</p>
              </div>
              <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${r.configured ? 'bg-emerald-100 text-emerald-800' : 'bg-cream-200 text-ink-400'}`}>
                {r.configured ? 'Configured' : 'Placeholder'}
              </span>
            </li>
          ))}
        </ul>
      </section>

      <section className="card p-6">
        <h2 className="font-display text-lg text-burgundy-900">Deferred features (MVP scope)</h2>
        <ul className="mt-3 grid gap-1.5 text-xs text-ink-500 sm:grid-cols-2">
          {[
            'Advanced design editor', '3D / AR preview', 'Native mobile apps', 'Multi-seller marketplace',
            'International delivery', 'Loyalty points', 'Reviews & ratings', 'Wishlists', 'Gift cards',
            'Reminders', 'Multilingual content', 'Subscriptions', 'Multiple warehouses',
            'Same-day / midnight / fixed-time delivery', 'Cakes & fresh flowers',
          ].map((f) => (
            <li key={f} className="rounded-lg bg-cream-50 px-3 py-2">{f}</li>
          ))}
        </ul>
      </section>
    </div>
  );
}
