'use client';

import { AdminTable, StatusPill, useAdminData } from '@/components/admin/AdminShell';
import { formatDateTime } from '@/lib/utils';

interface MiscData {
  audit: { id: string; at: string; actor: string; action: string; detail: string }[];
  emails: { id: string; to: string; template: string; subject: string; at: string }[];
}

interface JobsData {
  jobs: { id: string; type: string; state: string; attempts: number; maxAttempts: number; lastError?: string; createdAt: string }[];
}

export default function AdminStaffPage() {
  const { data: misc } = useAdminData<MiscData>('/api/admin/misc');
  const { data: jobs, reload: reloadJobs } = useAdminData<JobsData>('/api/admin/jobs');

  async function runJobs() {
    await fetch('/api/admin/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'run' }) });
    reloadJobs();
  }
  async function retry(id: string) {
    await fetch('/api/admin/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'retry', jobId: id }) });
    reloadJobs();
  }

  return (
    <div className="space-y-8">
      <h1 className="font-display text-2xl text-burgundy-900">Staff & Audit</h1>

      <section className="rounded-xl border border-gold-300 bg-gold-200/25 p-4 text-xs leading-relaxed text-ink-600">
        <strong>Production security model:</strong> Supabase Auth with enforced MFA · protected <code>staff_roles</code> table ·
        role-based row access · every mutation audited. The browser is untrusted — roles are always re-checked
        server-side from the session.
      </section>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-lg text-burgundy-900">Background jobs</h2>
          <button className="btn-outline btn-sm" onClick={runJobs}>Run due jobs now</button>
        </div>
        <AdminTable head={['Job', 'State', 'Attempts', 'Created', 'Last error', '']}>
          {(jobs?.jobs ?? []).map((j) => (
            <tr key={j.id}>
              <td className="px-4 py-3 font-mono text-xs">{j.type}</td>
              <td className="px-4 py-3"><StatusPill status={j.state} /></td>
              <td className="px-4 py-3 text-xs">{j.attempts}/{j.maxAttempts}</td>
              <td className="px-4 py-3 text-xs">{formatDateTime(j.createdAt)}</td>
              <td className="max-w-[220px] px-4 py-3 text-[11px] text-burgundy-600">{j.lastError ?? '—'}</td>
              <td className="px-4 py-3">
                {j.state === 'failed' && <button className="btn-outline btn-sm" onClick={() => retry(j.id)}>Retry</button>}
              </td>
            </tr>
          ))}
          {!jobs?.jobs.length && <tr><td colSpan={6} className="px-4 py-6 text-center text-sm text-ink-400">Queue empty.</td></tr>}
        </AdminTable>
      </section>

      <div className="grid gap-6 xl:grid-cols-2">
        <section>
          <h2 className="mb-3 font-display text-lg text-burgundy-900">Audit log</h2>
          <div className="card max-h-96 divide-y divide-cream-100 overflow-y-auto">
            {(misc?.audit ?? []).map((a) => (
              <div key={a.id} className="p-3.5">
                <p className="text-xs"><strong className="text-ink-900">{a.actor}</strong> · <span className="font-mono text-burgundy-700">{a.action}</span></p>
                <p className="mt-0.5 text-[11px] text-ink-500">{a.detail}</p>
                <p className="mt-0.5 text-[10px] text-ink-300">{formatDateTime(a.at)}</p>
              </div>
            ))}
            {!misc?.audit.length && <p className="p-6 text-sm text-ink-400">No entries yet.</p>}
          </div>
        </section>

        <section>
          <h2 className="mb-3 font-display text-lg text-burgundy-900">Email outbox (demo)</h2>
          <div className="card max-h-96 divide-y divide-cream-100 overflow-y-auto">
            {(misc?.emails ?? []).map((e) => (
              <div key={e.id} className="p-3.5">
                <p className="text-xs font-semibold text-ink-900">{e.subject}</p>
                <p className="mt-0.5 text-[11px] text-ink-500">to {e.to} · template <span className="font-mono">{e.template}</span></p>
                <p className="mt-0.5 text-[10px] text-ink-300">{formatDateTime(e.at)}</p>
              </div>
            ))}
            {!misc?.emails.length && <p className="p-6 text-sm text-ink-400">No emails sent yet. Production provider plugs in via background jobs.</p>}
          </div>
        </section>
      </div>
    </div>
  );
}
