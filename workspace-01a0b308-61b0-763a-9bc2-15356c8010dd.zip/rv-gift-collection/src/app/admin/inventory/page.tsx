'use client';

import { useState } from 'react';
import { AdminTable, useAdminData } from '@/components/admin/AdminShell';
import { formatDateTime } from '@/lib/utils';

interface InventoryData {
  stock: { sku: string; product: string; onHand: number; reserved: number; available: number }[];
  reservations: { id: string; items: { sku: string; qty: number }[]; status: string; createdAt: string; expiresAt: string; orderId?: string }[];
  adjustments: { id: string; sku: string; delta: number; reason: string; at: string; by: string }[];
}

export default function AdminInventoryPage() {
  const { data, reload } = useAdminData<InventoryData>('/api/admin/inventory');
  const [sku, setSku] = useState('');
  const [delta, setDelta] = useState('1');
  const [reason, setReason] = useState('restock');
  const [msg, setMsg] = useState('');

  if (!data) return <div className="skeleton h-64" />;

  async function adjust(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch('/api/admin/inventory/adjust', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sku, delta: Number(delta), reason }),
    });
    const json = await res.json();
    setMsg(res.ok ? 'Adjustment saved.' : json.message ?? 'Adjustment failed.');
    reload();
  }

  return (
    <div className="space-y-8">
      <h1 className="font-display text-2xl text-burgundy-900">Inventory</h1>

      <section>
        <h2 className="mb-3 font-display text-lg text-burgundy-900">Stock levels</h2>
        <AdminTable head={['SKU', 'Product', 'On hand', 'Reserved', 'Available', '']}>
          {data.stock.map((s) => (
            <tr key={s.sku} className="hover:bg-cream-50/60">
              <td className="px-4 py-3 font-mono text-xs text-ink-500">{s.sku}</td>
              <td className="px-4 py-3 text-sm font-semibold text-ink-900">{s.product}</td>
              <td className="px-4 py-3">{s.onHand}</td>
              <td className="px-4 py-3">{s.reserved}</td>
              <td className={`px-4 py-3 font-bold ${s.available <= 3 ? 'text-burgundy-600' : 'text-emerald-700'}`}>{s.available}</td>
              <td className="px-4 py-3">
                <button className="text-xs font-semibold text-burgundy-700 underline" onClick={() => setSku(s.sku)}>Adjust</button>
              </td>
            </tr>
          ))}
        </AdminTable>
        <p className="mt-2 text-[11px] text-ink-400">Available = on hand − reserved. Reservations expire automatically; expired stock returns to the pool.</p>
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <form onSubmit={adjust} className="card h-fit space-y-3 p-5">
          <h2 className="font-display text-lg text-burgundy-900">Stock adjustment</h2>
          <div>
            <label className="label" htmlFor="adj-sku">SKU</label>
            <select id="adj-sku" className="input" value={sku} onChange={(e) => setSku(e.target.value)}>
              <option value="">Choose…</option>
              {data.stock.map((s) => <option key={s.sku} value={s.sku}>{s.sku} — {s.product}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label" htmlFor="adj-delta">Delta (+/−)</label>
              <input id="adj-delta" className="input" inputMode="numeric" value={delta} onChange={(e) => setDelta(e.target.value.replace(/[^\d-]/g, ''))} />
            </div>
            <div>
              <label className="label" htmlFor="adj-reason">Reason</label>
              <select id="adj-reason" className="input" value={reason} onChange={(e) => setReason(e.target.value)}>
                <option value="restock">Restock</option>
                <option value="damage">Damaged stock</option>
                <option value="correction">Correction</option>
                <option value="write-off">Write-off</option>
              </select>
            </div>
          </div>
          {msg && <p className="text-xs font-medium text-burgundy-700" aria-live="polite">{msg}</p>}
          <button className="btn-primary btn-md" disabled={!sku}>Apply adjustment</button>
        </form>

        <div className="card p-5">
          <h2 className="font-display text-lg text-burgundy-900">Recent adjustments</h2>
          <ul className="mt-3 space-y-2">
            {data.adjustments.length === 0 && <li className="text-xs text-ink-400">None yet.</li>}
            {data.adjustments.map((a) => (
              <li key={a.id} className="flex items-center justify-between gap-2 rounded-lg bg-cream-50 px-3 py-2 text-xs">
                <span className="font-mono text-ink-500">{a.sku}</span>
                <span className={`font-bold ${a.delta > 0 ? 'text-emerald-700' : 'text-burgundy-600'}`}>{a.delta > 0 ? '+' : ''}{a.delta}</span>
                <span className="text-ink-500">{a.reason}</span>
                <span className="text-ink-400">{formatDateTime(a.at)}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section>
        <h2 className="mb-3 font-display text-lg text-burgundy-900">Reservation history</h2>
        <AdminTable head={['Reservation', 'Items', 'Status', 'Created', 'Expires', 'Order']}>
          {data.reservations.map((r) => (
            <tr key={r.id} className="hover:bg-cream-50/60">
              <td className="px-4 py-3 font-mono text-xs">{r.id.slice(0, 12)}…</td>
              <td className="px-4 py-3 text-xs">{r.items.map((i) => `${i.sku} ×${i.qty}`).join(', ')}</td>
              <td className="px-4 py-3"><span className="rounded-full bg-cream-200 px-2.5 py-0.5 text-[11px] font-bold text-ink-500">{r.status}</span></td>
              <td className="px-4 py-3 text-xs">{formatDateTime(r.createdAt)}</td>
              <td className="px-4 py-3 text-xs">{formatDateTime(r.expiresAt)}</td>
              <td className="px-4 py-3 text-xs">{r.orderId ? '✓ allocated' : '—'}</td>
            </tr>
          ))}
          {data.reservations.length === 0 && (
            <tr><td colSpan={6} className="px-4 py-6 text-center text-sm text-ink-400">No reservations yet.</td></tr>
          )}
        </AdminTable>
      </section>
    </div>
  );
}
