'use client';

import Link from 'next/link';
import { useState } from 'react';
import { StatusPill, useAdminData } from '@/components/admin/AdminShell';
import { formatDateTime } from '@/lib/utils';

interface ProductionOrder {
  id: string;
  reference: string;
  status: string;
  createdAt: string;
  recipient: { name: string; phone?: string };
  items: {
    name: string;
    sku: string;
    qty: number;
    personalisation?: { fields: Record<string, string>; textColor: string; crop: { scale: number }; assetIds: string[]; previewThumb?: string; templateVersion: number };
  }[];
}

const QUEUE_STATUSES = ['CONFIRMED', 'PERSONALISATION_REVIEW', 'IN_PRODUCTION', 'QUALITY_CHECKED', 'PACKED'];

export default function AdminProductionPage() {
  const { data, reload } = useAdminData<{ orders: ProductionOrder[] }>('/api/admin/orders');
  const [msg, setMsg] = useState('');
  if (!data) return <div className="skeleton h-64" />;

  const queue = data.orders.filter((o) => QUEUE_STATUSES.includes(o.status));

  async function advance(o: ProductionOrder, status: string, note: string) {
    const res = await fetch(`/api/admin/orders/${o.id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, note }),
    });
    setMsg(res.ok ? `${o.reference} → ${status.replace(/_/g, ' ')}` : 'Update failed.');
    reload();
  }

  return (
    <div className="space-y-5">
      <h1 className="font-display text-2xl text-burgundy-900">Production</h1>
      <div className="rounded-xl border border-gold-300 bg-gold-200/25 p-4 text-xs leading-relaxed text-ink-600">
        <strong>Least privilege:</strong> production staff see only the artwork files and recipient info required for
        each job. Customer photo assets open via short-lived signed links and expire automatically. Template version
        shown is the one approved by the customer at purchase.
      </div>
      <p className="text-xs text-ink-400" aria-live="polite">{msg}</p>

      <div className="grid gap-4 xl:grid-cols-2">
        {queue.map((o) => (
          <div key={o.id} className="card p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-bold text-ink-900">{o.reference}</p>
                <p className="text-[11px] text-ink-400">Placed {formatDateTime(o.createdAt)} · for {o.recipient.name}</p>
              </div>
              <StatusPill status={o.status} />
            </div>

            <ul className="mt-4 space-y-3">
              {o.items.map((it, i) => (
                <li key={i} className="rounded-xl bg-cream-50 p-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-sm font-semibold text-ink-900">{it.name} <span className="text-xs text-ink-400">× {it.qty} · {it.sku}</span></p>
                    {it.personalisation && <span className="rounded-full bg-burgundy-100 px-2 py-0.5 text-[10px] font-bold text-burgundy-800">template v{it.personalisation.templateVersion}</span>}
                  </div>
                  {it.personalisation && (
                    <div className="mt-2 grid gap-3 sm:grid-cols-[120px_1fr]">
                      {it.personalisation.previewThumb && (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={it.personalisation.previewThumb} alt="Approved design preview" className="h-[120px] w-[120px] rounded-lg border border-cream-200 object-cover" />
                      )}
                      <div className="text-[11px] leading-relaxed text-ink-500">
                        {Object.entries(it.personalisation.fields).filter(([, v]) => v).map(([k, v]) => (
                          <p key={k}><b className="capitalize text-ink-700">{k}:</b> {v}</p>
                        ))}
                        <p><b className="text-ink-700">Text colour:</b> {it.personalisation.textColor}</p>
                        {it.personalisation.assetIds.length > 0 && (
                          <p className="mt-1">
                            <b className="text-ink-700">Hi-res photos:</b>{' '}
                            {it.personalisation.assetIds.map((a, j) => (
                              <Link key={a} href={`/api/uploads/${a}/file`} className="mr-2 text-burgundy-700 underline" target="_blank" rel="noopener">
                                asset {j + 1} ↗
                              </Link>
                            ))}
                            <span className="text-ink-400">(staff-only signed access)</span>
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </li>
              ))}
            </ul>

            <div className="mt-4 flex flex-wrap gap-2">
              {o.status === 'CONFIRMED' && (
                <button className="btn-primary btn-sm" onClick={() => advance(o, 'PERSONALISATION_REVIEW', 'Artwork review started')}>Start artwork review</button>
              )}
              {o.status === 'PERSONALISATION_REVIEW' && (
                <>
                  <button className="btn-primary btn-sm" onClick={() => advance(o, 'IN_PRODUCTION', 'Artwork approved; production started')}>Approve & start production</button>
                  <button className="btn-outline btn-sm" onClick={() => advance(o, 'CORRECTION_HOLD', 'Correction requested from customer')}>Request correction</button>
                </>
              )}
              {o.status === 'IN_PRODUCTION' && (
                <button className="btn-primary btn-sm" onClick={() => advance(o, 'QUALITY_CHECKED', 'Production complete; quality check passed')}>QC passed</button>
              )}
              {o.status === 'QUALITY_CHECKED' && (
                <button className="btn-primary btn-sm" onClick={() => advance(o, 'PACKED', 'Packed and ready for pickup')}>Mark packed</button>
              )}
              {o.status === 'PACKED' && <p className="text-xs font-semibold text-emerald-700">Ready for dispatch — see Delivery.</p>}
            </div>
          </div>
        ))}
        {queue.length === 0 && <p className="text-sm text-ink-400">Production queue is empty. Confirmed paid orders appear here automatically.</p>}
      </div>
    </div>
  );
}
