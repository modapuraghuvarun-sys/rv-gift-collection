'use client';

import { useState } from 'react';
import { AdminTable, useAdminData } from '@/components/admin/AdminShell';
import { formatINR } from '@/lib/money';
import { formatDate } from '@/lib/utils';
import type { Coupon } from '@/lib/types';

export default function AdminPromotionsPage() {
  const { data, reload } = useAdminData<{ coupons: Coupon[] }>('/api/admin/coupons');
  const [form, setForm] = useState({ code: '', kind: 'flat', value: '', minSubtotal: '', expiresAt: '', usageLimit: '1000', perCustomerLimit: '1', description: '' });
  const [msg, setMsg] = useState('');

  if (!data) return <div className="skeleton h-64" />;

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setMsg('Saving…');
    const res = await fetch('/api/admin/coupons', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        code: form.code,
        kind: form.kind,
        value: form.kind === 'flat' ? Number(form.value) * 100 : Number(form.value),
        minSubtotal: Number(form.minSubtotal || 0) * 100,
        expiresAt: form.expiresAt || undefined,
        usageLimit: Number(form.usageLimit || 1000),
        perCustomerLimit: Number(form.perCustomerLimit || 1),
        description: form.description,
        active: true,
      }),
    });
    setMsg(res.ok ? 'Coupon saved. Enforcement is server-side: expiry, minimum order, usage and per-customer limits.' : 'Save failed.');
    reload();
  }

  return (
    <div className="space-y-8">
      <h1 className="font-display text-2xl text-burgundy-900">Promotions</h1>
      <p className="text-xs text-ink-400" aria-live="polite">{msg}</p>

      <section>
        <h2 className="mb-3 font-display text-lg text-burgundy-900">Coupons</h2>
        <AdminTable head={['Code', 'Discount', 'Min order', 'Window', 'Usage', 'Per customer', 'Status']}>
          {data.coupons.map((c) => (
            <tr key={c.code}>
              <td className="px-4 py-3 font-mono text-sm font-bold text-burgundy-800">{c.code}</td>
              <td className="px-4 py-3 text-xs">{c.kind === 'flat' ? formatINR(c.value) : `${c.value}%${c.maxDiscount ? ` (cap ${formatINR(c.maxDiscount)})` : ''}`}</td>
              <td className="px-4 py-3 text-xs">{c.minSubtotal ? formatINR(c.minSubtotal) : '—'}</td>
              <td className="px-4 py-3 text-xs">{formatDate(c.startsAt)} → {formatDate(c.expiresAt)}</td>
              <td className="px-4 py-3 text-xs">{c.redeemed} / {c.usageLimit}</td>
              <td className="px-4 py-3 text-xs">{c.perCustomerLimit}</td>
              <td className="px-4 py-3">
                <span className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${c.active && new Date(c.expiresAt) > new Date() ? 'bg-emerald-100 text-emerald-800' : 'bg-cream-200 text-ink-400'}`}>
                  {c.active && new Date(c.expiresAt) > new Date() ? 'Active' : 'Inactive/expired'}
                </span>
              </td>
            </tr>
          ))}
        </AdminTable>
      </section>

      <form onSubmit={save} className="card grid max-w-3xl gap-4 p-6 sm:grid-cols-2">
        <h2 className="font-display text-lg text-burgundy-900 sm:col-span-2">Create / update coupon</h2>
        <div><label className="label" htmlFor="cp-code">Code</label><input id="cp-code" className="input uppercase" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} required /></div>
        <div>
          <label className="label" htmlFor="cp-kind">Type</label>
          <select id="cp-kind" className="input" value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
            <option value="flat">Flat (₹)</option>
            <option value="percent">Percent (%)</option>
          </select>
        </div>
        <div><label className="label" htmlFor="cp-value">{form.kind === 'flat' ? 'Amount (₹)' : 'Percent (%)'}</label><input id="cp-value" className="input" inputMode="numeric" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} required /></div>
        <div><label className="label" htmlFor="cp-min">Minimum order (₹)</label><input id="cp-min" className="input" inputMode="numeric" value={form.minSubtotal} onChange={(e) => setForm({ ...form, minSubtotal: e.target.value })} /></div>
        <div><label className="label" htmlFor="cp-exp">Expiry date</label><input id="cp-exp" type="date" className="input" value={form.expiresAt} onChange={(e) => setForm({ ...form, expiresAt: e.target.value })} /></div>
        <div><label className="label" htmlFor="cp-limit">Usage limit</label><input id="cp-limit" className="input" inputMode="numeric" value={form.usageLimit} onChange={(e) => setForm({ ...form, usageLimit: e.target.value })} /></div>
        <div><label className="label" htmlFor="cp-per">Per-customer limit</label><input id="cp-per" className="input" inputMode="numeric" value={form.perCustomerLimit} onChange={(e) => setForm({ ...form, perCustomerLimit: e.target.value })} /></div>
        <div><label className="label" htmlFor="cp-desc">Description</label><input id="cp-desc" className="input" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
        <button className="btn-primary btn-md sm:col-span-2">Save coupon</button>
      </form>
    </div>
  );
}
