'use client';

import { useAdminData } from '@/components/admin/AdminShell';

interface MiscData {
  contentPlaceholders: { key: string; label: string; location: string; status: string }[];
  uploads: { id: string; status: string; size: number; width: number; height: number; url: string }[];
}

export default function AdminContentPage() {
  const { data } = useAdminData<MiscData>('/api/admin/misc');
  if (!data) return <div className="skeleton h-64" />;

  return (
    <div className="space-y-8">
      <h1 className="font-display text-2xl text-burgundy-900">Content</h1>

      <section>
        <h2 className="mb-3 font-display text-lg text-burgundy-900">Owner-supplied content placeholders</h2>
        <p className="mb-4 text-xs text-ink-400">
          Per the content policy we never invent testimonials, reviews, sales figures, contact details or business legal
          details. These slots wait for real owner-supplied content:
        </p>
        <div className="grid gap-4 md:grid-cols-2">
          {data.contentPlaceholders.map((p) => (
            <div key={p.key} className="card p-5">
              <p className="badge-placeholder mb-2">Awaiting owner</p>
              <h3 className="text-sm font-bold text-ink-900">{p.label}</h3>
              <p className="mt-1 text-xs text-ink-500">Location: {p.location}</p>
              <p className="mt-0.5 text-[11px] text-ink-400 capitalize">Status: {p.status}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="mb-3 font-display text-lg text-burgundy-900">Private customer uploads</h2>
        <p className="mb-4 text-xs text-ink-400">
          Stored privately (bucket <code>customer-uploads</code>). Links below are short-lived signed URLs — they expire
          in 5 minutes and require a staff session. Object paths are opaque ids; no names, addresses or emails.
        </p>
        {data.uploads.length === 0 ? (
          <p className="text-sm text-ink-400">No uploads yet.</p>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            {data.uploads.map((u) => (
              <li key={u.id} className="card p-4">
                <p className="font-mono text-[11px] text-ink-500">{u.id}</p>
                <p className="mt-1 text-xs text-ink-500">{u.width}×{u.height} · {(u.size / 1024).toFixed(0)} KB · {u.status}</p>
                <a href={u.url} target="_blank" rel="noopener" className="mt-2 inline-block text-xs font-semibold text-burgundy-700 underline">
                  Open signed link (5 min) ↗
                </a>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
