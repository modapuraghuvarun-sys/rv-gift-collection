'use client';

import { useState } from 'react';
import { AdminTable, StatusPill, useAdminData } from '@/components/admin/AdminShell';
import { formatINR } from '@/lib/money';

interface AdminProduct {
  id: string;
  slug: string;
  name: string;
  category: string;
  status: string;
  featured: boolean;
  leadTimeDays: number;
  personalisable: boolean;
  variants: { id: string; sku: string; name: string; price: number; available: boolean; onHand: number; reserved: number; availableCount: number }[];
}

export default function AdminCataloguePage() {
  const { data, reload } = useAdminData<{ products: AdminProduct[] }>('/api/admin/products');
  const [filter, setFilter] = useState('all');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [msg, setMsg] = useState('');

  if (!data) return <div className="skeleton h-64" />;

  const products = data.products.filter((p) => filter === 'all' || p.status === filter);

  async function patch(id: string, body: Record<string, unknown>) {
    setMsg('Saving…');
    const res = await fetch(`/api/admin/products/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    setMsg(res.ok ? 'Saved.' : 'Save failed.');
    reload();
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-2xl text-burgundy-900">Catalogue & Products</h1>
        <div className="flex items-center gap-2">
          {['all', 'draft', 'published', 'archived'].map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`rounded-full px-3 py-1.5 text-xs font-semibold ${filter === s ? 'bg-burgundy-800 text-cream-50' : 'bg-white text-ink-500'}`}
            >
              {s[0].toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
      </div>
      <p className="text-xs text-ink-400" aria-live="polite">{msg}</p>

      <AdminTable head={['Product', 'Category', 'Status', 'Lead time', 'Featured', 'Variants / stock', 'Actions']}>
        {products.map((p) => (
          <tr key={p.id} className="align-top hover:bg-cream-50/60">
            <td className="px-4 py-3">
              <p className="font-semibold text-ink-900">{p.name}</p>
              <p className="text-[11px] text-ink-400">/{p.slug}{p.personalisable ? ' · personalizable' : ''}</p>
            </td>
            <td className="px-4 py-3 capitalize text-ink-500">{p.category.replace(/-/g, ' ')}</td>
            <td className="px-4 py-3"><StatusPill status={p.status} /></td>
            <td className="px-4 py-3 text-ink-500">{p.leadTimeDays}d</td>
            <td className="px-4 py-3">
              <button
                onClick={() => patch(p.id, { featured: !p.featured })}
                className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${p.featured ? 'bg-gold-300 text-burgundy-950' : 'bg-cream-200 text-ink-400'}`}
              >
                {p.featured ? 'Featured' : '—'}
              </button>
            </td>
            <td className="px-4 py-3">
              <button className="text-xs font-semibold text-burgundy-700 underline" onClick={() => setExpanded(expanded === p.id ? null : p.id)}>
                {p.variants.length} variant{p.variants.length > 1 ? 's' : ''}
              </button>
              {expanded === p.id && (
                <ul className="mt-2 space-y-1.5 rounded-lg bg-cream-50 p-3">
                  {p.variants.map((v) => (
                    <li key={v.id} className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <span className="font-mono text-ink-500">{v.sku}</span>
                      <span className="text-ink-700">{v.name}</span>
                      <span className="font-semibold">{formatINR(v.price)}</span>
                      <span className={v.availableCount > 0 ? 'text-emerald-700' : 'text-burgundy-600'}>
                        {v.onHand} on hand · {v.reserved} reserved · {v.availableCount} avail.
                      </span>
                      <button
                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${v.available ? 'bg-emerald-100 text-emerald-800' : 'bg-burgundy-100 text-burgundy-800'}`}
                        onClick={() => patch(p.id, { variantId: v.id, variantAvailable: !v.available })}
                      >
                        {v.available ? 'Mark unavailable' : 'Mark available'}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </td>
            <td className="px-4 py-3">
              <div className="flex flex-col gap-1.5">
                <button className="btn-outline btn-sm" onClick={() => patch(p.id, { status: 'published' })} disabled={p.status === 'published'}>Publish</button>
                <button className="btn-ghost btn-sm" onClick={() => patch(p.id, { status: 'draft' })} disabled={p.status === 'draft'}>Draft</button>
                <button className="btn-ghost btn-sm" onClick={() => patch(p.id, { status: 'archived' })} disabled={p.status === 'archived'}>Archive</button>
              </div>
            </td>
          </tr>
        ))}
      </AdminTable>
      <p className="text-[11px] text-ink-400">
        Archived products stay linked to historical orders through purchase-time snapshots — they simply disappear from the storefront.
      </p>
    </div>
  );
}
