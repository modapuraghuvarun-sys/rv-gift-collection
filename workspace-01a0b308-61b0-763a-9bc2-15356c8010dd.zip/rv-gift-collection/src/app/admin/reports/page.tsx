'use client';

import { StatCard, StatusPill, useAdminData } from '@/components/admin/AdminShell';
import { formatINR } from '@/lib/money';

interface Reports {
  paidOrders: number;
  paidSales: number;
  discounts: number;
  taxIncluded: number;
  shippingCollected: number;
  refunds: { count: number; total: number };
  statusCounts: Record<string, number>;
  fulfilment: { total: number; fulfilled: number };
  lowStock: { sku: string; available: number }[];
  couponRedemptions: number;
  emailsSent: number;
}

export default function AdminReportsPage() {
  const { data } = useAdminData<Reports>('/api/admin/reports');
  if (!data) return <div className="skeleton h-64" />;

  return (
    <div className="space-y-8">
      <h1 className="font-display text-2xl text-burgundy-900">Reports</h1>
      <div className="rounded-xl border border-gold-300 bg-gold-200/25 p-4 text-xs text-ink-600">
        Factual metrics only. Profit is intentionally <strong>not</strong> calculated until actual material, packaging,
        shipping and gateway costs are recorded.
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Paid sales" value={formatINR(data.paidSales)} tone="good" />
        <StatCard label="Paid orders" value={data.paidOrders} />
        <StatCard label="Discounts given" value={formatINR(data.discounts)} />
        <StatCard label="Tax included (GST)" value={formatINR(data.taxIncluded)} />
        <StatCard label="Shipping collected" value={formatINR(data.shippingCollected)} />
        <StatCard label="Refunds" value={`${data.refunds.count} · ${formatINR(data.refunds.total)}`} tone={data.refunds.count ? 'warn' : 'default'} />
        <StatCard label="Coupon redemptions" value={data.couponRedemptions} />
        <StatCard label="Transactional emails" value={data.emailsSent} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card p-6">
          <h2 className="font-display text-lg text-burgundy-900">Order status breakdown</h2>
          <ul className="mt-4 space-y-2">
            {Object.entries(data.statusCounts).map(([status, count]) => (
              <li key={status} className="flex items-center justify-between gap-3">
                <StatusPill status={status} />
                <span className="text-sm font-bold">{count}</span>
              </li>
            ))}
            {Object.keys(data.statusCounts).length === 0 && <li className="text-sm text-ink-400">No orders yet.</li>}
          </ul>
        </section>

        <section className="card p-6">
          <h2 className="font-display text-lg text-burgundy-900">Fulfilment & stock health</h2>
          <p className="mt-3 text-sm text-ink-500">
            {data.fulfilment.fulfilled} of {data.fulfilment.total} orders shipped or delivered.
          </p>
          <h3 className="label mt-5">Low stock (≤ 3 available)</h3>
          <ul className="mt-2 space-y-1.5">
            {data.lowStock.map((s) => (
              <li key={s.sku} className="flex justify-between rounded-lg bg-cream-50 px-3 py-2 text-xs">
                <span className="font-mono text-ink-500">{s.sku}</span>
                <span className="font-bold text-burgundy-600">{s.available} left</span>
              </li>
            ))}
            {data.lowStock.length === 0 && <li className="text-xs text-ink-400">All SKUs healthy.</li>}
          </ul>
        </section>
      </div>
    </div>
  );
}
