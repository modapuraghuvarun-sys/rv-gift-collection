'use client';

import { useState } from 'react';
import { AdminTable, useAdminData } from '@/components/admin/AdminShell';
import { formatINR } from '@/lib/money';

interface Rules {
  rules: {
    zones: { id: string; name: string; pinPrefixes: string[]; transitDays: [number, number]; fee: number; expressFee?: number }[];
    unsupportedPins: string[];
    cutoffHour: number;
    businessDays: number[];
    capacityPerDay: number;
    freeStandardAbove: number;
  };
  bookings: Record<string, number>;
}

export default function AdminDeliveryPage() {
  const { data, reload } = useAdminData<Rules>('/api/admin/delivery-rules');
  const [msg, setMsg] = useState('');
  const [newPin, setNewPin] = useState('');
  if (!data) return <div className="skeleton h-64" />;

  async function patch(body: Record<string, unknown>) {
    setMsg('Saving…');
    const res = await fetch('/api/admin/delivery-rules', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    setMsg(res.ok ? 'Saved.' : 'Save failed.');
    reload();
  }

  return (
    <div className="space-y-8">
      <h1 className="font-display text-2xl text-burgundy-900">Delivery</h1>
      <p className="text-xs text-ink-400" aria-live="polite">{msg}</p>

      <section>
        <h2 className="mb-3 font-display text-lg text-burgundy-900">Zones, fees & transit</h2>
        <AdminTable head={['Zone', 'PIN prefixes', 'Transit (days)', 'Standard fee', 'Express fee', '']}>
          {data.rules.zones.map((z) => (
            <tr key={z.id}>
              <td className="px-4 py-3 text-sm font-semibold text-ink-900">{z.name}</td>
              <td className="px-4 py-3 text-xs text-ink-500">{z.pinPrefixes.join(', ') || '—'}</td>
              <td className="px-4 py-3 text-xs">{z.transitDays[0]}–{z.transitDays[1]}</td>
              <td className="px-4 py-3 text-xs">{formatINR(z.fee)}</td>
              <td className="px-4 py-3 text-xs">{z.expressFee !== undefined ? formatINR(z.expressFee) : 'Not offered'}</td>
              <td className="px-4 py-3">
                <button
                  className="text-xs font-semibold text-burgundy-700 underline"
                  onClick={() => {
                    const fee = window.prompt(`New standard fee (paise) for ${z.name}:`, String(z.fee));
                    if (fee) patch({ zoneId: z.id, fee: Number(fee) });
                  }}
                >
                  Edit fee
                </button>
              </td>
            </tr>
          ))}
        </AdminTable>
      </section>

      <section className="grid gap-6 lg:grid-cols-2">
        <div className="card space-y-4 p-5">
          <h2 className="font-display text-lg text-burgundy-900">Business calendar & capacity</h2>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="label">Cut-off hour (IST)</p>
              <input
                type="number" min={0} max={23} defaultValue={data.rules.cutoffHour}
                className="input"
                onBlur={(e) => patch({ cutoffHour: Number(e.target.value) })}
                aria-label="Cut-off hour"
              />
              <p className="mt-1 text-[11px] text-ink-400">Orders after this hour start production next business day.</p>
            </div>
            <div>
              <p className="label">Daily capacity</p>
              <input
                type="number" min={1} defaultValue={data.rules.capacityPerDay}
                className="input"
                onBlur={(e) => patch({ capacityPerDay: Number(e.target.value) })}
                aria-label="Daily capacity"
              />
              <p className="mt-1 text-[11px] text-ink-400">Full days push the estimate forward automatically.</p>
            </div>
          </div>
          <p className="text-[11px] text-ink-400">Business days: Mon–Sat · Free standard delivery above {formatINR(data.rules.freeStandardAbove)}.</p>
          {Object.keys(data.bookings).length > 0 && (
            <div>
              <p className="label">Capacity bookings</p>
              <ul className="space-y-1 text-xs text-ink-500">
                {Object.entries(data.bookings).map(([d, n]) => (
                  <li key={d}>{d}: {n} booked</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="card p-5">
          <h2 className="font-display text-lg text-burgundy-900">Unsupported PIN codes</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {data.rules.unsupportedPins.map((p) => (
              <button key={p} className="chip" onClick={() => patch({ removeUnsupportedPin: p })} title="Remove block">
                {p} ✕
              </button>
            ))}
            {data.rules.unsupportedPins.length === 0 && <p className="text-xs text-ink-400">None blocked.</p>}
          </div>
          <form
            className="mt-4 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (newPin) patch({ addUnsupportedPin: newPin });
              setNewPin('');
            }}
          >
            <input className="input" placeholder="PIN or prefix (e.g. 799)" value={newPin} onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 6))} aria-label="Add unsupported PIN" />
            <button className="btn-outline btn-sm shrink-0">Block</button>
          </form>
        </div>
      </section>

      <section>
        <h2 className="mb-2 font-display text-lg text-burgundy-900">Tracking information</h2>
        <p className="text-xs leading-relaxed text-ink-500">
          Courier and AWB details are added from Admin → Orders when a packed order ships. The customer timeline updates
          and a dispatch email job is queued automatically. Courier API sync (tracking events) runs as a background job.
        </p>
      </section>
    </div>
  );
}
