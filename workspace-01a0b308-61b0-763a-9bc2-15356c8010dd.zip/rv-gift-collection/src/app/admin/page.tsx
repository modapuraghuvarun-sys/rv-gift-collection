'use client';

import Link from 'next/link';
import { StatCard, StatusPill, useAdminData } from '@/components/admin/AdminShell';
import { formatINR } from '@/lib/money';
import { formatDateTime } from '@/lib/utils';

interface Overview {
  cards: {
    paidAwaitingAction: number;
    onHold: number;
    overdueProduction: number;
    lowStock: number;
    pendingPayments: number;
    refundExceptions: number;
    failedJobs: number;
  };
  recentOrders: { id: string; reference: string; createdAt: string; status: string; total: number; buyer: string }[];
  jobs: { id: string; type: string; state: string; attempts: number; lastError?: string; createdAt: string }[];
}

export default function AdminDashboardPage() {
  const { data, error, reload } = useAdminData<Overview>('/api/admin/overview');

  if (error) return <p className="text-sm text-burgundy-700">{error} <button className="underline" onClick={reload}>Retry</button></p>;
  if (!data) return <div className="skeleton h-64" />;

  const c = data.cards;
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl text-burgundy-900">Dashboard</h1>
        <button className="btn-outline btn-sm" onClick={reload}>Refresh</button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Paid orders awaiting action" value={c.paidAwaitingAction} tone={c.paidAwaitingAction ? 'warn' : 'good'} />
        <StatCard label="Orders on hold" value={c.onHold} tone={c.onHold ? 'warn' : 'good'} />
        <StatCard label="Overdue production jobs" value={c.overdueProduction} tone={c.overdueProduction ? 'danger' : 'good'} />
        <StatCard label="Low-stock products" value={c.lowStock} tone={c.lowStock ? 'warn' : 'default'} hint="≤ 3 available" />
        <StatCard label="Pending payments" value={c.pendingPayments} />
        <StatCard label="Refund exceptions" value={c.refundExceptions} tone={c.refundExceptions ? 'danger' : 'good'} />
        <StatCard label="Failed background jobs" value={c.failedJobs} tone={c.failedJobs ? 'danger' : 'good'} />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_380px]">
        <section>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-lg text-burgundy-900">Recent orders</h2>
            <Link href="/admin/orders" className="text-xs font-semibold text-burgundy-700 underline">All orders →</Link>
          </div>
          <div className="card divide-y divide-cream-100">
            {data.recentOrders.length === 0 && <p className="p-6 text-sm text-ink-400">No orders yet.</p>}
            {data.recentOrders.map((o) => (
              <div key={o.id} className="flex items-center justify-between gap-3 p-4">
                <div>
                  <p className="text-sm font-bold text-ink-900">{o.reference}</p>
                  <p className="text-xs text-ink-400">{o.buyer} · {formatDateTime(o.createdAt)}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold">{formatINR(o.total)}</span>
                  <StatusPill status={o.status} />
                </div>
              </div>
            ))}
          </div>
        </section>

        <section>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-lg text-burgundy-900">Job queue</h2>
            <Link href="/admin/staff" className="text-xs font-semibold text-burgundy-700 underline">Manage →</Link>
          </div>
          <div className="card divide-y divide-cream-100">
            {data.jobs.slice(0, 8).map((j) => (
              <div key={j.id} className="flex items-center justify-between gap-2 p-3.5">
                <div className="min-w-0">
                  <p className="truncate text-xs font-semibold text-ink-900">{j.type}</p>
                  <p className="text-[11px] text-ink-400">{formatDateTime(j.createdAt)} · attempt {j.attempts}</p>
                </div>
                <StatusPill status={j.state} />
              </div>
            ))}
            {data.jobs.length === 0 && <p className="p-6 text-sm text-ink-400">Queue is empty.</p>}
          </div>
        </section>
      </div>
    </div>
  );
}
