import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { ChevronRight, RotateCcw, ShieldCheck, Sparkles } from 'lucide-react';
import { store } from '@/lib/store';
import { categories } from '@/lib/data/catalog';
import { formatINR } from '@/lib/money';
import { ProductPageClient } from '@/components/product/ProductPageClient';

export const dynamic = 'force-dynamic';

interface Props {
  params: { slug: string };
}

export function generateMetadata({ params }: Props): Metadata {
  const product = store.products.find((p) => p.slug === params.slug && p.status === 'published');
  if (!product) return { title: 'Gift not found' };
  const price = Math.min(...product.variants.filter((v) => v.available).map((v) => v.price));
  return {
    title: product.name,
    description: product.shortDescription,
    alternates: { canonical: `/product/${product.slug}` },
    openGraph: { images: [{ url: product.images[0], width: 900, height: 900, alt: product.name }] },
  };
}

export default function ProductPage({ params }: Props) {
  const product = store.products.find((p) => p.slug === params.slug);
  if (!product || product.status !== 'published') notFound();

  const category = categories.find((c) => c.slug === product.category);
  const minPrice = Math.min(...product.variants.map((v) => v.price));

  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.name,
    description: product.shortDescription,
    image: product.images.map((i) => `${process.env.NEXT_PUBLIC_SITE_URL ?? ''}${i}`),
    sku: product.variants[0]?.sku,
    brand: { '@type': 'Brand', name: 'RV Gift Collection' },
    offers: {
      '@type': 'AggregateOffer',
      priceCurrency: 'INR',
      lowPrice: minPrice / 100,
      highPrice: Math.max(...product.variants.map((v) => v.price)) / 100,
      offerCount: product.variants.length,
      availability: product.variants.some((v) => v.available)
        ? 'https://schema.org/InStock'
        : 'https://schema.org/OutOfStock',
    },
  };

  return (
    <div className="shell py-6 md:py-10">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <nav className="mb-6 flex items-center gap-1.5 text-xs text-ink-400" aria-label="Breadcrumb">
        <Link href="/" className="hover:text-burgundy-800">Home</Link>
        <ChevronRight size={12} aria-hidden />
        <Link href="/collections" className="hover:text-burgundy-800">Gifts</Link>
        <ChevronRight size={12} aria-hidden />
        {category && (
          <>
            <Link href={`/collections?category=${category.slug}`} className="hover:text-burgundy-800">
              {category.name}
            </Link>
            <ChevronRight size={12} aria-hidden />
          </>
        )}
        <span className="truncate text-ink-700">{product.name}</span>
      </nav>

      <ProductPageClient product={JSON.parse(JSON.stringify(product))} />

      {/* Product information */}
      <section className="mt-14 grid gap-4 md:grid-cols-2" aria-label="Product information">
        <div className="card p-6">
          <h2 className="font-display text-lg text-burgundy-900">About this gift</h2>
          <p className="mt-2 text-sm leading-relaxed text-ink-500">{product.description}</p>
          <dl className="mt-5 space-y-2.5 text-sm">
            <InfoRow term="Dimensions" value={product.dimensions} />
            <InfoRow term="Material" value={product.material} />
            <InfoRow term="Care" value={product.care} />
            <InfoRow term="Production time" value={`${product.leadTimeDays} business day${product.leadTimeDays > 1 ? 's' : ''} before dispatch`} />
          </dl>
        </div>
        <div className="space-y-4">
          <div className="card flex items-start gap-3 p-5">
            <ShieldCheck className="mt-0.5 shrink-0 text-burgundy-700" size={20} aria-hidden />
            <p className="text-sm leading-relaxed text-ink-500">
              <strong className="text-ink-900">Approved before production.</strong> Your personalization is reviewed and
              approved by you — we never print without your approval.
            </p>
          </div>
          <div className="card flex items-start gap-3 p-5">
            <Sparkles className="mt-0.5 shrink-0 text-burgundy-700" size={20} aria-hidden />
            <p className="text-sm leading-relaxed text-ink-500">
              <strong className="text-ink-900">Photos stay private.</strong> Uploaded photos are validated, stripped of
              camera metadata and stored in private storage — never publicly accessible.
            </p>
          </div>
          <div className="card flex items-start gap-3 p-5">
            <RotateCcw className="mt-0.5 shrink-0 text-burgundy-700" size={20} aria-hidden />
            <p className="text-sm leading-relaxed text-ink-500">
              <strong className="text-ink-900">Personalized with care.</strong> Because every piece is made to order,
              personalized items can’t be returned unless damaged or incorrect — see our{' '}
              <Link href="/policies/returns" className="text-burgundy-700 underline">Returns &amp; Cancellation policy</Link>.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

function InfoRow({ term, value }: { term: string; value: string }) {
  return (
    <div className="flex gap-3 border-b border-cream-200 pb-2.5 last:border-0 last:pb-0">
      <dt className="w-32 shrink-0 text-xs font-semibold uppercase tracking-wider text-ink-400">{term}</dt>
      <dd className="text-ink-700">{value}</dd>
    </div>
  );
}
