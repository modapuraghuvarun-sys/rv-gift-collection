import type { Metadata } from 'next';
import { ContactClient } from '@/components/ContactClient';

export const metadata: Metadata = {
  title: 'Contact & Support',
  description: 'Raise an order issue, personalization correction, delivery problem or any question — with a case reference.',
  alternates: { canonical: '/contact' },
};

export default function ContactPage({ searchParams }: { searchParams: { order?: string } }) {
  return <ContactClient orderReference={searchParams.order} />;
}
