import type { Metadata } from 'next';
import { Fraunces, Inter } from 'next/font/google';
import './globals.css';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { MobileNav } from '@/components/MobileNav';
import { CartProvider } from '@/components/cart/CartProvider';

const display = Fraunces({ subsets: ['latin'], variable: '--font-display' });
const sans = Inter({ subsets: ['latin'], variable: '--font-sans' });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'),
  title: {
    default: 'RV Gift Collection — Personalized Gifts Made for Every Moment',
    template: '%s | RV Gift Collection',
  },
  description:
    'Personalized gifts made for birthdays, anniversaries, weddings and every special moment. Photo mugs, frames, cushions, lamps, keychains, stationery and hampers — crafted in India.',
  openGraph: {
    title: 'RV Gift Collection — Make Every Gift Personal',
    description:
      'Personalized gifts made for birthdays, anniversaries, weddings and every special moment.',
    type: 'website',
    locale: 'en_IN',
    images: [{ url: '/images/hero.jpg', width: 1600, height: 900, alt: 'RV Gift Collection' }],
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body className="flex min-h-screen flex-col pb-16 md:pb-0">
        <CartProvider>
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
          <MobileNav />
        </CartProvider>
      </body>
    </html>
  );
}
