import type { Metadata } from 'next';
import { DemoPayClient } from '@/components/payment/DemoPayClient';

export const metadata: Metadata = { title: 'Secure Payment', robots: { index: false } };

export default function DemoPayPage() {
  return <DemoPayClient />;
}
