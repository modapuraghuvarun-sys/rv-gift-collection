import type { Metadata } from 'next';
import { AuthForm } from '@/components/auth/AuthForm';

export const metadata: Metadata = { title: 'Log In', robots: { index: false } };

export default function LoginPage() {
  return <AuthForm mode="login" />;
}
