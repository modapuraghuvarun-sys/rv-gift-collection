import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="shell flex min-h-[60vh] flex-col items-center justify-center py-16 text-center">
      <p className="eyebrow">404</p>
      <h1 className="mt-2 font-display text-3xl text-burgundy-900">This page wandered off</h1>
      <p className="mt-2 max-w-sm text-sm text-ink-500">
        The page you’re looking for doesn’t exist — but the perfect gift probably does.
      </p>
      <div className="mt-6 flex gap-3">
        <Link href="/" className="btn-outline btn-md">Go home</Link>
        <Link href="/collections" className="btn-primary btn-md">Explore Gifts</Link>
      </div>
    </div>
  );
}
