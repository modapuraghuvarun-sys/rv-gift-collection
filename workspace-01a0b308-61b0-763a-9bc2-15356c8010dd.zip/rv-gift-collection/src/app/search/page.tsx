import type { Metadata } from 'next';
import { Suspense } from 'react';
import { CatalogueBrowser } from '@/components/CatalogueBrowser';

export const metadata: Metadata = {
  title: 'Search Gifts',
  description: 'Search personalized gifts at RV Gift Collection.',
  robots: { index: false },
};

export default function SearchPage() {
  return (
    <Suspense>
      <CatalogueBrowser />
    </Suspense>
  );
}
