import type { Metadata } from 'next';
import { Suspense } from 'react';
import { CatalogueBrowser } from '@/components/CatalogueBrowser';

export const metadata: Metadata = {
  title: 'All Personalized Gifts',
  description:
    'Browse personalized mugs, frames, cushions, keychains, lamps, stationery and gift hampers. Filter by occasion, recipient and price.',
  alternates: { canonical: '/collections' },
};

export default function CollectionsPage() {
  return (
    <Suspense>
      <CatalogueBrowser
        title="The Gift Collection"
        subtitle="Every gift here can be personalized. Filter by category, occasion, recipient or price to find the right one."
      />
    </Suspense>
  );
}
