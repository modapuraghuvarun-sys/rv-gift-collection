import type { Metadata } from 'next';
import Link from 'next/link';
import { cookies } from 'next/headers';
import { CheckCircle2, Lock, Package, ShieldCheck } from 'lucide-react';
import { accessOrder, MAIN_TIMELINE, STATUS_LABELS } from '@/lib/orders';
import { getSession, store } from '@/lib/store';
import { formatINR } from '@/lib/money';
import { formatDateTime } from '@/lib/utils';
import { OrderTimeline } from '@/components/order/OrderTimeline';

export const metadata: Metadata = { title: 'Your Order', robots: { index: false } };
export const dynamic = 'force-dynamic';

interface Props {
  params: { reference: string };
  searchParams: { token?: string };
}

/**
 * Order confirmation + tracking.
 * Security: requires the secret tracking token (guest links) or the owning
 * account / staff session. Order number + email alone never grants access.
 */
export default function OrderPage({ params, searchParams }: Props) {
  const session = getSession(cookies().get('rv_session')?.value);
  const access = accessOrder(params.reference, {
    token: searchParams.token,
    userId: session?.userId,
    staff: session?.role === 'staff',
  });

  if (!access.ok) {
    return (
      <div className="shell flex min-h-[60vh] items-center justify-center py-16">
        <div className="card w-full max-w-md p-10 text-center" role="alert">
          <Lock className="mx-auto text-burgundy-500" size={36} aria-hidden />
          <h1 className="mt-4 font-display text-2xl text-burgundy-900">
            {access.reason === 'NOT_FOUND' ? 'Order not found' : 'This order is private'}
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-ink-500">
            {access.reason === 'NOT_FOUND'
              ? 'We couldn’t find an order with that reference. Please check the link from your confirmation email.'
              : 'For your security, orders can only be opened with a secure tracking link or by the account that placed them. An order number alone is never enough.'}
          </p>
          <Link href="/track" className="btn-primary btn-md mt-6">Go to Track Order</Link>
        </div>
      </div>
    );
  }

  const order = access.order!;
  const payment = store.payments.find((p) => p.id === order.paymentId);
  const confirmed = order.status !== 'PAYMENT_PENDING' && order.status !== 'CANCELLED';
  const isException = ['CORRECTION_HOLD', 'DELIVERY_EXCEPTION', 'CANCELLED'].includes(order.status);

  return (
    <div className="shell py-8 md:py-12">
      <div className="mx-auto max-w-3xl">
        <div className="text-center">
          <span className={`mx-auto flex h-16 w-16 items-center justify-center rounded-full ${confirmed ? 'bg-emerald-100 text-emerald-700' : isException ? 'bg-gold-200 text-gold-600' : 'bg-cream-200 text-ink-400'}`}>
            {confirmed ? <CheckCircle2 size={30} aria-hidden /> : <Package size={28} aria-hidden />}
          </span>
          <p className="mt-4 eyebrow">Order {order.reference}</p>
          <h1 className="mt-2 font-display text-3xl text-burgundy-900 sm:text-4xl">
            {order.status === 'PAYMENT_PENDING' ? 'Awaiting payment' : isException ? STATUS_LABELS[order.status] : 'Order Confirmed'}
          </h1>
          <p className="mx-auto mt-2 max-w-md text-sm text-ink-500">
            {confirmed
              ? `Thank you, ${order.buyer.name.split(' ')[0]}. Your gift is being prepared with care.`
              : order.status === 'PAYMENT_PENDING'
                ? 'This order confirms once payment is verified.'
                : 'Please see the note below from our team.'}
          </p>
        </div>

        {/* Timeline */}
        <section className="card mt-10 p-6 sm:p-8" aria-label="Order progress">
          <div className="mb-6 flex items-center justify-between">
            <h2 className="font-display text-lg text-burgundy-900">Order progress</h2>
            <span className="rounded-full bg-burgundy-50 px-3 py-1 text-xs font-semibold text-burgundy-800">
              {STATUS_LABELS[order.status]}
            </span>
          </div>
          <OrderTimeline order={order} />
          {isException && (
            <div className="mt-6 rounded-xl bg-gold-200/40 p-4 text-sm text-ink-700" role="alert">
              <p className="font-semibold">{STATUS_LABELS[order.status]}</p>
              {[...order.history].reverse().find((h) => h.status === order.status)?.note && (
                <p className="mt-1 text-xs">{[...order.history].reverse().find((h) => h.status === order.status)?.note}</p>
              )}
              <p className="mt-2 text-xs text-ink-500">
                Our team will reach out at {order.buyer.email}. You can also{' '}
                <Link href={`/contact?order=${order.reference}`} className="text-burgundy-700 underline">raise a support request</Link>.
              </p>
            </div>
          )}
        </section>

        {/* Items */}
        <section className="card mt-6 p-6 sm:p-8" aria-label="Items">
          <h2 className="font-display text-lg text-burgundy-900">Your gifts</h2>
          <ul className="mt-4 divide-y divide-cream-200">
            {order.items.map((item, i) => (
              <li key={i} className="flex gap-4 py-4 first:pt-0 last:pb-0">
                <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-cream-100">
                  {item.personalisation?.previewThumb ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={item.personalisation.previewThumb} alt="Approved design" className="h-full w-full object-cover" />
                  ) : (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex justify-between gap-3">
                    <p className="text-sm font-semibold text-ink-900">{item.name}</p>
                    <p className="text-sm font-bold text-burgundy-900">{formatINR(item.lineTotal)}</p>
                  </div>
                  <p className="mt-0.5 text-xs text-ink-400">
                    {item.variantName} · SKU {item.sku} · Qty {item.qty}
                  </p>
                  {item.personalisation && (
                    <div className="mt-2 rounded-lg bg-cream-100 p-2.5 text-[11px] text-ink-500">
                      {Object.entries(item.personalisation.fields).filter(([, v]) => v).map(([k, v]) => (
                        <p key={k}>
                          <strong className="capitalize text-ink-700">{k}:</strong> {v}
                        </p>
                      ))}
                      <p className="mt-1 flex items-center gap-1 font-semibold text-emerald-700">
                        <ShieldCheck size={11} aria-hidden /> Approved design · template v{item.personalisation.templateVersion}
                      </p>
                    </div>
                  )}
                </div>
              </li>
            ))}
          </ul>

          <dl className="mt-4 space-y-2 border-t border-cream-200 pt-4 text-sm">
            <div className="flex justify-between"><dt className="text-ink-500">Subtotal</dt><dd className="font-semibold">{formatINR(order.subtotal)}</dd></div>
            {order.discount > 0 && (
              <div className="flex justify-between text-emerald-700"><dt>Discount{order.couponCode ? ` (${order.couponCode})` : ''}</dt><dd>− {formatINR(order.discount)}</dd></div>
            )}
            <div className="flex justify-between text-xs text-ink-400"><dt>Tax (included)</dt><dd>{formatINR(order.taxIncluded)}</dd></div>
            <div className="flex justify-between"><dt className="text-ink-500">Delivery ({order.deliveryOption})</dt><dd className="font-semibold">{order.deliveryFee === 0 ? 'Free' : formatINR(order.deliveryFee)}</dd></div>
            <div className="flex justify-between border-t border-cream-200 pt-3"><dt className="text-base font-bold">Total</dt><dd className="text-lg font-bold text-burgundy-900">{formatINR(order.total)}</dd></div>
            <div className="flex justify-between text-xs text-ink-400">
              <dt>Payment</dt>
              <dd>
                {payment?.status === 'CAPTURED' ? `Paid · ${payment.provider === 'razorpay-demo' ? 'Hosted checkout (demo)' : 'Razorpay'} · ${payment.providerPaymentId ?? ''}` : payment?.status ?? 'Pending'}
              </dd>
            </div>
            {order.deliveryWindow && (
              <div className="flex justify-between text-xs text-ink-400"><dt>Estimated delivery</dt><dd>{order.deliveryWindow}</dd></div>
            )}
          </dl>
        </section>

        {/* Delivery + support */}
        <section className="mt-6 grid gap-4 sm:grid-cols-2">
          <div className="card p-6">
            <h2 className="text-sm font-semibold text-ink-900">Delivering to</h2>
            <p className="mt-2 text-sm text-ink-500">
              {order.address.fullName}
              <br />
              {order.address.line1}
              {order.address.line2 && <><br />{order.address.line2}</>}
              <br />
              {order.address.city}, {order.address.state} {order.address.pincode}
            </p>
            {order.recipient.name !== order.address.fullName && (
              <p className="mt-2 text-xs text-ink-400">Gift recipient: {order.recipient.name}</p>
            )}
            {order.shipment?.awb && (
              <p className="mt-3 rounded-lg bg-cream-100 p-2.5 text-xs text-ink-500">
                Courier: {order.shipment.courier} · AWB {order.shipment.awb}
              </p>
            )}
          </div>
          <div className="card flex flex-col justify-between p-6">
            <div>
              <h2 className="text-sm font-semibold text-ink-900">Need help with this order?</h2>
              <p className="mt-2 text-xs text-ink-500">
                Raise a support request and quote reference <strong>{order.reference}</strong>.
              </p>
            </div>
            <Link href={`/contact?order=${order.reference}`} className="btn-outline btn-md mt-4">
              Contact support
            </Link>
          </div>
        </section>

        <p className="mt-6 text-center text-[11px] text-ink-400">
          Placed {formatDateTime(order.createdAt)} · Keep this page’s link private — it grants access to this order.
        </p>
      </div>
    </div>
  );
}
