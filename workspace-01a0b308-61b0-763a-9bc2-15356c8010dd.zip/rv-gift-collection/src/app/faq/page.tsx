import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = {
  title: 'FAQ',
  description: 'Common questions about personalization, photo uploads, delivery estimates, payments and returns.',
  alternates: { canonical: '/faq' },
};

const FAQS: { q: string; a: string }[] = [
  {
    q: 'How does personalization work?',
    a: 'Choose a gift, add your name or message, upload photos where the product supports them, preview your design in 2D, and approve it. Nothing is produced until you approve the exact design — and you can see the precise crop that will be printed.',
  },
  {
    q: 'Which photo formats and sizes do you accept?',
    a: 'JPEG and PNG only, up to 10 MB per photo. Photos are validated for genuine file signatures, decoded and checked for pixel dimensions against the product’s print requirements. Camera metadata is removed automatically, and uploads are stored privately — never publicly.',
  },
  {
    q: 'Is the preview exactly what I’ll receive?',
    a: 'The preview shows approximate placement and appearance so you can approve the design with confidence. Final colours and material finishes can vary slightly between screens and physical materials — but the crop and placement you approve is what we produce.',
  },
  {
    q: 'When will my order arrive?',
    a: 'Use the PIN code checker on any product page. It computes an honest estimate from production lead time, business days, cut-off times and transit time for your area. We do not promise next-day delivery — the estimated window shown is what we commit to working towards.',
  },
  {
    q: 'What if my PIN code is not serviceable?',
    a: 'The checker will tell you before you pay. We are expanding coverage; please check back later or choose a delivery address in a serviceable area.',
  },
  {
    q: 'Can I change my personalization after ordering?',
    a: 'Orders enter a Personalization Review stage after payment. Raise a “Personalization correction” support request with your order reference as early as possible — corrections are possible until production begins.',
  },
  {
    q: 'How are payments handled?',
    a: 'Through a secure hosted payment page. Your order confirms only after the payment provider verifies the payment on our servers — a browser redirect alone never confirms an order. If payment fails, no money is captured and you can retry.',
  },
  {
    q: 'Can I return a personalized gift?',
    a: 'Because personalized items are made uniquely for you, they cannot be returned or exchanged unless they arrive damaged or incorrect. In those cases, raise a support request with photos and your order reference and we will make it right.',
  },
  {
    q: 'Do you add gift recipients to marketing lists?',
    a: 'Never. Recipient details are used only to deliver the gift. Transactional updates (order, production, delivery) are separate from marketing, and marketing consent is always explicit and separate.',
  },
];

export default function FaqPage() {
  return (
    <div className="shell py-10 md:py-16">
      <div className="mx-auto max-w-3xl">
        <p className="eyebrow text-center">Help</p>
        <h1 className="mt-2 text-center font-display text-3xl text-burgundy-900 md:text-4xl">Frequently asked questions</h1>
        <div className="mt-10 space-y-3">
          {FAQS.map((f) => (
            <details key={f.q} className="card group p-5 open:shadow-card">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-sm font-semibold text-ink-900">
                {f.q}
                <span className="text-burgundy-500 transition-transform group-open:rotate-45" aria-hidden>+</span>
              </summary>
              <p className="mt-3 text-sm leading-relaxed text-ink-500">{f.a}</p>
            </details>
          ))}
        </div>
        <p className="mt-8 text-center text-sm text-ink-500">
          Still stuck? <Link href="/contact" className="font-semibold text-burgundy-700 underline">Contact support</Link> — every request gets a case reference.
        </p>
      </div>
    </div>
  );
}
