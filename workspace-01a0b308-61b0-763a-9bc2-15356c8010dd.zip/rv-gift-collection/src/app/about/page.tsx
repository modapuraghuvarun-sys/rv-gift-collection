import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import { Reveal } from '@/components/Reveal';

export const metadata: Metadata = {
  title: 'About Us',
  description: 'RV Gift Collection is an India-first personalized gifting brand — gifts made with names, photos and memories.',
  alternates: { canonical: '/about' },
};

export default function AboutPage() {
  return (
    <>
      <section className="relative h-72 overflow-hidden md:h-96">
        <Image src="/images/hero.jpg" alt="RV Gift Collection studio" fill priority sizes="100vw" className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-burgundy-950/85 to-burgundy-950/30" />
        <div className="shell absolute bottom-0 pb-10">
          <p className="eyebrow text-gold-300">About us</p>
          <h1 className="mt-2 max-w-xl font-display text-3xl text-cream-50 md:text-5xl">
            Gifts that carry a name, a photo, a memory.
          </h1>
        </div>
      </section>

      <section className="shell max-w-3xl py-14 md:py-20">
        <Reveal>
          <p className="text-base leading-relaxed text-ink-700 md:text-lg">
            RV Gift Collection exists for one simple reason: a gift becomes unforgettable when it is made for one
            person. Not a shelf product — a mug with their family’s photo, a lamp engraved with their wedding date, a
            cushion that turns a sofa into a memory.
          </p>
        </Reveal>
        <Reveal delay={80}>
          <p className="mt-6 text-base leading-relaxed text-ink-700 md:text-lg">
            We are an India-first gifting brand. Every piece is personalized by you, reviewed and approved by you, and
            then produced with care — quality-checked before it is packed and delivered with tracking.
          </p>
        </Reveal>

        <Reveal delay={120}>
          <div className="mt-12 grid gap-4 sm:grid-cols-3">
            {[
              { title: 'Made for one', text: 'Every product is configured for names, messages or photos — never mass-printed.' },
              { title: 'Approved by you', text: 'Nothing enters production until you approve your exact design.' },
              { title: 'Handled with care', text: 'Private photo storage, honest delivery estimates and order tracking end to end.' },
            ].map((v) => (
              <div key={v.title} className="card p-6">
                <h2 className="font-display text-lg text-burgundy-900">{v.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-ink-500">{v.text}</p>
              </div>
            ))}
          </div>
        </Reveal>

        {/* Owner-supplied story placeholder — PRD §39: do not invent business history */}
        <Reveal delay={160}>
          <div className="mt-12 rounded-xl2 border border-gold-300 bg-gold-200/25 p-6">
            <p className="badge-placeholder mb-2">Owner content placeholder</p>
            <p className="text-sm leading-relaxed text-ink-700">
              The founding story, team details and studio photographs will be added here by the store owner. Until
              then, we let the gifts speak for themselves.
            </p>
          </div>
        </Reveal>

        <div className="mt-12 text-center">
          <Link href="/collections" className="btn-primary btn-lg">Explore the Collection</Link>
        </div>
      </section>
    </>
  );
}
