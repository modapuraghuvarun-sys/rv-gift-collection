import type { Metadata } from 'next';
import { PolicyLayout } from '@/components/PolicyLayout';

export const metadata: Metadata = {
  title: 'Terms & Conditions',
  description: 'Terms of use for RV Gift Collection.',
  alternates: { canonical: '/policies/terms' },
};

export default function TermsPage() {
  return (
    <PolicyLayout
      title="Terms & Conditions"
      updated="September 2026"
      intro="These terms govern your use of RV Gift Collection and purchases made through the store."
      sections={[
        {
          heading: '1. Orders and pricing',
          body: [
            'All prices are in Indian Rupees and include GST. Prices are computed on our servers at the time of checkout; if a price changes between cart and payment, you will be shown the updated amount and asked to review it before paying.',
            'An order confirms only when payment is verified by our payment provider. Until then the order remains in a payment-pending state and stock reservations may expire.',
          ],
        },
        {
          heading: '2. Personalization and approval',
          body: [
            'You are responsible for the spelling, photos and placement you approve. The on-screen preview is approximate; final colours and material finishes can vary slightly. Once production begins, changes may not be possible.',
            'You confirm you have the right to use any photo or text you upload. Content that is unlawful, infringing or offensive may be rejected.',
          ],
        },
        {
          heading: '3. Production and delivery',
          body: [
            'Delivery windows shown at checkout are estimates computed from production and transit times, not guarantees. Events beyond our control (courier disruptions, natural events) can affect delivery; if your order is affected we will keep you informed via the order timeline.',
          ],
        },
        {
          heading: '4. Cancellations and refunds',
          body: [
            'See the Returns & Cancellation policy. In brief: personalized orders can be cancelled before production begins; after production starts, refunds apply only for damaged or incorrect items.',
          ],
        },
        {
          heading: '5. Accounts and security',
          body: [
            'You are responsible for the accuracy of information you provide and for keeping your account credentials confidential. Order tracking links are private; sharing them shares access to that order.',
          ],
        },
        {
          heading: '6. Changes',
          body: [
            'We may update these terms as the service grows; the latest version will always be published here with its update date.',
          ],
        },
      ]}
    />
  );
}
