import type { Metadata } from 'next';
import { PolicyLayout } from '@/components/PolicyLayout';

export const metadata: Metadata = {
  title: 'Shipping Policy',
  description: 'How RV Gift Collection estimates delivery windows, PIN code serviceability and production lead times.',
  alternates: { canonical: '/policies/shipping' },
};

export default function ShippingPolicyPage() {
  return (
    <PolicyLayout
      title="Shipping Policy"
      updated="September 2026"
      intro="Every RV Gift Collection product is made to order. This page explains how delivery estimates are calculated and what you can expect after checkout."
      sections={[
        {
          heading: '1. Made-to-order production',
          body: [
            'Personalized gifts are produced after your order confirms. Each product page lists its production lead time in business days (typically 1–3 business days). Production begins after payment is verified and your personalization is approved.',
            'Orders placed after our daily cut-off time, or on non-business days, begin production the next business day.',
          ],
        },
        {
          heading: '2. Delivery estimates',
          body: [
            'Use the PIN code checker on any product page before ordering. The estimate combines production lead time, business days, cut-off times, daily fulfilment capacity and courier transit time for your zone.',
            'Estimates are shown as a window (for example, “Mon, 22 Sep – Thu, 25 Sep”). These are honest working estimates, not guarantees. Same-day, midnight and fixed-time delivery are not offered at this stage.',
          ],
        },
        {
          heading: '3. Serviceable areas',
          body: [
            'We deliver to PIN codes supported by our courier partners. If your PIN code is not serviceable, the checker will tell you before payment. Coverage expands over time.',
          ],
        },
        {
          heading: '4. Delivery charges',
          body: [
            'Delivery charges are calculated server-side and shown clearly in the cart and at checkout before you pay. Standard delivery above the free-delivery threshold (shown at checkout) is free. Express delivery, where available for your PIN code, carries an additional charge.',
          ],
        },
        {
          heading: '5. Tracking',
          body: [
            'Once your order ships, tracking information is added to your order page. You can follow every stage — Confirmed, Personalization Review, In Production, Quality Checked, Packed, Shipped, Delivered — plus any holds or exceptions.',
          ],
        },
        {
          heading: '6. Recipient privacy',
          body: [
            'Gift recipient details are used only to deliver the gift. Recipients are never enrolled into marketing communications.',
          ],
        },
      ]}
    />
  );
}
