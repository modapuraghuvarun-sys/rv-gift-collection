import type { Metadata } from 'next';
import { PolicyLayout } from '@/components/PolicyLayout';

export const metadata: Metadata = {
  title: 'Returns & Cancellation',
  description: 'Cancellation windows and return rules for personalized gifts at RV Gift Collection.',
  alternates: { canonical: '/policies/returns' },
};

export default function ReturnsPage() {
  return (
    <PolicyLayout
      title="Returns & Cancellation"
      updated="September 2026"
      intro="Because every gift is made uniquely for you, our return rules are different from regular e-commerce — please read them before ordering."
      sections={[
        {
          heading: '1. Personalized items',
          body: [
            'Personalized products are produced with your approved design and cannot be resold. They therefore cannot be returned or exchanged for change of mind, spelling approved by you, or minor colour variation between screen and material.',
          ],
        },
        {
          heading: '2. Damaged or incorrect items',
          body: [
            'If your gift arrives damaged or materially different from the design you approved, raise a support request within the window stated by the store owner (placeholder until published) with your order reference and photos. We will offer a replacement or refund as appropriate.',
          ],
        },
        {
          heading: '3. Cancellations',
          body: [
            'You may cancel a paid order before it enters the In Production stage; refunds are initiated to the original payment method. Once production has begun, cancellation is not possible, though correction requests are handled case by case during Personalization Review.',
          ],
        },
        {
          heading: '4. Refund timelines',
          body: [
            'Approved refunds are processed to the original payment method. The time the refund takes to appear depends on your bank or card issuer. You will receive an email when the refund is initiated.',
          ],
        },
        {
          heading: '5. Non-personalized items',
          body: [
            'Items without personalization follow the standard return window that the store owner will publish here. Items must be unused and in original packaging.',
          ],
        },
      ]}
    />
  );
}
