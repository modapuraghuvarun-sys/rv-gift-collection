import type { Metadata } from 'next';
import { PolicyLayout } from '@/components/PolicyLayout';

export const metadata: Metadata = {
  title: 'Privacy Policy',
  description: 'How RV Gift Collection protects customer data and personal photos.',
  alternates: { canonical: '/policies/privacy' },
};

export default function PrivacyPolicyPage() {
  return (
    <PolicyLayout
      title="Privacy Policy"
      updated="September 2026"
      intro="Your trust matters more than a transaction. This policy explains what we collect, why, and how it is protected — especially your photos."
      sections={[
        {
          heading: '1. What we collect',
          body: [
            'Account details you choose to provide (name, email, phone), delivery addresses, order history, and the personalization content you create (text, messages, photos). Payment card details are never collected or stored by us — payments run through a secure hosted payment provider.',
          ],
        },
        {
          heading: '2. Your photos are private',
          body: [
            'Uploaded photos are stored in private storage and are never publicly accessible. We validate file types (JPEG/PNG only), remove camera metadata, and access is granted only to staff who need it to produce your order, through short-lived secure links.',
            'Photo file paths never contain customer names, addresses or emails.',
          ],
        },
        {
          heading: '3. How we use your data',
          body: [
            'To produce and deliver your orders, send transactional updates (payment, production, dispatch, delivery), respond to support requests, and prevent fraud. Transactional communication is separate from marketing — marketing messages are only sent with explicit, separate consent.',
          ],
        },
        {
          heading: '4. Gift recipients',
          body: [
            'Recipient names, addresses and phone numbers are used solely to deliver the gift. Recipients are never added to marketing lists.',
          ],
        },
        {
          heading: '5. Security',
          body: [
            'Row-level security on all customer data, server-side authorization checks for every request, encrypted secrets that are never exposed to the browser, and audit logs of staff actions. We follow a strict policy of least privilege: production staff only see the files and recipient information their work requires.',
          ],
        },
        {
          heading: '6. Retention',
          body: [
            'Order records are retained as required for service and legal purposes. Uncompleted uploads are cleaned up automatically. You may request account deletion via support; production files for completed orders follow the retention schedule the owner will publish here.',
          ],
        },
      ]}
    />
  );
}
