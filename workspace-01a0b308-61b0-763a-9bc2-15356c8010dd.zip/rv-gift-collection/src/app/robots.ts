import type { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000';
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        // Private areas: never indexed.
        disallow: ['/admin', '/account', '/cart', '/checkout', '/payment', '/order', '/api/', '/search'],
      },
    ],
    sitemap: `${base}/sitemap.xml`,
  };
}
