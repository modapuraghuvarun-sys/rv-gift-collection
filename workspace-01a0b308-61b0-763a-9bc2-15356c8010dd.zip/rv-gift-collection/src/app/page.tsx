import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight, BadgeCheck, Gift, ImageIcon, Lock, PackageSearch, Palette, PhoneCall, Truck } from 'lucide-react';
import { categories, occasions, recipients } from '@/lib/data/catalog';
import { store } from '@/lib/store';
import { formatINR } from '@/lib/money';
import { Reveal } from '@/components/Reveal';

export const dynamic = 'force-dynamic';

export default function HomePage() {
  const featured = store.products.filter((p) => p.status === 'published' && p.featured).slice(0, 4);

  return (
    <>
      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/images/hero.jpg"
            alt="Personalized gifts styled on cream linen with burgundy ribbon and marigolds"
            fill
            priority
            sizes="100vw"
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-burgundy-950/85 via-burgundy-950/55 to-burgundy-950/15" />
        </div>
        <div className="shell relative flex min-h-[560px] flex-col justify-center py-20 md:min-h-[640px]">
          <div className="max-w-xl">
            <p className="animate-fade-up eyebrow text-gold-300" style={{ animationDelay: '60ms' }}>
              RV Gift Collection
            </p>
            <h1
              className="mt-4 animate-fade-up font-display text-4xl leading-[1.08] text-cream-50 sm:text-5xl md:text-6xl"
              style={{ animationDelay: '160ms' }}
            >
              Make Every Gift <em className="not-italic text-gold-300">Personal.</em>
            </h1>
            <p
              className="mt-5 max-w-md animate-fade-up text-base leading-relaxed text-cream-100/85 sm:text-lg"
              style={{ animationDelay: '280ms' }}
            >
              Personalized gifts made for birthdays, anniversaries, weddings and every special moment.
            </p>
            <div className="mt-8 flex animate-fade-up flex-wrap gap-3" style={{ animationDelay: '400ms' }}>
              <Link href="/collections" className="btn-gold btn-lg">
                Explore Gifts <ArrowRight size={18} aria-hidden />
              </Link>
              <Link
                href="#occasions"
                className="btn btn-lg border border-cream-50/40 text-cream-50 backdrop-blur hover:bg-cream-50/10"
              >
                Shop by Occasion
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── CATEGORIES ───────────────────────────────────────────────────── */}
      <section className="shell py-16 md:py-20" aria-labelledby="categories-heading">
        <Reveal>
          <p className="eyebrow">The collection</p>
          <h2 id="categories-heading" className="section-title mt-2">
            Gifts in every shape
          </h2>
        </Reveal>
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {categories.map((c, i) => (
            <Reveal key={c.slug} delay={i * 60}>
              <Link
                href={`/collections?category=${c.slug}`}
                className={`group relative block overflow-hidden rounded-xl2 shadow-soft transition-all duration-300 hover:-translate-y-1 hover:shadow-lift ${
                  i === 0 ? 'col-span-2 row-span-2' : ''
                }`}
              >
                <div className={`relative w-full ${i === 0 ? 'aspect-square sm:aspect-[4/3.05]' : 'aspect-square'} overflow-hidden`}>
                  <Image
                    src={c.image}
                    alt={c.name}
                    fill
                    sizes={i === 0 ? '50vw' : '25vw'}
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-burgundy-950/70 via-transparent to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <h3 className="font-display text-lg text-cream-50">{c.name}</h3>
                    <p className="mt-0.5 line-clamp-1 text-xs text-cream-100/70">{c.blurb}</p>
                  </div>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── OCCASIONS ────────────────────────────────────────────────────── */}
      <section id="occasions" className="bg-cream-100 py-16 md:py-20" aria-labelledby="occasions-heading">
        <div className="shell">
          <Reveal>
            <p className="eyebrow">Shop by occasion</p>
            <h2 id="occasions-heading" className="section-title mt-2">
              For the moments that matter
            </h2>
          </Reveal>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {occasions.map((o, i) => (
              <Reveal key={o.slug} delay={i * 60}>
                <Link
                  href={`/occasion/${o.slug}`}
                  className="group relative block aspect-[3/4] overflow-hidden rounded-xl2 shadow-soft transition-all duration-300 hover:-translate-y-1 hover:shadow-lift"
                >
                  <Image
                    src={o.image}
                    alt={o.name}
                    fill
                    sizes="20vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-burgundy-950/75 via-transparent to-transparent" />
                  <div className="absolute bottom-0 p-4">
                    <h3 className="font-display text-lg text-cream-50">{o.name}</h3>
                    <p className="mt-0.5 line-clamp-2 text-xs text-cream-100/75">{o.blurb}</p>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── RECIPIENTS ───────────────────────────────────────────────────── */}
      <section className="shell py-16 md:py-20" aria-labelledby="recipients-heading">
        <Reveal>
          <p className="eyebrow">Shop by recipient</p>
          <h2 id="recipients-heading" className="section-title mt-2">
            Made for someone specific
          </h2>
        </Reveal>
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
          {recipients.map((r, i) => (
            <Reveal key={r.slug} delay={i * 40}>
              <Link
                href={`/collections?recipient=${r.slug}`}
                className="group block overflow-hidden rounded-xl2 border border-cream-200 bg-white shadow-soft transition-all duration-300 hover:-translate-y-1 hover:shadow-card"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <Image
                    src={r.image}
                    alt={r.name}
                    fill
                    sizes="16vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="p-3.5">
                  <h3 className="text-sm font-semibold text-ink-900 group-hover:text-burgundy-800">{r.name}</h3>
                  <p className="mt-0.5 line-clamp-1 text-xs text-ink-400">{r.blurb}</p>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ── FEATURED (curated — not "bestseller" claims) ─────────────────── */}
      <section className="bg-burgundy-950 py-16 md:py-20" aria-labelledby="featured-heading">
        <div className="shell">
          <Reveal>
            <p className="eyebrow text-gold-400">Curated by RV</p>
            <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
              <h2 id="featured-heading" className="font-display text-3xl text-cream-50 sm:text-4xl">
                Featured gifts
              </h2>
              <Link href="/collections" className="text-sm font-medium text-gold-300 hover:text-gold-200">
                View all gifts →
              </Link>
            </div>
          </Reveal>
          <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
            {featured.map((p, i) => (
              <Reveal key={p.id} delay={i * 70}>
                <Link
                  href={`/product/${p.slug}`}
                  className="group block overflow-hidden rounded-xl2 bg-cream-50 shadow-soft transition-all duration-300 hover:-translate-y-1 hover:shadow-lift"
                >
                  <div className="relative aspect-square overflow-hidden">
                    <Image
                      src={p.images[0]}
                      alt={p.name}
                      fill
                      sizes="25vw"
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="line-clamp-1 text-sm font-semibold text-ink-900">{p.name}</h3>
                    <p className="mt-1 text-sm font-bold text-burgundy-900">
                      From {formatINR(Math.min(...p.variants.filter((v) => v.available).map((v) => v.price)))}
                    </p>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW PERSONALIZATION WORKS ────────────────────────────────────── */}
      <section className="shell py-16 md:py-20" aria-labelledby="how-heading">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <Reveal>
            <div className="relative overflow-hidden rounded-xl2 shadow-card">
              <Image
                src="/images/studio.jpg"
                alt="Artisan personalizing a ceramic mug in the RV studio"
                width={900}
                height={700}
                className="w-full object-cover"
              />
            </div>
          </Reveal>
          <div>
            <Reveal>
              <p className="eyebrow">How it works</p>
              <h2 id="how-heading" className="section-title mt-2">
                Your gift, in six gentle steps
              </h2>
            </Reveal>
            <ol className="mt-8 space-y-4">
              {[
                { icon: Gift, title: 'Choose a gift', text: 'Pick from mugs, frames, cushions, lamps, keychains, stationery and hampers.' },
                { icon: ImageIcon, title: 'Add your name & photo', text: 'Upload photos securely — JPEG or PNG up to 10 MB, validated and stored privately.' },
                { icon: Palette, title: 'Preview your design', text: 'See a live 2D preview with your exact text, photos and placement.' },
                { icon: BadgeCheck, title: 'Approve it', text: 'Nothing goes into production until you approve the personalization yourself.' },
                { icon: Lock, title: 'Place your order', text: 'Secure hosted checkout with clear, upfront pricing — no surprises.' },
                { icon: Truck, title: 'We create & deliver', text: 'We produce your gift, quality-check it, pack it and deliver with tracking.' },
              ].map((s, i) => (
                <Reveal key={s.title} delay={i * 50}>
                  <li className="flex items-start gap-4">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-burgundy-50 text-burgundy-800">
                      <s.icon size={18} aria-hidden />
                    </span>
                    <div>
                      <h3 className="text-sm font-semibold text-ink-900">
                        {i + 1}. {s.title}
                      </h3>
                      <p className="mt-0.5 text-sm text-ink-500">{s.text}</p>
                    </div>
                  </li>
                </Reveal>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* ── WHY RV ───────────────────────────────────────────────────────── */}
      <section className="bg-cream-100 py-16 md:py-20" aria-labelledby="why-heading">
        <div className="shell">
          <Reveal>
            <p className="eyebrow">Why RV Gift Collection</p>
            <h2 id="why-heading" className="section-title mt-2">
              Gifting, handled with care
            </h2>
          </Reveal>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: Palette, title: 'Personalized products', text: 'Names, messages and photos printed or engraved on quality keepsakes.' },
              { icon: Lock, title: 'Secure photo uploads', text: 'Photos are validated, stripped of metadata and stored privately — never public.' },
              { icon: BadgeCheck, title: 'Clear pricing', text: 'Prices include GST. Delivery charges are shown before you pay — no hidden fees.' },
              { icon: Truck, title: 'Delivery availability check', text: 'Check your PIN code for an honest estimated delivery window before ordering.' },
              { icon: PackageSearch, title: 'Order tracking', text: 'Follow your gift from confirmation to production to your doorstep.' },
              { icon: PhoneCall, title: 'Customer support', text: 'Order-linked support requests with a case reference you can quote anytime.' },
            ].map((b, i) => (
              <Reveal key={b.title} delay={i * 50}>
                <div className="card h-full p-6">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full bg-burgundy-50 text-burgundy-800">
                    <b.icon size={20} aria-hidden />
                  </span>
                  <h3 className="mt-4 font-display text-lg text-burgundy-900">{b.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-ink-500">{b.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── CLOSING CTA ──────────────────────────────────────────────────── */}
      <section className="shell py-16 md:py-24">
        <Reveal>
          <div className="relative overflow-hidden rounded-xl2 bg-burgundy-900 px-6 py-14 text-center shadow-lift md:py-20">
            <div className="pointer-events-none absolute -left-16 -top-16 h-56 w-56 rounded-full bg-burgundy-700/40 blur-2xl" aria-hidden />
            <div className="pointer-events-none absolute -bottom-20 -right-10 h-64 w-64 rounded-full bg-gold-500/15 blur-2xl" aria-hidden />
            <h2 className="relative font-display text-3xl text-cream-50 sm:text-4xl">
              Someone out there deserves a gift with their name on it.
            </h2>
            <p className="relative mx-auto mt-3 max-w-md text-sm text-cream-100/75">
              Start with a photo, a name or a memory — we’ll take care of the rest.
            </p>
            <Link href="/collections" className="btn-gold btn-lg relative mt-8">
              Explore Gifts <ArrowRight size={18} aria-hidden />
            </Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}
