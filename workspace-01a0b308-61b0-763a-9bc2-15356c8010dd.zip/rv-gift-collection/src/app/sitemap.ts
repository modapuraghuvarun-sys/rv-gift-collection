import type { MetadataRoute } from 'next';
import { categories, occasions } from '@/lib/data/catalog';
import { store } from '@/lib/store';

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000';
  const now = new Date();

  const staticPages = [
    '',
    '/collections',
    '/about',
    '/contact',
    '/faq',
    '/policies/shipping',
    '/policies/privacy',
    '/policies/terms',
    '/policies/returns',
  ].map((path) => ({ url: `${base}${path}`, lastModified: now, changeFrequency: 'weekly' as const, priority: path === '' ? 1 : 0.7 }));

  const productPages = store.products
    .filter((p) => p.status === 'published')
    .map((p) => ({ url: `${base}/product/${p.slug}`, lastModified: now, changeFrequency: 'daily' as const, priority: 0.9 }));

  const occasionPages = occasions.map((o) => ({ url: `${base}/occasion/${o.slug}`, lastModified: now, changeFrequency: 'weekly' as const, priority: 0.8 }));
  const categoryPages = categories.map((c) => ({ url: `${base}/collections?category=${c.slug}`, lastModified: now, changeFrequency: 'weekly' as const, priority: 0.75 }));

  return [...staticPages, ...productPages, ...occasionPages, ...categoryPages];
}
