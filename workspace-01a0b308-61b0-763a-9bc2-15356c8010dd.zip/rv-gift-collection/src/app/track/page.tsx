import type { Metadata } from 'next';
import { TrackClient } from '@/components/order/TrackClient';

export const metadata: Metadata = { title: 'Track Your Order', robots: { index: false } };

export default function TrackPage() {
  return <TrackClient />;
}
