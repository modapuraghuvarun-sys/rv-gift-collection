import type { Metadata } from 'next';
import Image from 'next/image';
import { notFound } from 'next/navigation';
import { Suspense } from 'react';
import { occasions } from '@/lib/data/catalog';
import { CatalogueBrowser } from '@/components/CatalogueBrowser';

export const dynamicParams = true;

export function generateStaticParams() {
  return occasions.map((o) => ({ slug: o.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const occasion = occasions.find((o) => o.slug === params.slug);
  if (!occasion) return {};
  return {
    title: `${occasion.name} Gifts`,
    description: `Personalized ${occasion.name.toLowerCase()} gifts — ${occasion.blurb.toLowerCase()}.`,
    alternates: { canonical: `/occasion/${occasion.slug}` },
    openGraph: { images: [{ url: occasion.image, width: 800, height: 1000, alt: occasion.name }] },
  };
}

export default function OccasionPage({ params }: { params: { slug: string } }) {
  const occasion = occasions.find((o) => o.slug === params.slug);
  if (!occasion) notFound();

  return (
    <>
      <section className="relative h-64 overflow-hidden md:h-80">
        <Image src={occasion.image} alt={occasion.name} fill priority sizes="100vw" className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-burgundy-950/80 to-burgundy-950/20" />
        <div className="shell absolute bottom-0 left-0 right-0 pb-8">
          <p className="eyebrow text-gold-300">Shop by occasion</p>
          <h1 className="mt-1 font-display text-3xl text-cream-50 md:text-4xl">{occasion.name} Gifts</h1>
          <p className="mt-1 max-w-md text-sm text-cream-100/80">{occasion.blurb}</p>
        </div>
      </section>
      <Suspense>
        <CatalogueBrowser />
      </Suspense>
    </>
  );
}
