import { cookies } from 'next/headers';
import { getSession } from '@/lib/store';

/**
 * Server-side admin authorization. The browser is untrusted: role checks are
 * always re-done here from the server session, never from request bodies or
 * client-supplied flags.
 *
 * Production: Supabase Auth session + `staff_roles` table lookup + MFA
 * enforcement; every admin mutation is also written to `audit_logs`.
 */
export function requireStaff(): { ok: true; actor: string } | { ok: false; status: 401 | 403 } {
  const session = getSession(cookies().get('rv_session')?.value);
  if (!session) return { ok: false, status: 401 };
  if (session.role !== 'staff') return { ok: false, status: 403 };
  return { ok: true, actor: session.userId ?? 'staff' };
}
