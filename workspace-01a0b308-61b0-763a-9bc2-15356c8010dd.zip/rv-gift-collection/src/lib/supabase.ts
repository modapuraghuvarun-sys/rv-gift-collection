import { createClient, type SupabaseClient } from '@supabase/supabase-js';

/**
 * Supabase client factory.
 *
 * The browser client uses ONLY the anon key — Row Level Security
 * (supabase/migrations/0002_rls_storage.sql) enforces all data access.
 *
 * The service-role key is server-only and must NEVER be exposed via
 * NEXT_PUBLIC variables or shipped to the browser.
 */

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

export function isSupabaseConfigured(): boolean {
  return Boolean(
    SUPABASE_URL &&
      SUPABASE_ANON_KEY &&
      !SUPABASE_URL.includes('your-project-ref') &&
      !SUPABASE_ANON_KEY.includes('your-anon'),
  );
}

let browserClient: SupabaseClient | null = null;

/** Browser client (anon key only, RLS enforced). */
export function getSupabaseBrowser(): SupabaseClient | null {
  if (!isSupabaseConfigured()) return null;
  if (!browserClient) {
    browserClient = createClient(SUPABASE_URL!, SUPABASE_ANON_KEY!, {
      auth: { persistSession: true, autoRefreshToken: true },
    });
  }
  return browserClient;
}

let serverClient: SupabaseClient | null = null;

/**
 * Server-only admin client (service role). Import ONLY from route handlers
 * / server modules. Bypasses RLS — use with explicit permission checks.
 */
export function getSupabaseAdmin(): SupabaseClient | null {
  if (!isSupabaseConfigured() || !SERVICE_ROLE_KEY) return null;
  if (!serverClient) {
    serverClient = createClient(SUPABASE_URL!, SERVICE_ROLE_KEY, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
  }
  return serverClient;
}
