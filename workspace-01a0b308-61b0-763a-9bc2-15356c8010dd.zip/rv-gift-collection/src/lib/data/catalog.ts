import type {
  CategoryInfo,
  Coupon,
  DeliveryRules,
  OccasionInfo,
  PersonalisationTemplate,
  Product,
  RecipientInfo,
} from '@/lib/types';

/**
 * Demo catalogue. In production this lives in Supabase (products,
 * product_variants, product_images, collections, personalisation_templates)
 * and is managed from Admin → Catalogue.
 *
 * Prices are integer paise, GST inclusive. No invented sales figures,
 * bestseller rankings or delivery guarantees — see PRD §39.
 */

export const categories: CategoryInfo[] = [
  { slug: 'mugs', name: 'Mugs', blurb: 'Photo & name mugs for everyday gifting', image: '/images/cat-mugs.jpg' },
  { slug: 'frames', name: 'Frames', blurb: 'Wooden and collage frames for your favourite memories', image: '/images/cat-frames.jpg' },
  { slug: 'cushions', name: 'Cushions', blurb: 'Photo cushions that make a house feel like home', image: '/images/cat-cushions.jpg' },
  { slug: 'keychains', name: 'Keychains', blurb: 'Small keepsakes with names and photos', image: '/images/cat-keychains.jpg' },
  { slug: 'lamps', name: 'Lamps', blurb: 'Engraved lamps that glow with memories', image: '/images/cat-lamps.jpg' },
  { slug: 'stationery', name: 'Stationery', blurb: 'Notebooks, pens and desk keepsakes', image: '/images/cat-stationery.jpg' },
  { slug: 'gift-hampers', name: 'Gift Hampers', blurb: 'Curated personalised bundles for big moments', image: '/images/cat-hampers.jpg' },
];

export const occasions: OccasionInfo[] = [
  { slug: 'birthday', name: 'Birthday', blurb: 'Personalised surprises for their special day', image: '/images/occ-birthday.jpg' },
  { slug: 'anniversary', name: 'Anniversary', blurb: 'Celebrate the years that matter', image: '/images/occ-anniversary.jpg' },
  { slug: 'wedding', name: 'Wedding', blurb: 'Keepsakes for the couple and their families', image: '/images/occ-wedding.jpg' },
  { slug: 'festive', name: 'Festive', blurb: 'Diwali, Rakhi and every festival of light', image: '/images/occ-festive.jpg' },
  { slug: 'housewarming', name: 'Housewarming', blurb: 'Warm beginnings for a new home', image: '/images/occ-housewarming.jpg' },
];

export const recipients: RecipientInfo[] = [
  { slug: 'for-her', name: 'For Her', blurb: 'Thoughtful gifts she will keep forever', image: '/images/occ-anniversary.jpg' },
  { slug: 'for-him', name: 'For Him', blurb: 'Practical keepsakes with a personal touch', image: '/images/cat-stationery.jpg' },
  { slug: 'for-couples', name: 'For Couples', blurb: 'Weddings, anniversaries and new beginnings', image: '/images/occ-wedding.jpg' },
  { slug: 'for-parents', name: 'For Parents', blurb: 'Memories they raised, framed with love', image: '/images/cat-frames.jpg' },
  { slug: 'for-friends', name: 'For Friends', blurb: 'Little things that say a lot', image: '/images/cat-mugs.jpg' },
  { slug: 'for-colleagues', name: 'For Colleagues', blurb: 'Desk-friendly gifts that stay professional', image: '/images/cat-keychains.jpg' },
];

export const collectionList: { slug: string; name: string; featured: boolean }[] = [
  { slug: 'signature', name: 'RV Signature', featured: true },
  { slug: 'wedding-edit', name: 'The Wedding Edit', featured: true },
  { slug: 'under-999', name: 'Gifts Under ₹999', featured: false },
  { slug: 'corporate', name: 'Corporate Gifting', featured: false },
];

// ── Personalisation templates ────────────────────────────────────────────────
// Template coordinates are normalised on a 600x600 preview canvas.

function tpl(
  id: string,
  layout: PersonalisationTemplate['layout'],
  printArea: PersonalisationTemplate['printArea'],
  opts?: Partial<Omit<PersonalisationTemplate, 'id' | 'layout' | 'printArea'>>,
): PersonalisationTemplate {
  return {
    id,
    version: 1,
    layout,
    fields: [
      { key: 'name', label: 'Name', type: 'text', required: true, maxLength: 24, placeholder: 'e.g. Ananya' },
      { key: 'message', label: 'Gift message', type: 'message', required: false, maxLength: 140, placeholder: 'Optional message printed on the gift' },
    ],
    photos: { count: 1, minPx: 800, maxPx: 6000 },
    printArea,
    textColors: ['#431026', '#FFFFFF', '#C29A3B', '#241C18'],
    ...opts,
  };
}

const templateMug = tpl('tpl-mug', 'mug', { x: 0.3, y: 0.3, w: 0.4, h: 0.42, shape: 'rect' }, {});
const templateFrame = tpl('tpl-frame', 'frame', { x: 0.22, y: 0.18, w: 0.56, h: 0.56, shape: 'rect' }, {
  photos: { count: 1, minPx: 900, maxPx: 6000 },
});
const templateCollage = tpl('tpl-collage', 'frame', { x: 0.2, y: 0.16, w: 0.6, h: 0.6, shape: 'rect' }, {
  photos: { count: 4, minPx: 700, maxPx: 6000 },
});
const templateCushion = tpl('tpl-cushion', 'cushion', { x: 0.25, y: 0.25, w: 0.5, h: 0.5, shape: 'rect' }, {});
const templateKeychain = tpl('tpl-keychain', 'keychain', { x: 0.36, y: 0.36, w: 0.28, h: 0.28, shape: 'circle' }, {
  photos: { count: 0, minPx: 0, maxPx: 0 },
  fields: [
    { key: 'name', label: 'Text to engrave', type: 'text', required: true, maxLength: 12, placeholder: 'e.g. A&R' },
  ],
});
const templateKeychainPhoto = tpl('tpl-keychain-photo', 'keychain', { x: 0.34, y: 0.34, w: 0.32, h: 0.32, shape: 'circle' }, {
  photos: { count: 1, minPx: 600, maxPx: 6000 },
  fields: [
    { key: 'name', label: 'Name on back', type: 'text', required: false, maxLength: 12, placeholder: 'Optional' },
  ],
});
const templateLamp = tpl('tpl-lamp', 'lamp', { x: 0.3, y: 0.22, w: 0.4, h: 0.5, shape: 'rect' }, {
  photos: { count: 0, minPx: 0, maxPx: 0 },
  fields: [
    { key: 'name', label: 'Names / text to engrave', type: 'text', required: true, maxLength: 26, placeholder: 'e.g. Aarav & Diya' },
    { key: 'date', label: 'Special date', type: 'text', required: false, maxLength: 16, placeholder: 'e.g. 14 Feb 2026' },
  ],
});
const templateLampPhoto = tpl('tpl-lamp-photo', 'lamp', { x: 0.32, y: 0.2, w: 0.36, h: 0.5, shape: 'rect' }, {});
const templateNotebook = tpl('tpl-notebook', 'notebook', { x: 0.3, y: 0.4, w: 0.4, h: 0.2, shape: 'rect' }, {
  photos: { count: 0, minPx: 0, maxPx: 0 },
  fields: [
    { key: 'name', label: 'Name / monogram', type: 'text', required: true, maxLength: 20, placeholder: 'e.g. Meera S.' },
  ],
});
const templateHamper = tpl('tpl-hamper', 'hamper', { x: 0.32, y: 0.34, w: 0.36, h: 0.34, shape: 'rect' }, {
  fields: [
    { key: 'name', label: 'Name on mug', type: 'text', required: true, maxLength: 20 },
    { key: 'message', label: 'Gift note card', type: 'message', required: false, maxLength: 180, placeholder: 'We hand-write this on a card' },
  ],
});

// ── Products ─────────────────────────────────────────────────────────────────

export const products: Product[] = [
  {
    id: 'p-mug-classic',
    slug: 'personalised-photo-mug',
    name: 'Classic Personalised Photo Mug',
    category: 'mugs',
    shortDescription: 'Ceramic 330 ml mug printed edge-to-edge with your photo and name.',
    description:
      'Our signature ceramic mug, printed with your photograph and a name of your choice. The print wraps the body of the mug and is sealed for everyday use. A simple, emotional gift that gets used every single day.',
    material: 'Food-safe glazed ceramic, 330 ml',
    dimensions: '9.5 cm × 8 cm (H × Ø)',
    care: 'Hand wash recommended. Avoid abrasive scrubbers on the printed area. Not microwave-safe for extended use.',
    leadTimeDays: 1,
    images: ['/images/cat-mugs.jpg', '/images/hero.jpg'],
    occasions: ['birthday', 'anniversary', 'festive'],
    recipients: ['for-her', 'for-him', 'for-friends', 'for-colleagues'],
    collections: ['signature', 'under-999'],
    featured: true,
    status: 'published',
    personalisation: templateMug,
    variants: [
      { id: 'v-mug-ivory', sku: 'RV-MUG-CL-IV', name: 'Ivory', attributes: { Colour: 'Ivory' }, price: 49900, taxRate: 18, available: true },
      { id: 'v-mug-burgundy', sku: 'RV-MUG-CL-BG', name: 'Burgundy Interior', attributes: { Colour: 'Burgundy' }, price: 54900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-mug-magic',
    slug: 'magic-colour-change-mug',
    name: 'Magic Colour-Change Photo Mug',
    category: 'mugs',
    shortDescription: 'Your photo appears like magic when hot liquid is poured in.',
    description:
      'A heat-sensitive ceramic mug that reveals your printed photo when filled with a hot drink. Starts matte dark and transitions in seconds — a favourite for surprise gifting.',
    material: 'Heat-sensitive coated ceramic, 330 ml',
    dimensions: '9.5 cm × 8 cm (H × Ø)',
    care: 'Hand wash only. Do not microwave — heat coating is sensitive.',
    leadTimeDays: 2,
    images: ['/images/cat-mugs.jpg'],
    occasions: ['birthday', 'festive'],
    recipients: ['for-friends', 'for-her', 'for-him'],
    collections: ['signature'],
    featured: false,
    status: 'published',
    personalisation: templateMug,
    variants: [
      { id: 'v-magic-std', sku: 'RV-MUG-MG-BK', name: 'Matte Black', attributes: { Colour: 'Matte Black' }, price: 64900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-mug-couple',
    slug: 'wedding-couple-names-mug',
    name: 'Couple Names Wedding Mug',
    category: 'mugs',
    shortDescription: 'Names and wedding date printed in an elegant gold-toned layout.',
    description:
      'Designed for weddings and engagements: both names with your wedding date in our classic serif layout. Pairs beautifully with The Wedding Edit hampers.',
    material: 'Food-safe glazed ceramic, 330 ml',
    dimensions: '9.5 cm × 8 cm (H × Ø)',
    care: 'Hand wash recommended.',
    leadTimeDays: 1,
    images: ['/images/cat-mugs.jpg', '/images/occ-wedding.jpg'],
    occasions: ['wedding', 'anniversary'],
    recipients: ['for-couples'],
    collections: ['wedding-edit', 'under-999'],
    featured: false,
    status: 'published',
    personalisation: {
      ...templateMug,
      id: 'tpl-mug-couple',
      photos: { count: 0, minPx: 0, maxPx: 0 },
      fields: [
        { key: 'name', label: 'First name', type: 'text', required: true, maxLength: 14, placeholder: 'e.g. Aarav' },
        { key: 'name2', label: 'Second name', type: 'text', required: true, maxLength: 14, placeholder: 'e.g. Diya' },
        { key: 'date', label: 'Wedding date', type: 'text', required: false, maxLength: 18, placeholder: 'e.g. 24 Nov 2026' },
      ],
    },
    variants: [
      { id: 'v-couple-ivory', sku: 'RV-MUG-CP-IV', name: 'Ivory & Gold', attributes: { Colour: 'Ivory & Gold' }, price: 59900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-frame-wood',
    slug: 'wooden-photo-frame-a5',
    name: 'Wooden Photo Frame',
    category: 'frames',
    shortDescription: 'Warm wooden frame with your photo printed on premium matte paper.',
    description:
      'A solid wooden frame finished in warm walnut tone, fitted with your photograph printed on premium 230 gsm matte paper. Ready to hang or stand on a desk.',
    material: 'Mango wood frame, 230 gsm matte print',
    dimensions: 'A5 (21 × 14.8 cm) portrait or landscape',
    care: 'Wipe with a dry cloth. Keep away from direct water.',
    leadTimeDays: 2,
    images: ['/images/cat-frames.jpg', '/images/hero.jpg'],
    occasions: ['anniversary', 'wedding', 'housewarming'],
    recipients: ['for-parents', 'for-couples', 'for-her'],
    collections: ['signature'],
    featured: true,
    status: 'published',
    personalisation: templateFrame,
    variants: [
      { id: 'v-frame-a5', sku: 'RV-FRM-WD-A5', name: 'A5', attributes: { Size: 'A5' }, price: 89900, taxRate: 18, available: true },
      { id: 'v-frame-a4', sku: 'RV-FRM-WD-A4', name: 'A4', attributes: { Size: 'A4' }, price: 129900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-frame-collage',
    slug: 'four-photo-collage-frame',
    name: '4-Photo Collage Frame',
    category: 'frames',
    shortDescription: 'Four favourite memories arranged in a single elegant frame.',
    description:
      'Upload four photos and we arrange them in a balanced grid inside a warm wooden frame. A favourite for parents and anniversaries.',
    material: 'Mango wood frame, 230 gsm matte prints',
    dimensions: '30 × 30 cm',
    care: 'Wipe with a dry cloth.',
    leadTimeDays: 2,
    images: ['/images/cat-frames.jpg'],
    occasions: ['anniversary', 'housewarming', 'festive'],
    recipients: ['for-parents', 'for-couples'],
    collections: ['wedding-edit'],
    featured: false,
    status: 'published',
    personalisation: templateCollage,
    variants: [
      { id: 'v-collage-std', sku: 'RV-FRM-CO-30', name: '30 × 30 cm', attributes: { Size: '30 × 30 cm' }, price: 149900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-frame-name',
    slug: 'engraved-name-frame',
    name: 'Engraved MDF Name Frame',
    category: 'frames',
    shortDescription: 'Laser-engraved names in an elegant frame — no photo needed.',
    description:
      'Names or a short line engraved into a warm MDF panel inside a classic frame. A clean choice when you want words instead of pictures.',
    material: 'Laser-engraved MDF, wooden frame',
    dimensions: 'A5 (21 × 14.8 cm)',
    care: 'Wipe with a dry cloth.',
    leadTimeDays: 2,
    images: ['/images/cat-frames.jpg', '/images/occ-wedding.jpg'],
    occasions: ['wedding', 'housewarming'],
    recipients: ['for-couples', 'for-parents'],
    collections: ['wedding-edit', 'under-999'],
    featured: false,
    status: 'published',
    personalisation: {
      ...templateFrame,
      id: 'tpl-frame-name',
      photos: { count: 0, minPx: 0, maxPx: 0 },
      fields: [
        { key: 'name', label: 'Names to engrave', type: 'text', required: true, maxLength: 30, placeholder: 'e.g. The Sharma Family' },
        { key: 'date', label: 'Date or short line', type: 'text', required: false, maxLength: 24 },
      ],
    },
    variants: [
      { id: 'v-nameframe-std', sku: 'RV-FRM-NM-A5', name: 'A5', attributes: { Size: 'A5' }, price: 119900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-cushion-photo',
    slug: 'personalised-photo-cushion',
    name: 'Personalised Photo Cushion',
    category: 'cushions',
    shortDescription: 'Your photo printed on a soft plush cushion with hidden zip.',
    description:
      'A soft plush cushion printed with your photograph on one side and plain cream on the reverse. Includes fibre filling and a hidden zip for easy washing.',
    material: 'Plush polyester cover, fibre fill',
    dimensions: 'Available in 12 inch and 16 inch square',
    care: 'Machine wash cold on gentle cycle. Do not bleach. Air dry.',
    leadTimeDays: 2,
    images: ['/images/cat-cushions.jpg', '/images/hero.jpg'],
    occasions: ['birthday', 'anniversary', 'housewarming'],
    recipients: ['for-her', 'for-parents', 'for-couples'],
    collections: ['signature'],
    featured: true,
    status: 'published',
    personalisation: templateCushion,
    variants: [
      { id: 'v-cush-12', sku: 'RV-CUS-PH-12', name: '12 inch', attributes: { Size: '12 inch' }, price: 79900, taxRate: 18, available: true },
      { id: 'v-cush-16', sku: 'RV-CUS-PH-16', name: '16 inch', attributes: { Size: '16 inch' }, price: 99900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-cushion-velvet',
    slug: 'velvet-name-cushion',
    name: 'Velvet Name Cushion',
    category: 'cushions',
    shortDescription: 'Deep velvet cushion with a name printed in gold-toned serif.',
    description:
      'Rich burgundy velvet with a single name or short line printed in an elegant gold-toned serif. Quietly luxurious, made to be kept.',
    material: 'Velvet cover, fibre fill',
    dimensions: '16 inch square',
    care: 'Spot clean only.',
    leadTimeDays: 2,
    images: ['/images/cat-cushions.jpg'],
    occasions: ['anniversary', 'wedding', 'festive'],
    recipients: ['for-her', 'for-couples'],
    collections: ['signature', 'wedding-edit'],
    featured: false,
    status: 'published',
    personalisation: {
      ...templateCushion,
      id: 'tpl-cushion-velvet',
      photos: { count: 0, minPx: 0, maxPx: 0 },
      fields: [{ key: 'name', label: 'Name', type: 'text', required: true, maxLength: 16, placeholder: 'e.g. Ananya' }],
    },
    variants: [
      { id: 'v-velvet-bg', sku: 'RV-CUS-VL-BG', name: 'Burgundy', attributes: { Colour: 'Burgundy' }, price: 99900, taxRate: 18, available: true },
      { id: 'v-velvet-sg', sku: 'RV-CUS-VL-SG', name: 'Sage', attributes: { Colour: 'Sage' }, price: 99900, taxRate: 18, available: false },
    ],
  },
  {
    id: 'p-keychain-leather',
    slug: 'engraved-leather-keychain',
    name: 'Engraved Leather Keychain',
    category: 'keychains',
    shortDescription: 'Tan leather keychain engraved with initials — a small daily reminder.',
    description:
      'Vegetable-tanned leather keychain with up to twelve characters engraved in a clean serif, finished with a gold-tone ring.',
    material: 'Vegetable-tanned leather, brass ring',
    dimensions: '10 × 3 cm',
    care: 'Keep dry. Leather darkens naturally with use.',
    leadTimeDays: 1,
    images: ['/images/cat-keychains.jpg'],
    occasions: ['birthday', 'festive'],
    recipients: ['for-him', 'for-colleagues', 'for-friends'],
    collections: ['under-999', 'corporate'],
    featured: false,
    status: 'published',
    personalisation: templateKeychain,
    variants: [
      { id: 'v-key-tan', sku: 'RV-KEY-LT-TN', name: 'Tan', attributes: { Colour: 'Tan' }, price: 29900, taxRate: 18, available: true },
      { id: 'v-key-brown', sku: 'RV-KEY-LT-BR', name: 'Dark Brown', attributes: { Colour: 'Dark Brown' }, price: 29900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-keychain-photo',
    slug: 'double-sided-photo-keychain',
    name: 'Double-Sided Photo Keychain',
    category: 'keychains',
    shortDescription: 'Your photo sealed inside acrylic on both sides.',
    description:
      'A photo sealed inside clear acrylic with a gold-tone ring. Optional name on the reverse. Small enough for keys, meaningful enough to keep.',
    material: 'Acrylic, brass ring',
    dimensions: '4 × 4 cm',
    care: 'Wipe clean with a soft cloth.',
    leadTimeDays: 1,
    images: ['/images/cat-keychains.jpg', '/images/cat-mugs.jpg'],
    occasions: ['birthday', 'anniversary'],
    recipients: ['for-friends', 'for-her'],
    collections: ['under-999'],
    featured: false,
    status: 'published',
    personalisation: templateKeychainPhoto,
    variants: [
      { id: 'v-keyp-std', sku: 'RV-KEY-PH-AC', name: 'Clear Acrylic', attributes: { Finish: 'Clear' }, price: 34900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-lamp-wood',
    slug: 'engraved-wooden-lamp',
    name: 'Engraved Wooden LED Lamp',
    category: 'lamps',
    shortDescription: 'Names and dates laser-engraved on a warm glowing wooden panel.',
    description:
      'A laser-engraved wooden panel on a warm LED base. When lit, the engraving glows softly — made for bedside tables and quiet corners.',
    material: 'Beech wood panel, USB LED base',
    dimensions: '20 × 15 cm panel',
    care: 'Wipe with a dry cloth. Indoor use only.',
    leadTimeDays: 2,
    images: ['/images/cat-lamps.jpg', '/images/hero.jpg'],
    occasions: ['anniversary', 'wedding', 'birthday'],
    recipients: ['for-couples', 'for-parents', 'for-her'],
    collections: ['signature'],
    featured: true,
    status: 'published',
    personalisation: templateLamp,
    variants: [
      { id: 'v-lamp-std', sku: 'RV-LMP-WD-BE', name: 'Beech / Warm White', attributes: { Wood: 'Beech', Light: 'Warm White' }, price: 129900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-lamp-acrylic',
    slug: 'photo-acrylic-lamp',
    name: 'Photo Acrylic Lamp',
    category: 'lamps',
    shortDescription: 'Your photo edge-lit on crystal-clear acrylic with a wooden base.',
    description:
      'Your photograph is printed on crystal-clear acrylic and edge-lit by a wooden LED base. The image appears to float when the lamp is on.',
    material: 'Cast acrylic, wooden USB base',
    dimensions: '18 × 13 cm panel',
    care: 'Wipe gently with a microfibre cloth.',
    leadTimeDays: 2,
    images: ['/images/cat-lamps.jpg'],
    occasions: ['birthday', 'anniversary'],
    recipients: ['for-her', 'for-friends'],
    collections: ['signature'],
    featured: false,
    status: 'published',
    personalisation: templateLampPhoto,
    variants: [
      { id: 'v-lampa-std', sku: 'RV-LMP-AC-WD', name: 'Wood Base / Warm White', attributes: { Base: 'Wood', Light: 'Warm White' }, price: 159900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-stationery-set',
    slug: 'personalised-notebook-set',
    name: 'Personalised Notebook Set',
    category: 'stationery',
    shortDescription: 'Kraft notebook and pen with an embossed name — ready for desk or diary.',
    description:
      'A 192-page ruled kraft notebook with your name embossed on the cover, paired with a smooth-writing metal pen in a burgundy gift box.',
    material: 'Kraft hardbound notebook, metal pen',
    dimensions: 'A5 notebook, 192 pages',
    care: 'Keep away from water.',
    leadTimeDays: 1,
    images: ['/images/cat-stationery.jpg', '/images/hero.jpg'],
    occasions: ['birthday', 'festive'],
    recipients: ['for-colleagues', 'for-him', 'for-friends'],
    collections: ['under-999', 'corporate'],
    featured: true,
    status: 'published',
    personalisation: templateNotebook,
    variants: [
      { id: 'v-note-kraft', sku: 'RV-STA-NB-KR', name: 'Kraft', attributes: { Cover: 'Kraft' }, price: 69900, taxRate: 18, available: true },
      { id: 'v-note-black', sku: 'RV-STA-NB-BK', name: 'Black', attributes: { Cover: 'Black' }, price: 69900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-pen-set',
    slug: 'engraved-pen-gift-set',
    name: 'Engraved Pen Gift Set',
    category: 'stationery',
    shortDescription: 'A weighted metal pen engraved with a name, in a lined gift box.',
    description:
      'A weighted metal rollerball pen engraved with a name or short line, presented in a burgundy gift box with a refill. A dependable corporate and personal gift.',
    material: 'Metal rollerball, gift box',
    dimensions: '14 cm pen',
    care: 'Standard refill included.',
    leadTimeDays: 1,
    images: ['/images/cat-stationery.jpg'],
    occasions: ['festive', 'birthday'],
    recipients: ['for-colleagues', 'for-him'],
    collections: ['corporate', 'under-999'],
    featured: false,
    status: 'published',
    personalisation: {
      ...templateNotebook,
      id: 'tpl-pen',
      fields: [{ key: 'name', label: 'Text to engrave', type: 'text', required: true, maxLength: 18, placeholder: 'e.g. R. Venkatesh' }],
    },
    variants: [
      { id: 'v-pen-gold', sku: 'RV-STA-PN-GD', name: 'Gold Tone', attributes: { Finish: 'Gold Tone' }, price: 89900, taxRate: 18, available: true },
      { id: 'v-pen-gun', sku: 'RV-STA-PN-GN', name: 'Gunmetal', attributes: { Finish: 'Gunmetal' }, price: 89900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-hamper-celebration',
    slug: 'celebration-gift-hamper',
    name: 'Celebration Gift Hamper',
    category: 'gift-hampers',
    shortDescription: 'Personalised mug, notebook and keychain bundled in a keepsake box.',
    description:
      'A burgundy keepsake box containing a personalised photo mug, an embossed notebook and a leather keychain, with a hand-written gift note card if you add a message.',
    material: 'Mixed — see individual products',
    dimensions: '28 × 22 × 10 cm box',
    care: 'See individual product care notes.',
    leadTimeDays: 2,
    images: ['/images/cat-hampers.jpg', '/images/hero.jpg'],
    occasions: ['birthday', 'festive'],
    recipients: ['for-her', 'for-friends'],
    collections: ['signature'],
    featured: true,
    status: 'published',
    personalisation: templateHamper,
    variants: [
      { id: 'v-hamp-classic', sku: 'RV-HAM-CL-BX', name: 'Classic Box', attributes: { Box: 'Classic' }, price: 249900, taxRate: 18, available: true },
      { id: 'v-hamp-premium', sku: 'RV-HAM-PR-BX', name: 'Premium Box (adds candle)', attributes: { Box: 'Premium' }, price: 299900, taxRate: 18, available: true },
    ],
  },
  {
    id: 'p-hamper-wedding',
    slug: 'wedding-keepsake-hamper',
    name: 'Wedding Keepsake Hamper',
    category: 'gift-hampers',
    shortDescription: 'Couple mugs, name frame and a note card in The Wedding Edit box.',
    description:
      'Our wedding signature: a pair of couple-name mugs, an engraved name frame and a hand-written note card, arranged in The Wedding Edit box with gold ribbon.',
    material: 'Mixed — see individual products',
    dimensions: '32 × 26 × 12 cm box',
    care: 'See individual product care notes.',
    leadTimeDays: 3,
    images: ['/images/cat-hampers.jpg', '/images/occ-wedding.jpg'],
    occasions: ['wedding'],
    recipients: ['for-couples'],
    collections: ['wedding-edit'],
    featured: false,
    status: 'published',
    personalisation: {
      ...templateHamper,
      id: 'tpl-hamper-wedding',
      photos: { count: 0, minPx: 0, maxPx: 0 },
      fields: [
        { key: 'name', label: 'First name', type: 'text', required: true, maxLength: 14 },
        { key: 'name2', label: 'Second name', type: 'text', required: true, maxLength: 14 },
        { key: 'message', label: 'Gift note card', type: 'message', required: false, maxLength: 180 },
      ],
    },
    variants: [
      { id: 'v-hampw-std', sku: 'RV-HAM-WD-BX', name: 'Wedding Edit Box', attributes: { Box: 'Wedding Edit' }, price: 349900, taxRate: 18, available: true },
    ],
  },
];

// ── Coupons (server-validated) ───────────────────────────────────────────────

const daysFromNow = (d: number) => new Date(Date.now() + d * 86400000).toISOString();

export const seedCoupons: Coupon[] = [
  {
    code: 'RVWELCOME',
    description: '₹100 off your first order above ₹599',
    kind: 'flat',
    value: 10000,
    minSubtotal: 59900,
    startsAt: daysFromNow(-30),
    expiresAt: daysFromNow(120),
    usageLimit: 5000,
    perCustomerLimit: 1,
    redeemed: 12,
    active: true,
  },
  {
    code: 'FESTIVE10',
    description: '10% off (up to ₹300) on orders above ₹999',
    kind: 'percent',
    value: 10,
    maxDiscount: 30000,
    minSubtotal: 99900,
    startsAt: daysFromNow(-10),
    expiresAt: daysFromNow(45),
    usageLimit: 2000,
    perCustomerLimit: 2,
    redeemed: 40,
    active: true,
  },
  {
    code: 'EXPIRED50',
    description: 'Expired demo coupon (for testing validation)',
    kind: 'flat',
    value: 5000,
    minSubtotal: 0,
    startsAt: daysFromNow(-90),
    expiresAt: daysFromNow(-1),
    usageLimit: 100,
    perCustomerLimit: 1,
    redeemed: 100,
    active: false,
  },
];

// ── Delivery rules ───────────────────────────────────────────────────────────

export const seedDeliveryRules: DeliveryRules = {
  zones: [
    {
      id: 'zone-metro',
      name: 'Metro & nearby (Telangana, AP, KA, TN)',
      pinPrefixes: ['50', '51', '52', '53', '56', '57', '60', '61', '62'],
      transitDays: [2, 3],
      fee: 4900,
      expressFee: 14900,
      expressTransitDays: [1, 2],
    },
    {
      id: 'zone-north',
      name: 'North & West India',
      pinPrefixes: ['1', '2', '3', '4'],
      transitDays: [3, 5],
      fee: 7900,
      expressFee: 19900,
      expressTransitDays: [2, 3],
    },
  ],
  unsupportedPins: ['110099', '799'],
  cutoffHour: 18, // 6 pm IST
  businessDays: [1, 2, 3, 4, 5, 6], // Mon–Sat
  capacityPerDay: 40,
  freeStandardAbove: 99900,
};

/** Default zone for PINs not matching an explicit prefix list. */
export const defaultZone = {
  id: 'zone-rest',
  name: 'Rest of India',
  pinPrefixes: [],
  transitDays: [4, 7] as [number, number],
  fee: 9900,
};
