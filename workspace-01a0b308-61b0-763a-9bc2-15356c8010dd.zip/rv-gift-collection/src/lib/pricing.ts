/**
 * Server-authoritative pricing.
 *
 * The browser NEVER sends totals. It sends line references (product, variant,
 * qty, approved personalisation) and the server recomputes every amount in
 * integer paise: unit price, discounts, tax-inclusive split, delivery and the
 * final total. Quotes expire and are re-validated at order time.
 */

import { checkDelivery } from '@/lib/delivery';
import { validateCoupon } from '@/lib/coupons';
import { store } from '@/lib/store';
import type {
  Address,
  CartLine,
  DeliveryOptionId,
  Product,
  ProductVariant,
  Quote,
  QuoteLineOut,
} from '@/lib/types';
import { taxIncludedIn } from '@/lib/money';
import { formatDateRange, uid } from '@/lib/utils';

export interface BuildQuoteInput {
  lines: CartLine[];
  couponCode?: string;
  deliveryOption?: DeliveryOptionId;
  pincode?: string;
  customerEmail?: string;
}

export interface BuildQuoteResult {
  ok: boolean;
  code?: 'EMPTY_CART' | 'PRODUCT_UNAVAILABLE' | 'VARIANT_UNAVAILABLE' | 'PERSONALISATION_REQUIRED' | 'PERSONALISATION_NOT_APPROVED' | 'OUT_OF_STOCK' | 'PIN_UNSUPPORTED' | 'COUPON_ERROR';
  message?: string;
  quote?: Quote;
}

function findProduct(id: string): Product | undefined {
  return store.products.find((p) => p.id === id);
}

function personalisationSummary(p: Product, line: CartLine): Record<string, string> | undefined {
  if (!line.personalisation) return undefined;
  const out: Record<string, string> = {};
  for (const f of p.personalisation?.fields ?? []) {
    const val = line.personalisation.fields[f.key];
    if (val) out[f.label] = val;
  }
  if (line.personalisation.assetIds.length) out['Photos'] = `${line.personalisation.assetIds.length}`;
  return out;
}

export function buildQuote(input: BuildQuoteInput): BuildQuoteResult {
  const { lines, couponCode, deliveryOption = 'standard', pincode, customerEmail } = input;

  if (!lines.length) {
    return { ok: false, code: 'EMPTY_CART', message: 'Your cart is empty.' };
  }

  const quoteLines: QuoteLineOut[] = [];
  let subtotal = 0;
  const stockNeed = new Map<string, number>();

  for (const line of lines) {
    const product = findProduct(line.productId);
    if (!product || product.status !== 'published') {
      return { ok: false, code: 'PRODUCT_UNAVAILABLE', message: 'One of the items in your cart is no longer available.' };
    }
    const variant: ProductVariant | undefined = product.variants.find((v) => v.id === line.variantId);
    if (!variant || !variant.available) {
      return { ok: false, code: 'VARIANT_UNAVAILABLE', message: `${product.name}: the selected option is unavailable.` };
    }
    if (product.personalisation) {
      if (!line.personalisation) {
        return { ok: false, code: 'PERSONALISATION_REQUIRED', message: `${product.name} needs to be personalised before checkout.` };
      }
      if (!line.personalisation.approvedAt) {
        return { ok: false, code: 'PERSONALISATION_NOT_APPROVED', message: `Please review and approve the personalisation for ${product.name}.` };
      }
    }
    const lineTotal = variant.price * line.qty;
    subtotal += lineTotal;
    stockNeed.set(variant.sku, (stockNeed.get(variant.sku) ?? 0) + line.qty);
    quoteLines.push({
      lineId: line.id,
      productId: product.id,
      slug: product.slug,
      variantId: variant.id,
      name: product.name,
      variantName: variant.name,
      image: product.images[0],
      qty: line.qty,
      unitPrice: variant.price,
      lineTotal,
      hasPersonalisation: Boolean(product.personalisation),
      personalisationSummary: personalisationSummary(product, line),
    });
  }

  // Stock availability check against live on-hand minus reserved.
  for (const [sku, qty] of stockNeed) {
    const rec = store.inventory.get(sku);
    const available = rec ? rec.onHand - rec.reserved : 0;
    if (available < qty) {
      return {
        ok: false,
        code: 'OUT_OF_STOCK',
        message: `Only ${available} unit(s) left for one of your items. Please reduce the quantity.`,
      };
    }
  }

  // Coupon (server-validated).
  let discount = 0;
  let appliedCode: string | undefined;
  if (couponCode) {
    const check = validateCoupon(couponCode, subtotal, customerEmail);
    if (!check.ok) {
      return { ok: false, code: 'COUPON_ERROR', message: check.message };
    }
    discount = check.discount ?? 0;
    appliedCode = check.coupon?.code;
  }

  // Delivery: use the slowest lead-time product for the window estimate.
  let deliveryFee = 0;
  let deliveryWindow: string | undefined;
  let representativeProduct: Product | undefined;
  for (const line of lines) {
    const p = findProduct(line.productId)!;
    if (!representativeProduct || p.leadTimeDays > representativeProduct.leadTimeDays) representativeProduct = p;
  }

  if (pincode && representativeProduct) {
    const check = checkDelivery(pincode, representativeProduct, 1);
    if (!check.serviceable) {
      return { ok: false, code: 'PIN_UNSUPPORTED', message: check.reason };
    }
    const discountedSubtotal = subtotal - discount;
    if (deliveryOption === 'express' && check.expressAvailable && check.expressFee !== undefined) {
      deliveryFee = check.expressFee;
      deliveryWindow = formatDateRange(check.expressWindowStart, check.expressWindowEnd);
    } else {
      deliveryFee = discountedSubtotal >= store.deliveryRules.freeStandardAbove ? 0 : check.standardFee;
      deliveryWindow = formatDateRange(check.windowStart, check.windowEnd);
    }
  }

  const total = subtotal - discount + deliveryFee;
  const taxIncluded = quoteLines.reduce((acc, l) => {
    const product = findProduct(l.productId)!;
    const variant = product.variants.find((v) => v.id === l.variantId)!;
    return acc + taxIncludedIn(l.lineTotal, variant.taxRate);
  }, 0);

  const now = new Date();
  const quote: Quote = {
    id: uid('q'),
    createdAt: now.toISOString(),
    expiresAt: new Date(now.getTime() + 10 * 60000).toISOString(),
    lines: quoteLines,
    subtotal,
    discount,
    couponCode: appliedCode,
    taxIncluded,
    deliveryFee,
    deliveryOption,
    deliveryWindow,
    total,
    currency: 'INR',
  };
  store.quotes.set(quote.id, quote);
  return { ok: true, quote };
}

export function getQuote(id: string): Quote | undefined {
  return store.quotes.get(id);
}

export function isQuoteExpired(q: Quote): boolean {
  return new Date(q.expiresAt).getTime() < Date.now();
}

/** Convenience for address shape validation. */
export function addressIncomplete(a: Address): string | null {
  if (!a.fullName || !a.phone || !a.line1 || !a.city || !a.state || !a.pincode) return 'Address is incomplete.';
  return null;
}
