/**
 * Server-side coupon validation. The browser is never trusted — every coupon
 * is re-validated when the quote is created and again at order time.
 */

import { store } from '@/lib/store';
import type { Coupon } from '@/lib/types';
import { percentOf } from '@/lib/money';

export interface CouponCheck {
  ok: boolean;
  code?: 'COUPON_INVALID' | 'COUPON_EXPIRED' | 'COUPON_NOT_STARTED' | 'COUPON_LIMIT_REACHED' | 'COUPON_MIN_ORDER' | 'COUPON_PER_CUSTOMER';
  message?: string;
  discount?: number;
  coupon?: Coupon;
}

export function validateCoupon(code: string, subtotal: number, customerEmail?: string): CouponCheck {
  const coupon = store.coupons.find((c) => c.code.toUpperCase() === code.trim().toUpperCase());
  if (!coupon || !coupon.active) {
    return { ok: false, code: 'COUPON_INVALID', message: 'This coupon code is not valid.' };
  }
  const now = new Date();
  if (new Date(coupon.startsAt) > now) {
    return { ok: false, code: 'COUPON_NOT_STARTED', message: 'This coupon is not active yet.' };
  }
  if (new Date(coupon.expiresAt) < now) {
    return { ok: false, code: 'COUPON_EXPIRED', message: 'This coupon has expired.' };
  }
  if (coupon.redeemed >= coupon.usageLimit) {
    return { ok: false, code: 'COUPON_LIMIT_REACHED', message: 'This coupon has reached its usage limit.' };
  }
  if (subtotal < coupon.minSubtotal) {
    return {
      ok: false,
      code: 'COUPON_MIN_ORDER',
      message: `This coupon needs a minimum order of ₹${(coupon.minSubtotal / 100).toFixed(0)}.`,
    };
  }
  if (customerEmail) {
    const uses = store.couponRedemptions.filter(
      (r) => r.couponCode === coupon.code && r.email.toLowerCase() === customerEmail.toLowerCase(),
    ).length;
    if (uses >= coupon.perCustomerLimit) {
      return { ok: false, code: 'COUPON_PER_CUSTOMER', message: 'You have already used this coupon.' };
    }
  }
  const discount =
    coupon.kind === 'flat' ? Math.min(coupon.value, subtotal) : percentOf(subtotal, coupon.value, coupon.maxDiscount);
  return { ok: true, discount, coupon };
}

export function recordRedemption(code: string, orderId: string, email: string) {
  const coupon = store.coupons.find((c) => c.code === code);
  if (coupon) coupon.redeemed += 1;
  store.couponRedemptions.push({ couponCode: code, orderId, email });
}
