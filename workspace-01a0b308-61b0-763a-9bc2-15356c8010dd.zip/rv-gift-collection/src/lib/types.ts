/**
 * Shared domain types for RV Gift Collection.
 * Money is ALWAYS integer paise (1/100 INR) on the server.
 */

export type ProductStatus = 'draft' | 'published' | 'archived';

export interface CategoryInfo {
  slug: string;
  name: string;
  blurb: string;
  image: string;
}

export interface OccasionInfo {
  slug: string;
  name: string;
  blurb: string;
  image: string;
}

export interface RecipientInfo {
  slug: string;
  name: string;
  blurb: string;
  image: string;
}

export interface PersonalisationField {
  key: string;
  label: string;
  type: 'text' | 'message';
  required: boolean;
  maxLength: number;
  placeholder?: string;
}

export type PreviewLayout =
  | 'mug'
  | 'frame'
  | 'cushion'
  | 'keychain'
  | 'lamp'
  | 'notebook'
  | 'hamper';

export interface PrintArea {
  /** Normalised (0..1) coordinates inside the 600x600 preview canvas */
  x: number;
  y: number;
  w: number;
  h: number;
  shape: 'rect' | 'circle';
}

export interface PersonalisationTemplate {
  id: string;
  version: number;
  layout: PreviewLayout;
  fields: PersonalisationField[];
  photos: {
    count: number; // 0 = no photos
    minPx: number;
    maxPx: number;
  };
  printArea: PrintArea;
  textColors: string[];
}

export interface ProductVariant {
  id: string;
  sku: string;
  /** Human-readable variant label, e.g. "Ivory / 12 inch" */
  name: string;
  attributes: Record<string, string>;
  /** Integer paise, GST inclusive */
  price: number;
  /** GST rate, e.g. 18 */
  taxRate: number;
  available: boolean;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  category: string; // category slug
  shortDescription: string;
  description: string;
  material: string;
  dimensions: string;
  care: string;
  /** Production lead time in business days before dispatch */
  leadTimeDays: number;
  images: string[];
  occasions: string[];
  recipients: string[];
  collections: string[];
  featured: boolean;
  status: ProductStatus;
  personalisation?: PersonalisationTemplate;
  variants: ProductVariant[];
}

export interface CropConfig {
  scale: number;
  x: number;
  y: number;
}

export interface ApprovedPersonalisation {
  templateId: string;
  templateVersion: number;
  fields: Record<string, string>;
  /** Server-side private asset ids */
  assetIds: string[];
  /** Client-side thumbnails (data URLs) of the approved photos */
  photoThumbs: string[];
  /** Small raster of the exact approved preview, for cart/order display */
  previewThumb?: string;
  textColor: string;
  crop: CropConfig;
  approvedAt: string;
}

export interface CartLine {
  id: string;
  productId: string;
  slug: string;
  variantId: string;
  qty: number;
  addedAt: string;
  personalisation?: ApprovedPersonalisation;
}

export interface Address {
  id?: string;
  fullName: string;
  phone: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
  isDefault?: boolean;
}

export type DeliveryOptionId = 'standard' | 'express';

export interface QuoteLineOut {
  lineId: string;
  productId: string;
  slug: string;
  variantId: string;
  name: string;
  variantName: string;
  image: string;
  qty: number;
  unitPrice: number;
  lineTotal: number;
  hasPersonalisation: boolean;
  personalisationSummary?: Record<string, string>;
}

export interface Quote {
  id: string;
  createdAt: string;
  expiresAt: string;
  lines: QuoteLineOut[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  taxIncluded: number;
  deliveryFee: number;
  deliveryOption: DeliveryOptionId;
  deliveryWindow?: string;
  total: number;
  currency: 'INR';
}

export type OrderStatus =
  | 'PAYMENT_PENDING'
  | 'CONFIRMED'
  | 'PERSONALISATION_REVIEW'
  | 'IN_PRODUCTION'
  | 'QUALITY_CHECKED'
  | 'PACKED'
  | 'SHIPPED'
  | 'DELIVERED'
  | 'CORRECTION_HOLD'
  | 'CANCELLED'
  | 'DELIVERY_EXCEPTION';

export interface OrderItemSnapshot {
  productId: string;
  slug: string;
  name: string;
  sku: string;
  variantName: string;
  options: Record<string, string>;
  qty: number;
  unitPrice: number;
  taxRate: number;
  taxIncluded: number;
  lineTotal: number;
  image: string;
  personalisation?: ApprovedPersonalisation;
}

export interface OrderStatusEvent {
  status: OrderStatus;
  at: string;
  note?: string;
  by?: string;
}

export interface Order {
  id: string;
  /** Non-sequential public reference, e.g. RV-7K3M-9QX2 */
  reference: string;
  /** Secret token required for guest tracking links */
  trackingToken: string;
  createdAt: string;
  status: OrderStatus;
  history: OrderStatusEvent[];
  buyer: { userId?: string; name: string; email: string; phone: string };
  recipient: { name: string; phone?: string; giftMessage?: string };
  address: Address;
  items: OrderItemSnapshot[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  taxIncluded: number;
  deliveryFee: number;
  deliveryOption: DeliveryOptionId;
  deliveryWindow?: string;
  total: number;
  paymentId?: string;
  shipment?: { courier?: string; awb?: string; shippedAt?: string };
  isGuest: boolean;
}

export type PaymentStatus = 'CREATED' | 'CAPTURED' | 'FAILED' | 'ABANDONED';

export interface Payment {
  id: string;
  orderId: string;
  provider: 'razorpay-demo' | 'razorpay';
  providerOrderId: string;
  amount: number;
  currency: 'INR';
  status: PaymentStatus;
  createdAt: string;
  providerPaymentId?: string;
  capturedAt?: string;
}

export interface SupportTicket {
  id: string;
  reference: string;
  createdAt: string;
  type: string;
  orderReference?: string;
  name: string;
  email: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved';
}

export interface Coupon {
  code: string;
  description: string;
  kind: 'flat' | 'percent';
  /** flat = paise, percent = 0..100 */
  value: number;
  maxDiscount?: number; // paise cap for percent coupons
  minSubtotal: number; // paise
  startsAt: string;
  expiresAt: string;
  usageLimit: number;
  perCustomerLimit: number;
  redeemed: number;
  active: boolean;
}

export interface DeliveryZone {
  id: string;
  name: string;
  pinPrefixes: string[];
  transitDays: [number, number];
  fee: number;
  expressFee?: number;
  expressTransitDays?: [number, number];
}

export interface DeliveryRules {
  zones: DeliveryZone[];
  unsupportedPins: string[];
  cutoffHour: number; // IST hour after which production starts next business day
  businessDays: number[]; // 1=Mon ... 6=Sat
  capacityPerDay: number;
  freeStandardAbove: number; // paise
}

export interface StockRecord {
  sku: string;
  onHand: number;
  reserved: number;
}

export interface StockAdjustment {
  id: string;
  sku: string;
  delta: number;
  reason: string;
  at: string;
  by: string;
}

export interface AuditEntry {
  id: string;
  at: string;
  actor: string;
  action: string;
  detail: string;
}

export interface Job {
  id: string;
  type: string;
  payload: Record<string, unknown>;
  state: 'queued' | 'leased' | 'done' | 'failed';
  attempts: number;
  maxAttempts: number;
  nextRunAt: string;
  leaseUntil?: string;
  lastError?: string;
  idempotencyKey?: string;
  createdAt: string;
}

export interface Profile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  passwordHash: string; // demo mode only — Supabase Auth in production
  createdAt: string;
  addresses: Address[];
}

export interface EmailRecord {
  id: string;
  to: string;
  template: string;
  subject: string;
  at: string;
}

export interface UploadRecord {
  id: string;
  status: 'authorised' | 'stored' | 'processed' | 'rejected' | 'expired';
  contentType: string;
  size: number;
  width: number;
  height: number;
  productId?: string;
  buffer?: Buffer;
  createdAt: string;
  completedAt?: string;
}

export interface DeliveryCheckResult {
  serviceable: boolean;
  reason?: string;
  zone?: string;
  windowStart?: string;
  windowEnd?: string;
  standardFee: number;
  standardFree: boolean;
  expressAvailable: boolean;
  expressFee?: number;
  expressWindowStart?: string;
  expressWindowEnd?: string;
  productionDays: number;
}
