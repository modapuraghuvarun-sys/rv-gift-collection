/**
 * Order status labels + main timeline. Kept dependency-free (no Node imports)
 * so client components can safely import them.
 */

import type { OrderStatus } from '@/lib/types';

export const STATUS_LABELS: Record<OrderStatus, string> = {
  PAYMENT_PENDING: 'Payment pending',
  CONFIRMED: 'Confirmed',
  PERSONALISATION_REVIEW: 'Personalization Review',
  IN_PRODUCTION: 'In Production',
  QUALITY_CHECKED: 'Quality Checked',
  PACKED: 'Packed',
  SHIPPED: 'Shipped',
  DELIVERED: 'Delivered',
  CORRECTION_HOLD: 'Correction Hold',
  CANCELLED: 'Cancelled',
  DELIVERY_EXCEPTION: 'Delivery Exception',
};

export const MAIN_TIMELINE: OrderStatus[] = [
  'CONFIRMED',
  'PERSONALISATION_REVIEW',
  'IN_PRODUCTION',
  'QUALITY_CHECKED',
  'PACKED',
  'SHIPPED',
  'DELIVERED',
];
