/**
 * Delivery availability engine.
 *
 * Computes serviceability + estimated delivery window from:
 * PIN code → zone, production lead time (business days), cut-off time,
 * transit days and daily fulfilment capacity.
 *
 * NEVER promises "arrives tomorrow" — only shows a computed window.
 */

import { defaultZone } from '@/lib/data/catalog';
import { store } from '@/lib/store';
import type { DeliveryCheckResult, DeliveryZone, Product } from '@/lib/types';
import { isValidIndianPincode } from '@/lib/utils';

function istNow(): Date {
  // Work in IST wall-clock time.
  return new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
}

function isBusinessDay(d: Date): boolean {
  const day = d.getDay(); // 0 Sun .. 6 Sat
  return store.deliveryRules.businessDays.includes(day === 0 ? 7 : day);
}

/** Add n business days, skipping non-business days. */
function addBusinessDays(from: Date, days: number): Date {
  const d = new Date(from);
  let added = 0;
  while (added < days) {
    d.setDate(d.getDate() + 1);
    if (isBusinessDay(d)) added += 1;
  }
  return d;
}

/** Add calendar days for transit (couriers run all days). */
function addCalendarDays(from: Date, days: number): Date {
  const d = new Date(from);
  d.setDate(d.getDate() + days);
  return d;
}

function zoneFor(pin: string): DeliveryZone | (typeof defaultZone & { expressFee?: number; expressTransitDays?: [number, number] }) {
  const { zones } = store.deliveryRules;
  let best: DeliveryZone | null = null;
  let bestLen = 0;
  for (const z of zones) {
    for (const prefix of z.pinPrefixes) {
      if (pin.startsWith(prefix) && prefix.length > bestLen) {
        best = z;
        bestLen = prefix.length;
      }
    }
  }
  return best ?? defaultZone;
}

function dateKey(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/** First ship date with remaining capacity, starting from a given date. */
function nextShipDate(from: Date): Date {
  const d = new Date(from);
  let guard = 0;
  while (guard < 30) {
    const key = dateKey(d);
    const booked = store.capacityBookings.get(key) ?? 0;
    if (booked < store.deliveryRules.capacityPerDay) return d;
    d.setDate(d.getDate() + 1);
    guard += 1;
  }
  return d;
}

export function checkDelivery(pin: string, product: Product, qty: number): DeliveryCheckResult {
  const notServiceable = (reason: string): DeliveryCheckResult => ({
    serviceable: false,
    reason,
    standardFee: 0,
    standardFree: false,
    expressAvailable: false,
    productionDays: product.leadTimeDays,
  });

  if (!isValidIndianPincode(pin)) {
    return notServiceable('Please enter a valid 6-digit PIN code.');
  }
  if (store.deliveryRules.unsupportedPins.some((p) => pin.startsWith(p))) {
    return notServiceable(
      'We are unable to deliver to this PIN code right now. Please check back soon or choose a different delivery address.',
    );
  }

  const zone = zoneFor(pin);
  const now = istNow();

  // Cut-off: production starts next business day if past cut-off.
  let productionStart = new Date(now);
  if (now.getHours() >= store.deliveryRules.cutoffHour || !isBusinessDay(now)) {
    productionStart = addBusinessDays(now, 1);
    if (!isBusinessDay(productionStart)) productionStart = addBusinessDays(productionStart, 1);
  }
  const productionEnd = addBusinessDays(productionStart, Math.max(1, product.leadTimeDays));

  const shipDate = nextShipDate(productionEnd);
  const [tMin, tMax] = zone.transitDays;
  const windowStart = addCalendarDays(shipDate, tMin);
  const windowEnd = addCalendarDays(shipDate, tMax);

  const expressAvailable = Boolean(zone.expressFee && zone.expressTransitDays);
  let expressWindowStart: Date | undefined;
  let expressWindowEnd: Date | undefined;
  if (expressAvailable && zone.expressTransitDays) {
    expressWindowStart = addCalendarDays(shipDate, zone.expressTransitDays[0]);
    expressWindowEnd = addCalendarDays(shipDate, zone.expressTransitDays[1]);
  }

  return {
    serviceable: true,
    zone: zone.name,
    windowStart: windowStart.toISOString(),
    windowEnd: windowEnd.toISOString(),
    standardFee: zone.fee,
    standardFree: false, // final fee is computed server-side at quote time (free above threshold)
    expressAvailable,
    expressFee: zone.expressFee,
    expressWindowStart: expressWindowStart?.toISOString(),
    expressWindowEnd: expressWindowEnd?.toISOString(),
    productionDays: product.leadTimeDays,
  };
}

/** Book capacity for a confirmed order's ship date. */
export function bookCapacity(isoDate: string) {
  const key = isoDate.slice(0, 10);
  store.capacityBookings.set(key, (store.capacityBookings.get(key) ?? 0) + 1);
}
