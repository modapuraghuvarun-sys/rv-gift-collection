/** Refund records (demo). Production: `refunds` table + provider refund API. */

import { uid } from '@/lib/utils';

export interface RefundRecord {
  id: string;
  orderId: string;
  amount: number;
  reason: string;
  at: string;
  by: string;
  status: 'initiated' | 'processed';
}

declare global {
  // eslint-disable-next-line no-var
  var __rvRefunds: RefundRecord[] | undefined;
}

export const refunds: RefundRecord[] = (globalThis.__rvRefunds ??= []);

export function createRefund(orderId: string, amount: number, reason: string, by: string): RefundRecord {
  const refund: RefundRecord = {
    id: uid('ref'),
    orderId,
    amount,
    reason,
    at: new Date().toISOString(),
    by,
    status: 'initiated',
  };
  refunds.unshift(refund);
  return refund;
}
