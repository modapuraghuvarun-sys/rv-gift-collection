import { clsx, type ClassValue } from 'clsx';

export function cn(...inputs: ClassValue[]): string {
  return clsx(inputs);
}

export function uid(prefix = ''): string {
  const raw =
    typeof crypto !== 'undefined' && 'randomUUID' in crypto
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  return prefix ? `${prefix}_${raw.replace(/-/g, '').slice(0, 20)}` : raw.replace(/-/g, '').slice(0, 24);
}

export function randomToken(bytes = 16): string {
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const arr = new Uint8Array(bytes);
    crypto.getRandomValues(arr);
    return Array.from(arr, (b) => b.toString(16).padStart(2, '0')).join('');
  }
  return Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
}

const REF_ALPHABET = '23456789ABCDEFGHJKMNPQRSTUVWXYZ'; // no 0/1/I/L/O

/** Non-sequential public order reference like RV-7K3M-9QX2 */
export function generateOrderReference(): string {
  const pick = (n: number) =>
    Array.from({ length: n }, () =>
      REF_ALPHABET.charAt(Math.floor(Math.random() * REF_ALPHABET.length)),
    ).join('');
  return `RV-${pick(4)}-${pick(4)}`;
}

export function generateCaseReference(): string {
  const pick = (n: number) =>
    Array.from({ length: n }, () =>
      REF_ALPHABET.charAt(Math.floor(Math.random() * REF_ALPHABET.length)),
    ).join('');
  return `RVC-${pick(6)}`;
}

export function formatDate(iso: string): string {
  return new Intl.DateTimeFormat('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(new Date(iso));
}

export function formatDateTime(iso: string): string {
  return new Intl.DateTimeFormat('en-IN', {
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
    timeZone: 'Asia/Kolkata',
  }).format(new Date(iso));
}

export function formatDateRange(a?: string, b?: string): string {
  if (!a || !b) return '';
  const f = (iso: string) =>
    new Intl.DateTimeFormat('en-IN', {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      timeZone: 'Asia/Kolkata',
    }).format(new Date(iso));
  return `${f(a)} – ${f(b)}`;
}

export function isValidIndianPincode(pin: string): boolean {
  return /^[1-9][0-9]{5}$/.test(pin);
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
}

export function isValidPhone(phone: string): boolean {
  return /^[6-9][0-9]{9}$/.test(phone.replace(/\D/g, ''));
}

export function isJpegMagic(buf: Uint8Array): boolean {
  return buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
}

export function isPngMagic(buf: Uint8Array): boolean {
  return (
    buf.length > 7 &&
    buf[0] === 0x89 &&
    buf[1] === 0x50 &&
    buf[2] === 0x4e &&
    buf[3] === 0x47
  );
}
