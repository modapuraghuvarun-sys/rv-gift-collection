import { store } from '@/lib/store';
import { uid } from '@/lib/utils';

export interface ReserveResult {
  ok: boolean;
  reservationId?: string;
  code?: 'OUT_OF_STOCK';
  insufficient?: { sku: string; requested: number; available: number };
}

/**
 * Reserve stock for a set of items. Synchronous check-and-hold — atomic in
 * Node's event loop; production equivalent is a single guarded SQL UPDATE so
 * two customers cannot both buy the final unit.
 */
export function reserveStock(items: { sku: string; qty: number }[], ttlMinutes = 12): ReserveResult {
  // 1. Validate all lines first — all-or-nothing.
  for (const item of items) {
    const rec = store.inventory.get(item.sku);
    const available = rec ? rec.onHand - rec.reserved : 0;
    if (!rec || available < item.qty) {
      return {
        ok: false,
        code: 'OUT_OF_STOCK',
        insufficient: { sku: item.sku, requested: item.qty, available: Math.max(0, available) },
      };
    }
  }
  // 2. Apply reservation.
  for (const item of items) {
    const rec = store.inventory.get(item.sku)!;
    rec.reserved += item.qty;
  }
  const reservation = {
    id: uid('res'),
    items,
    status: 'held' as const,
    createdAt: new Date().toISOString(),
    expiresAt: new Date(Date.now() + ttlMinutes * 60000).toISOString(),
  };
  store.reservations.push(reservation);
  return { ok: true, reservationId: reservation.id };
}

/** Release a held reservation back to available pool. */
export function releaseReservation(reservationId: string, reason: 'expired' | 'cancelled' | 'payment_failed') {
  const res = store.reservations.find((r) => r.id === reservationId);
  if (!res || res.status !== 'held') return;
  for (const item of res.items) {
    const rec = store.inventory.get(item.sku);
    if (rec) rec.reserved = Math.max(0, rec.reserved - item.qty);
  }
  res.status = reason === 'expired' ? 'expired' : 'released';
}

/** Convert a held reservation to allocated after verified payment. */
export function allocateReservation(reservationId: string, orderId: string) {
  const res = store.reservations.find((r) => r.id === reservationId);
  if (!res || res.status !== 'held') return;
  res.status = 'allocated';
  res.orderId = orderId;
  for (const item of res.items) {
    const rec = store.inventory.get(item.sku);
    if (rec) {
      rec.reserved = Math.max(0, rec.reserved - item.qty);
      rec.onHand = Math.max(0, rec.onHand - item.qty);
    }
  }
}

/** Called by the reservation-expiry background job. */
export function sweepExpiredReservations(): number {
  const now = Date.now();
  let released = 0;
  for (const res of store.reservations) {
    if (res.status === 'held' && new Date(res.expiresAt).getTime() < now) {
      releaseReservation(res.id, 'expired');
      released += 1;
    }
  }
  return released;
}
