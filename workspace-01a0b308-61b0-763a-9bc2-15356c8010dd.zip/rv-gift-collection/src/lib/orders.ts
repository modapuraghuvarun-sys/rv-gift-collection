/**
 * Order creation — server-side, quote-driven.
 *
 * Flow: quote → re-validate (expiry + price drift) → reserve inventory →
 * create order with full purchase-time snapshots → create payment →
 * hosted checkout → verified webhook → CONFIRMED.
 */

import { reserveStock } from '@/lib/inventory';
import { recordRedemption } from '@/lib/coupons';
import { buildQuote, getQuote, isQuoteExpired } from '@/lib/pricing';
import { createPayment } from '@/lib/payments';
import { audit, store } from '@/lib/store';
import type { Address, CartLine, DeliveryOptionId, Order, OrderItemSnapshot, OrderStatus } from '@/lib/types';
import { taxIncludedIn } from '@/lib/money';
import { generateOrderReference, randomToken, uid } from '@/lib/utils';

export interface CreateOrderInput {
  quoteId: string;
  lines: CartLine[]; // re-sent for server recomputation; browser totals ignored
  couponCode?: string;
  deliveryOption: DeliveryOptionId;
  buyer: { userId?: string; name: string; email: string; phone: string };
  recipient: { name: string; phone?: string; giftMessage?: string };
  address: Address;
  isGuest: boolean;
}

export interface CreateOrderResult {
  ok: boolean;
  code?:
    | 'QUOTE_NOT_FOUND'
    | 'QUOTE_EXPIRED'
    | 'PRICE_CHANGED'
    | 'VALIDATION'
    | 'OUT_OF_STOCK'
    | 'PIN_UNSUPPORTED';
  message?: string;
  order?: Order;
  paymentId?: string;
  newQuoteId?: string;
  newTotal?: number;
}

export { STATUS_LABELS, MAIN_TIMELINE } from '@/lib/order-status';

export function createOrder(input: CreateOrderInput): CreateOrderResult {
  const quote = getQuote(input.quoteId);
  if (!quote) {
    return { ok: false, code: 'QUOTE_NOT_FOUND', message: 'Your session expired. Please review your cart again.' };
  }
  if (isQuoteExpired(quote)) {
    // Recompute a fresh quote so the customer sees the current amount.
    const fresh = buildQuote({
      lines: input.lines,
      couponCode: input.couponCode,
      deliveryOption: input.deliveryOption,
      pincode: input.address.pincode,
      customerEmail: input.buyer.email,
    });
    return {
      ok: false,
      code: 'QUOTE_EXPIRED',
      message: 'Prices were refreshed. Please review the updated total before paying.',
      newQuoteId: fresh.quote?.id,
      newTotal: fresh.quote?.total,
    };
  }

  // Re-validate cart end-to-end (availability, personalisation approvals).
  const recheck = buildQuote({
    lines: input.lines,
    couponCode: input.couponCode,
    deliveryOption: input.deliveryOption,
    pincode: input.address.pincode,
    customerEmail: input.buyer.email,
  });
  if (!recheck.ok || !recheck.quote) {
    const codeMap: Record<string, CreateOrderResult['code']> = {
      OUT_OF_STOCK: 'OUT_OF_STOCK',
      PIN_UNSUPPORTED: 'PIN_UNSUPPORTED',
      PERSONALISATION_NOT_APPROVED: 'VALIDATION',
      PERSONALISATION_REQUIRED: 'VALIDATION',
      COUPON_ERROR: 'VALIDATION',
    };
    return { ok: false, code: codeMap[recheck.code ?? ''] ?? 'VALIDATION', message: recheck.message };
  }

  // Price drift detection — never let stale browser totals through.
  if (recheck.quote.total !== quote.total) {
    return {
      ok: false,
      code: 'PRICE_CHANGED',
      message: 'The total changed while you were checking out. Please review the updated amount.',
      newQuoteId: recheck.quote.id,
      newTotal: recheck.quote.total,
    };
  }

  // Reserve inventory (atomic check-and-hold; prevents double-selling the
  // final unit across concurrent checkouts).
  const stockItems = input.lines.map((l) => {
    const product = store.products.find((p) => p.id === l.productId)!;
    const variant = product.variants.find((v) => v.id === l.variantId)!;
    return { sku: variant.sku, qty: l.qty };
  });
  const reservation = reserveStock(stockItems);
  if (!reservation.ok) {
    return { ok: false, code: 'OUT_OF_STOCK', message: 'One of your items just sold out. Please adjust your cart.' };
  }

  // Build purchase-time snapshots (name, SKU, options, price, tax, address,
  // approved design) so historical orders never depend on live catalogue.
  const items: OrderItemSnapshot[] = input.lines.map((l) => {
    const product = store.products.find((p) => p.id === l.productId)!;
    const variant = product.variants.find((v) => v.id === l.variantId)!;
    return {
      productId: product.id,
      slug: product.slug,
      name: product.name,
      sku: variant.sku,
      variantName: variant.name,
      options: variant.attributes,
      qty: l.qty,
      unitPrice: variant.price,
      taxRate: variant.taxRate,
      taxIncluded: taxIncludedIn(variant.price * l.qty, variant.taxRate),
      lineTotal: variant.price * l.qty,
      image: product.images[0],
      personalisation: l.personalisation
        ? { ...l.personalisation, assetIds: [...l.personalisation.assetIds] }
        : undefined,
    };
  });

  const now = new Date().toISOString();
  const order: Order = {
    id: uid('ord'),
    reference: generateOrderReference(),
    trackingToken: randomToken(16),
    createdAt: now,
    status: 'PAYMENT_PENDING',
    history: [{ status: 'PAYMENT_PENDING', at: now, note: 'Order created, awaiting payment', by: 'system' }],
    buyer: input.buyer,
    recipient: input.recipient,
    address: input.address,
    items,
    subtotal: quote.subtotal,
    discount: quote.discount,
    couponCode: quote.couponCode,
    taxIncluded: quote.taxIncluded,
    deliveryFee: quote.deliveryFee,
    deliveryOption: quote.deliveryOption,
    deliveryWindow: quote.deliveryWindow,
    total: quote.total,
    isGuest: input.isGuest,
  };

  // Bind reservation to the order so the webhook can allocate it.
  const res = store.reservations.find((r) => r.id === reservation.reservationId);
  if (res) res.orderId = order.id;

  store.orders.unshift(order);
  if (input.couponCode && quote.couponCode) {
    recordRedemption(quote.couponCode, order.id, input.buyer.email);
  }

  const payment = createPayment(order);
  audit(input.isGuest ? 'guest' : input.buyer.email, 'order.created', `Order ${order.reference} created (₹${(order.total / 100).toFixed(2)})`);

  return { ok: true, order, paymentId: payment.id };
}

export interface OrderAccess {
  ok: boolean;
  reason?: 'NOT_FOUND' | 'FORBIDDEN';
  order?: Order;
}

/**
 * Secure order lookup. Access requires EITHER the secret tracking token
 * (guest links) OR an authenticated owner/staff session. Order reference +
 * email alone is never sufficient.
 */
export function accessOrder(
  reference: string,
  opts: { token?: string; userId?: string; staff?: boolean },
): OrderAccess {
  const order = store.orders.find((o) => o.reference === reference || o.id === reference);
  if (!order) return { ok: false, reason: 'NOT_FOUND' };
  if (opts.staff) return { ok: true, order };
  if (opts.token && opts.token === order.trackingToken) return { ok: true, order };
  if (opts.userId && order.buyer.userId === opts.userId) return { ok: true, order };
  return { ok: false, reason: 'FORBIDDEN' };
}

export function updateOrderStatus(orderId: string, status: OrderStatus, note: string, actor: string) {
  const order = store.orders.find((o) => o.id === orderId);
  if (!order) return false;
  order.status = status;
  order.history.push({ status, at: new Date().toISOString(), note, by: actor });
  audit(actor, `order.status.${status.toLowerCase()}`, `Order ${order.reference}: ${note}`);

  if (status === 'SHIPPED' || status === 'DELIVERED') {
    enqueueOrderEmail(order, status);
  }
  return true;
}

import { enqueueJob } from '@/lib/jobs';

function enqueueOrderEmail(order: Order, status: OrderStatus) {
  const template = status === 'SHIPPED' ? 'dispatch_notification' : 'delivery_update';
  const subject =
    status === 'SHIPPED'
      ? `Your order ${order.reference} is on its way`
      : `Delivery update for order ${order.reference}`;
  enqueueJob('send_email', { to: order.buyer.email, template, subject }, { idempotencyKey: `email:${template}:${order.id}:${status}` });
}
