/** Money helpers — all amounts are integer paise (1/100 INR). */

export function formatINR(paise: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: paise % 100 === 0 ? 0 : 2,
    minimumFractionDigits: paise % 100 === 0 ? 0 : 2,
  }).format(paise / 100);
}

export function roundPaise(value: number): number {
  return Math.round(value);
}

/** GST included in a GST-inclusive price: price * rate / (100 + rate) */
export function taxIncludedIn(paise: number, taxRate: number): number {
  return roundPaise((paise * taxRate) / (100 + taxRate));
}

/** Percent discount capped at maxDiscount paise. */
export function percentOf(paise: number, percent: number, cap?: number): number {
  const v = roundPaise((paise * percent) / 100);
  return cap !== undefined ? Math.min(v, cap) : v;
}
