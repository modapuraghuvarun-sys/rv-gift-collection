/**
 * Demo-mode server store.
 *
 * In production every collection here maps to a Supabase table (see
 * supabase/migrations) with Row Level Security. For the preview build we keep
 * the same shapes in-process so every flow — pricing, reservations, webhooks,
 * idempotency, jobs — runs end to end without credentials.
 *
 * Node is single-threaded, so synchronous check-and-reserve sequences here are
 * atomic in the same way a production `UPDATE inventory SET reserved = reserved
 * + $qty WHERE sku = $sku AND on_hand - reserved >= $qty` single statement is.
 */

import { products as seedProducts, seedCoupons, seedDeliveryRules, collectionList } from '@/lib/data/catalog';
import type {
  AuditEntry,
  Coupon,
  DeliveryRules,
  EmailRecord,
  Job,
  Order,
  Payment,
  Product,
  Profile,
  Quote,
  StockAdjustment,
  StockRecord,
  SupportTicket,
  UploadRecord,
} from '@/lib/types';
import { uid } from '@/lib/utils';

interface Session {
  id: string;
  userId?: string;
  role: 'customer' | 'staff';
  createdAt: string;
}

interface Reservation {
  id: string;
  items: { sku: string; qty: number }[];
  orderId?: string;
  status: 'held' | 'allocated' | 'released' | 'expired';
  createdAt: string;
  expiresAt: string;
}

interface Store {
  products: Product[];
  collections: { slug: string; name: string; featured: boolean }[];
  inventory: Map<string, StockRecord>;
  reservations: Reservation[];
  stockAdjustments: StockAdjustment[];
  quotes: Map<string, Quote>;
  orders: Order[];
  payments: Payment[];
  /** Provider webhook event ids already processed (idempotency). */
  processedProviderEvents: Set<string>;
  coupons: Coupon[];
  couponRedemptions: { couponCode: string; orderId: string; email: string }[];
  deliveryRules: DeliveryRules;
  /** bookings per ISO date for capacity checks */
  capacityBookings: Map<string, number>;
  uploads: Map<string, UploadRecord>;
  tickets: SupportTicket[];
  audit: AuditEntry[];
  jobs: Job[];
  emails: EmailRecord[];
  profiles: Profile[];
  sessions: Map<string, Session>;
  templateVersions: Map<string, number>; // templateId -> current version
  started: boolean;
}

function createInventory(products: Product[]): Map<string, StockRecord> {
  const map = new Map<string, StockRecord>();
  for (const p of products) {
    for (const v of p.variants) {
      // Deterministic-ish demo stock: most healthy, a couple of scarcity cases.
      let onHand = 18 + ((p.name.length + v.sku.length) % 14);
      if (v.id === 'v-cush-16') onHand = 2; // scarcity demo
      if (!v.available) onHand = 0;
      map.set(v.sku, { sku: v.sku, onHand, reserved: 0 });
    }
  }
  return map;
}

function createStore(): Store {
  const products = JSON.parse(JSON.stringify(seedProducts)) as Product[];
  const templateVersions = new Map<string, number>();
  for (const p of products) {
    if (p.personalisation) templateVersions.set(p.personalisation.id, p.personalisation.version);
  }
  return {
    products,
    collections: [...collectionList],
    inventory: createInventory(products),
    reservations: [],
    stockAdjustments: [],
    quotes: new Map(),
    orders: [],
    payments: [],
    processedProviderEvents: new Set(),
    coupons: JSON.parse(JSON.stringify(seedCoupons)),
    couponRedemptions: [],
    deliveryRules: JSON.parse(JSON.stringify(seedDeliveryRules)),
    capacityBookings: new Map(),
    uploads: new Map(),
    tickets: [],
    audit: [],
    jobs: [],
    emails: [],
    profiles: [],
    sessions: new Map(),
    templateVersions,
    started: false,
  };
}

declare global {
  // eslint-disable-next-line no-var
  var __rvStore: Store | undefined;
}

export const store: Store = globalThis.__rvStore ?? (globalThis.__rvStore = createStore());

export function audit(actor: string, action: string, detail: string) {
  store.audit.unshift({ id: uid('aud'), at: new Date().toISOString(), actor, action, detail });
  if (store.audit.length > 500) store.audit.length = 500;
}

export function recordEmail(to: string, template: string, subject: string) {
  store.emails.unshift({ id: uid('eml'), to, template, subject, at: new Date().toISOString() });
}

export function getSession(id: string | undefined): Session | undefined {
  if (!id) return undefined;
  return store.sessions.get(id);
}

export function createSession(role: 'customer' | 'staff', userId?: string): Session {
  const s: Session = { id: uid('sess'), userId, role, createdAt: new Date().toISOString() };
  store.sessions.set(s.id, s);
  return s;
}

/** Ensure the demo background job loop is scheduled (dev-safe, once). */
export function ensureJobLoop() {
  if (store.started || typeof setInterval === 'undefined') return;
  store.started = true;
  setInterval(() => {
    try {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { runDueJobs } = require('@/lib/jobs') as typeof import('@/lib/jobs');
      runDueJobs();
    } catch {
      /* noop */
    }
  }, 20000);
}
