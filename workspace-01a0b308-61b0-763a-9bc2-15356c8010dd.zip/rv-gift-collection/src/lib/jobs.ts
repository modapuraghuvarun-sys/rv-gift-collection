/**
 * Background job queue (demo implementation).
 *
 * Mirrors the production worker architecture described in the Supabase spec:
 *  - job lease/lock with leaseUntil
 *  - attempt counts with exponential backoff
 *  - idempotency keys so retries never double-apply
 *  - failed jobs land in a review queue (Admin → Staff & Audit)
 *
 * Production: jobs are rows in `outbox_events` / `job_attempts`, leased by a
 * worker (`FOR UPDATE SKIP LOCKED`). Emails, image validation, reservation
 * expiry, reconciliation and courier sync all run here.
 */

import { store, recordEmail } from '@/lib/store';
import { sweepExpiredReservations } from '@/lib/inventory';
import { uid } from '@/lib/utils';

export function enqueueJob(
  type: string,
  payload: Record<string, unknown>,
  opts?: { idempotencyKey?: string; delayMs?: number },
) {
  if (opts?.idempotencyKey) {
    const existing = store.jobs.find((j) => j.idempotencyKey === opts.idempotencyKey);
    if (existing) return existing; // idempotent enqueue
  }
  const job = {
    id: uid('job'),
    type,
    payload,
    state: 'queued' as const,
    attempts: 0,
    maxAttempts: 4,
    nextRunAt: new Date(Date.now() + (opts?.delayMs ?? 0)).toISOString(),
    idempotencyKey: opts?.idempotencyKey,
    createdAt: new Date().toISOString(),
  };
  store.jobs.push(job);
  return job;
}

type Handler = (payload: Record<string, unknown>) => void;

const handlers: Record<string, Handler> = {
  reservation_expiry: () => {
    sweepExpiredReservations();
  },
  send_email: (p) => {
    recordEmail(String(p.to), String(p.template), String(p.subject));
  },
  image_validation: (p) => {
    const upload = store.uploads.get(String(p.uploadId));
    if (upload && upload.status === 'stored') upload.status = 'processed';
  },
  payment_reconciliation: () => {
    // Payments older than 20 minutes that were never captured are abandoned.
    const cutoff = Date.now() - 20 * 60000;
    for (const pay of store.payments) {
      if (pay.status === 'CREATED' && new Date(pay.createdAt).getTime() < cutoff) {
        pay.status = 'ABANDONED';
      }
    }
  },
  refund_reconciliation: () => {
    /* demo: nothing to reconcile */
  },
  upload_retention_cleanup: () => {
    const cutoff = Date.now() - 24 * 3600000;
    for (const [id, up] of store.uploads) {
      if (up.status === 'authorised' && new Date(up.createdAt).getTime() < cutoff) {
        up.status = 'expired';
        store.uploads.delete(id);
      }
    }
  },
  courier_tracking_sync: () => {
    /* demo: courier API integration placeholder */
  },
};

/** Process all due jobs with lease + backoff semantics. */
export function runDueJobs(): number {
  const now = Date.now();
  let processed = 0;

  // Reservation expiry runs on every tick regardless of queue.
  sweepExpiredReservations();

  for (const job of store.jobs) {
    if (job.state !== 'queued' && job.state !== 'leased') continue;
    if (new Date(job.nextRunAt).getTime() > now) continue;
    if (job.state === 'leased' && job.leaseUntil && new Date(job.leaseUntil).getTime() > now) continue;

    // Acquire lease.
    job.state = 'leased';
    job.leaseUntil = new Date(now + 30000).toISOString();
    job.attempts += 1;

    try {
      const handler = handlers[job.type];
      if (!handler) throw new Error(`No handler for job type ${job.type}`);
      handler(job.payload);
      job.state = 'done';
      processed += 1;
    } catch (err) {
      job.lastError = err instanceof Error ? err.message : String(err);
      if (job.attempts >= job.maxAttempts) {
        job.state = 'failed';
      } else {
        job.state = 'queued';
        const backoff = Math.pow(2, job.attempts) * 2000;
        job.nextRunAt = new Date(now + backoff).toISOString();
      }
    } finally {
      job.leaseUntil = undefined;
    }
  }
  return processed;
}

export function retryFailedJob(id: string): boolean {
  const job = store.jobs.find((j) => j.id === id);
  if (!job || job.state !== 'failed') return false;
  job.state = 'queued';
  job.attempts = 0;
  job.nextRunAt = new Date().toISOString();
  job.lastError = undefined;
  return true;
}
