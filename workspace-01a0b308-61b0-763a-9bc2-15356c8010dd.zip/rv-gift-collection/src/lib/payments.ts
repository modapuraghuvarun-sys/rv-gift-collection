/**
 * Payment orchestration + webhook verification.
 *
 * Demo mode simulates a hosted-checkout provider (Razorpay-style) so the full
 * flow runs without credentials. The webhook handler is written exactly the
 * way the production one is: verify signature, verify provider order id,
 * amount, currency and captured state, and enforce idempotency on the unique
 * provider event id so duplicate webhooks never double-confirm.
 *
 * Browser redirects are NEVER treated as proof of payment — only a verified
 * webhook transitions an order to CONFIRMED.
 */

import { allocateReservation } from '@/lib/inventory';
import { enqueueJob } from '@/lib/jobs';
import { bookCapacity } from '@/lib/delivery';
import { audit, store } from '@/lib/store';
import type { Order, Payment } from '@/lib/types';
import { uid } from '@/lib/utils';
import { createHmac, timingSafeEqual } from 'crypto';

const WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET || 'demo-webhook-secret';

export function createPayment(order: Order): Payment {
  const payment: Payment = {
    id: uid('pay'),
    orderId: order.id,
    provider: 'razorpay-demo',
    providerOrderId: uid('rzporder'),
    amount: order.total,
    currency: 'INR',
    status: 'CREATED',
    createdAt: new Date().toISOString(),
  };
  store.payments.push(payment);
  order.paymentId = payment.id;
  return payment;
}

export function getPayment(id: string): Payment | undefined {
  return store.payments.find((p) => p.id === id);
}

export interface WebhookPayload {
  event_id: string;
  provider_order_id: string;
  payment_id: string;
  amount: number; // paise
  currency: string;
  status: 'captured' | 'failed';
}

export function signPayload(payload: WebhookPayload): string {
  return createHmac('sha256', WEBHOOK_SECRET).update(JSON.stringify(payload)).digest('hex');
}

export function verifySignature(rawBody: string, signature: string): boolean {
  const expected = createHmac('sha256', WEBHOOK_SECRET).update(rawBody).digest('hex');
  try {
    return timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  } catch {
    return false;
  }
}

export interface WebhookResult {
  ok: boolean;
  duplicate?: boolean;
  code?: 'BAD_SIGNATURE' | 'UNKNOWN_ORDER' | 'AMOUNT_MISMATCH' | 'CURRENCY_MISMATCH' | 'PAYMENT_NOT_FOUND';
  message?: string;
}

/**
 * Idempotent webhook processor. Safe against duplicate provider events —
 * the provider `event_id` is recorded exactly once.
 */
export function processWebhook(payload: WebhookPayload): WebhookResult {
  if (store.processedProviderEvents.has(payload.event_id)) {
    return { ok: true, duplicate: true };
  }

  const payment = store.payments.find((p) => p.providerOrderId === payload.provider_order_id);
  if (!payment) return { ok: false, code: 'PAYMENT_NOT_FOUND', message: 'Unknown provider order.' };

  const order = store.orders.find((o) => o.id === payment.orderId);
  if (!order) return { ok: false, code: 'UNKNOWN_ORDER', message: 'Order not found.' };

  if (payload.currency !== 'INR') {
    return { ok: false, code: 'CURRENCY_MISMATCH', message: 'Currency mismatch.' };
  }
  if (payload.amount !== payment.amount) {
    return { ok: false, code: 'AMOUNT_MISMATCH', message: 'Amount mismatch.' };
  }

  // Record the event BEFORE applying side effects (idempotency).
  store.processedProviderEvents.add(payload.event_id);

  if (payload.status === 'failed') {
    payment.status = 'FAILED';
    payment.providerPaymentId = payload.payment_id;
    audit('webhook', 'payment.failed', `Order ${order.reference} payment failed`);
    return { ok: true };
  }

  // captured → confirm.
  payment.status = 'CAPTURED';
  payment.providerPaymentId = payload.payment_id;
  payment.capturedAt = new Date().toISOString();

  confirmOrder(order, payment);
  return { ok: true };
}

/** Post-payment confirmation side effects (single source of truth). */
export function confirmOrder(order: Order, payment: Payment) {
  if (order.status !== 'PAYMENT_PENDING') return; // already confirmed (dup)

  order.status = 'CONFIRMED';
  order.history.push({ status: 'CONFIRMED', at: new Date().toISOString(), note: 'Payment verified', by: 'system' });
  order.history.push({
    status: 'PERSONALISATION_REVIEW',
    at: new Date().toISOString(),
    note: 'Artwork queued for review',
    by: 'system',
  });

  // Convert reservation → allocated stock.
  const reservation = store.reservations.find((r) => r.orderId === undefined && r.status === 'held');
  // In production the reservation id is stored on the order; demo finds by items.
  const resForOrder = store.reservations.find((r) => r.status === 'held' && r.items.length > 0 && !r.orderId && matchesOrder(r.items, order));
  const target = resForOrder ?? reservation;
  if (target) allocateReservation(target.id, order.id);

  bookCapacity(order.createdAt);

  if (order.couponCode) {
    // redemption already counted at order creation; no-op guard here
  }

  enqueueJob('send_email', {
    to: order.buyer.email,
    template: 'order_confirmation',
    subject: `Order ${order.reference} confirmed — RV Gift Collection`,
  }, { idempotencyKey: `email:confirmed:${order.id}` });
  enqueueJob('send_email', {
    to: order.buyer.email,
    template: 'payment_confirmation',
    subject: `Payment received for ${order.reference}`,
  }, { idempotencyKey: `email:payment:${payment.id}` });

  audit('webhook', 'order.confirmed', `Order ${order.reference} confirmed via verified webhook (payment ${payment.id})`);
}

function matchesOrder(items: { sku: string; qty: number }[], order: Order): boolean {
  const orderSkus = new Map(order.items.map((i) => [i.sku, i.qty]));
  if (items.length !== orderSkus.size) return false;
  return items.every((i) => orderSkus.get(i.sku) === i.qty);
}
