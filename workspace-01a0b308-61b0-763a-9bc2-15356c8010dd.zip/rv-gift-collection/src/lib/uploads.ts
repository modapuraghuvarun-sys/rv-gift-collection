/**
 * Photo upload pipeline (server side).
 *
 * Security model:
 *  - Only JPEG/PNG accepted. SVGs and arbitrary documents are rejected.
 *  - Magic-byte (file signature) validation — MIME headers alone are untrusted.
 *  - Dimensions validated against the template's print requirements.
 *  - Files land in a PRIVATE bucket (customer-uploads) and are only ever
 *    served via short-lived signed URLs to authorised staff. Object paths use
 *    opaque ids — never customer names, addresses or emails.
 *  - The client re-encodes through canvas which strips EXIF/metadata; the
 *    server treats this as the last line of defence, not the first.
 */

import { enqueueJob } from '@/lib/jobs';
import { store } from '@/lib/store';
import { isJpegMagic, isPngMagic, uid } from '@/lib/utils';
import { createHmac } from 'crypto';

export const MAX_UPLOAD_BYTES = 10 * 1024 * 1024; // 10 MB
export const ALLOWED_TYPES = ['image/jpeg', 'image/png'] as const;

const SIGN_SECRET = process.env.APP_SECRET || 'demo-app-secret';

export interface AuthoriseInput {
  contentType: string;
  size: number;
  width: number;
  height: number;
  productId?: string;
  photoIndex?: number;
}

export interface AuthoriseResult {
  ok: boolean;
  code?: 'UPLOAD_REJECTED';
  message?: string;
  uploadId?: string;
}

export function authoriseUpload(input: AuthoriseInput): AuthoriseResult {
  if (!ALLOWED_TYPES.includes(input.contentType as (typeof ALLOWED_TYPES)[number])) {
    return { ok: false, code: 'UPLOAD_REJECTED', message: 'Only JPEG and PNG photos are accepted.' };
  }
  if (input.size <= 0 || input.size > MAX_UPLOAD_BYTES) {
    return { ok: false, code: 'UPLOAD_REJECTED', message: 'Photos must be under 10 MB.' };
  }
  if (!Number.isFinite(input.width) || !Number.isFinite(input.height) || input.width < 100 || input.height < 100) {
    return { ok: false, code: 'UPLOAD_REJECTED', message: 'This image could not be read. Please choose a clearer photo.' };
  }

  // Template-driven pixel minimum for the specific product.
  if (input.productId) {
    const product = store.products.find((p) => p.id === input.productId);
    const minPx = product?.personalisation?.photos.minPx ?? 0;
    if (minPx && Math.min(input.width, input.height) < minPx) {
      return {
        ok: false,
        code: 'UPLOAD_REJECTED',
        message: `This photo is too small for a sharp print — please use one at least ${minPx}px on the shorter side.`,
      };
    }
    const maxCount = product?.personalisation?.photos.count ?? 1;
    if (input.photoIndex !== undefined && input.photoIndex >= maxCount) {
      return { ok: false, code: 'UPLOAD_REJECTED', message: `This product supports up to ${maxCount} photo(s).` };
    }
  }

  const id = uid('upl');
  store.uploads.set(id, {
    id,
    status: 'authorised',
    contentType: input.contentType,
    size: input.size,
    width: input.width,
    height: input.height,
    productId: input.productId,
    createdAt: new Date().toISOString(),
  });

  // In production: return a signed/authorised upload URL for the private
  // bucket here (Supabase Storage, short TTL, path = opaque id).
  return { ok: true, uploadId: id };
}

export interface CompleteResult {
  ok: boolean;
  code?: 'UPLOAD_REJECTED' | 'UPLOAD_NOT_FOUND' | 'SIZE_MISMATCH';
  message?: string;
  assetId?: string;
}

export function completeUpload(uploadId: string, buffer: Buffer): CompleteResult {
  const record = store.uploads.get(uploadId);
  if (!record || record.status !== 'authorised') {
    return { ok: false, code: 'UPLOAD_NOT_FOUND', message: 'This upload session expired. Please upload again.' };
  }
  // Re-validate on the server: signature + size. Browser claims are untrusted.
  if (!isJpegMagic(buffer) && !isPngMagic(buffer)) {
    record.status = 'rejected';
    return { ok: false, code: 'UPLOAD_REJECTED', message: 'The file is not a valid JPEG or PNG image.' };
  }
  if (buffer.length > MAX_UPLOAD_BYTES || Math.abs(buffer.length - record.size) > record.size * 0.2) {
    return { ok: false, code: 'SIZE_MISMATCH', message: 'The uploaded file does not match its declared size.' };
  }

  record.buffer = buffer;
  record.status = 'stored';
  record.completedAt = new Date().toISOString();
  enqueueJob('image_validation', { uploadId }, { idempotencyKey: `imgval:${uploadId}` });
  return { ok: true, assetId: uploadId };
}

/** Short-lived signed token for staff access to private customer media. */
export function signMediaUrl(uploadId: string, ttlSeconds = 300): string {
  const exp = Math.floor(Date.now() / 1000) + ttlSeconds;
  const sig = createHmac('sha256', SIGN_SECRET).update(`${uploadId}:${exp}`).digest('hex').slice(0, 32);
  return `${exp}.${sig}`;
}

export function verifyMediaToken(uploadId: string, token: string): boolean {
  const [expStr, sig] = token.split('.');
  const exp = Number(expStr);
  if (!exp || !sig || exp < Math.floor(Date.now() / 1000)) return false;
  const expected = createHmac('sha256', SIGN_SECRET).update(`${uploadId}:${exp}`).digest('hex').slice(0, 32);
  try {
    return Buffer.from(expected).equals(Buffer.from(sig));
  } catch {
    return false;
  }
}
