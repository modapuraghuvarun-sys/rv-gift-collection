'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Camera, Sparkles } from 'lucide-react';
import { formatINR } from '@/lib/money';

export interface ProductCardData {
  id: string;
  slug: string;
  name: string;
  image: string;
  fromPrice: number;
  personalisable: boolean;
  photoPersonalisable: boolean;
  variantOptions: { label: string; values: string[] }[];
  inStock: boolean;
}

export function ProductCard({ product }: { product: ProductCardData }) {
  return (
    <Link
      href={`/product/${product.slug}`}
      className="group card block overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-lift"
    >
      <div className="relative aspect-square overflow-hidden bg-cream-100">
        <Image
          src={product.image}
          alt={product.name}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-cover transition-transform duration-500 group-hover:scale-[1.05]"
        />
        {!product.inStock && (
          <span className="absolute left-3 top-3 rounded-full bg-ink-900/80 px-3 py-1 text-[11px] font-semibold text-cream-50">
            Sold out
          </span>
        )}
        {product.personalisable && (
          <span className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-cream-50/95 px-2.5 py-1 text-[11px] font-semibold text-burgundy-800 shadow-soft">
            {product.photoPersonalisable ? <Camera size={12} aria-hidden /> : <Sparkles size={12} aria-hidden />}
            Personalizable
          </span>
        )}
      </div>
      <div className="p-4">
        <h3 className="line-clamp-1 text-sm font-semibold text-ink-900 group-hover:text-burgundy-800">{product.name}</h3>
        {product.variantOptions.length > 0 && (
          <p className="mt-1 line-clamp-1 text-xs text-ink-400">
            {product.variantOptions.map((o) => `${o.label}: ${o.values.join(' · ')}`).join('  |  ')}
          </p>
        )}
        <div className="mt-2.5 flex items-center justify-between">
          <p className="text-sm font-bold text-burgundy-900">
            <span className="mr-1 text-[11px] font-medium text-ink-400">From</span>
            {formatINR(product.fromPrice)}
          </p>
          <span className="rounded-full border border-burgundy-200 px-3 py-1 text-[11px] font-semibold text-burgundy-800 transition-colors group-hover:bg-burgundy-800 group-hover:text-cream-50">
            View
          </span>
        </div>
      </div>
    </Link>
  );
}

export function ProductCardSkeleton() {
  return (
    <div className="card overflow-hidden" aria-hidden>
      <div className="skeleton aspect-square rounded-none" />
      <div className="space-y-2 p-4">
        <div className="skeleton h-4 w-3/4" />
        <div className="skeleton h-3 w-1/2" />
        <div className="skeleton h-4 w-1/3" />
      </div>
    </div>
  );
}
