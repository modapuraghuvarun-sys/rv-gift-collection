'use client';

/**
 * Simulated hosted payment page (demo mode).
 *
 * In production this screen belongs to Razorpay's hosted checkout — the
 * customer never enters card details on our site. The only thing that
 * confirms an order is a VERIFIED webhook to /api/webhooks/payment; a browser
 * redirect alone never does. This demo page exists solely to exercise that
 * exact server-side path (signed payload → signature check → idempotency).
 */

import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Loader2, Lock, ShieldCheck } from 'lucide-react';
import { formatINR } from '@/lib/money';

export function DemoPayClient() {
  const params = useSearchParams();
  const paymentId = params.get('payment') ?? '';
  const [info, setInfo] = useState<{ amount: number; reference: string } | null>(null);
  const [busy, setBusy] = useState<'success' | 'failed' | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!paymentId) return;
    fetch('/api/payments/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paymentId }),
    })
      .then((r) => r.json())
      .then((json) => setInfo({ amount: json.amount, reference: json.reference }))
      .catch(() => setError('Payment session not found.'));
  }, [paymentId]);

  async function complete(outcome: 'success' | 'failed') {
    setBusy(outcome);
    setError('');
    try {
      const res = await fetch('/api/payments/demo/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentId, outcome }),
      });
      const json = await res.json();
      if (!res.ok && json.error !== 'ALREADY_CAPTURED') {
        setError(json.message ?? 'Payment could not be processed.');
        setBusy(null);
        return;
      }
      const pending = JSON.parse(sessionStorage.getItem('rv_pending_payment') ?? '{}');
      window.location.href = `/payment/status?payment=${paymentId}&token=${pending.token ?? ''}`;
    } catch {
      setError('Something went wrong contacting the payment service.');
      setBusy(null);
    }
  }

  if (!paymentId) {
    return (
      <Center>
        <p className="text-sm text-ink-500">No payment session found.</p>
      </Center>
    );
  }

  return (
    <Center>
      <div className="w-full max-w-md">
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between bg-burgundy-900 px-6 py-4 text-cream-50">
            <div className="flex items-center gap-2">
              <Lock size={16} aria-hidden />
              <span className="text-sm font-semibold">Hosted Checkout</span>
            </div>
            <span className="badge-placeholder">Demo provider</span>
          </div>
          <div className="p-6">
            <p className="text-xs uppercase tracking-wider text-ink-400">RV Gift Collection</p>
            <p className="mt-1 text-3xl font-bold text-burgundy-900">{info ? formatINR(info.amount) : '…'}</p>
            {info && <p className="mt-1 text-xs text-ink-400">Order {info.reference} · INR</p>}

            <div className="mt-6 space-y-3">
              <button className="btn-primary btn-lg w-full" onClick={() => complete('success')} disabled={busy !== null}>
                {busy === 'success' ? <Loader2 className="animate-spin" size={18} aria-hidden /> : <ShieldCheck size={18} aria-hidden />}
                Pay securely
              </button>
              <button className="btn-outline btn-md w-full" onClick={() => complete('failed')} disabled={busy !== null}>
                Simulate failed payment
              </button>
              <Link href="/cart" className="btn-ghost btn-md w-full">
                Abandon payment (go back)
              </Link>
            </div>

            {error && (
              <p className="mt-4 rounded-lg bg-burgundy-50 p-3 text-xs font-medium text-burgundy-700" role="alert">
                {error}
              </p>
            )}

            <p className="mt-6 text-center text-[11px] leading-relaxed text-ink-400">
              In production this page is Razorpay’s hosted checkout. Orders confirm only after the provider webhook is
              signature-verified — redirects alone are never proof of payment.
            </p>
          </div>
        </div>
      </div>
    </Center>
  );
}

function Center({ children }: { children: React.ReactNode }) {
  return <div className="shell flex min-h-[70vh] items-center justify-center py-12">{children}</div>;
}
