'use client';

import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { CheckCircle2, Loader2, XCircle } from 'lucide-react';
import { formatINR } from '@/lib/money';

type Status = 'CREATED' | 'CAPTURED' | 'FAILED' | 'ABANDONED';

export function PaymentStatusClient() {
  const params = useSearchParams();
  const paymentId = params.get('payment') ?? '';
  const token = params.get('token') ?? '';
  const [status, setStatus] = useState<Status | 'LOADING' | 'ERROR'>('LOADING');
  const [meta, setMeta] = useState<{ reference: string; amount: number } | null>(null);
  const tries = useRef(0);

  useEffect(() => {
    if (!paymentId) {
      setStatus('ERROR');
      return;
    }
    let stopped = false;
    async function poll() {
      try {
        const res = await fetch(`/api/payments/status?payment=${paymentId}&token=${token}`);
        if (!res.ok) {
          if (!stopped) setStatus('ERROR');
          return;
        }
        const json = await res.json();
        if (stopped) return;
        setMeta({ reference: json.reference, amount: json.amount });
        if (json.paymentStatus === 'CREATED') {
          // PAYMENT_PENDING — keep polling briefly (webhook may still land).
          if (tries.current < 8) {
            tries.current += 1;
            window.setTimeout(poll, 2500);
          } else {
            setStatus('CREATED');
          }
        } else {
          setStatus(json.paymentStatus as Status);
        }
      } catch {
        if (!stopped) setStatus('ERROR');
      }
    }
    poll();
    return () => {
      stopped = true;
    };
  }, [paymentId, token]);

  return (
    <div className="shell flex min-h-[70vh] items-center justify-center py-16">
      <div className="w-full max-w-md text-center">
        {(status === 'LOADING' || status === 'CREATED') && (
          <div className="card p-10">
            <Loader2 className="mx-auto animate-spin text-burgundy-600" size={36} aria-hidden />
            <h1 className="mt-5 font-display text-2xl text-burgundy-900">
              {status === 'CREATED' ? 'Payment pending' : 'Verifying your payment…'}
            </h1>
            <p className="mt-2 text-sm leading-relaxed text-ink-500">
              {status === 'CREATED'
                ? 'We have not received confirmation from the payment provider yet. Do not pay twice — this page will update automatically, and you can also check Track Order.'
                : 'Please wait while we confirm with the payment provider. Never trust the redirect alone — we verify via secure webhook.'}
            </p>
            {meta && (
              <p className="mt-3 text-xs text-ink-400">
                Order {meta.reference} · {formatINR(meta.amount)}
              </p>
            )}
          </div>
        )}

        {status === 'CAPTURED' && meta && (
          <div className="card p-10">
            <CheckCircle2 className="mx-auto text-emerald-600" size={44} aria-hidden />
            <h1 className="mt-5 font-display text-2xl text-burgundy-900">Payment verified</h1>
            <p className="mt-2 text-sm text-ink-500">
              Order <strong>{meta.reference}</strong> for {formatINR(meta.amount)} is confirmed. A confirmation email is
              on its way.
            </p>
            <Link
              href={`/order/${meta.reference}?token=${token}`}
              className="btn-primary btn-lg mt-6 w-full"
            >
              View Order Confirmation
            </Link>
          </div>
        )}

        {status === 'FAILED' && meta && (
          <div className="card p-10">
            <XCircle className="mx-auto text-burgundy-500" size={44} aria-hidden />
            <h1 className="mt-5 font-display text-2xl text-burgundy-900">Payment failed</h1>
            <p className="mt-2 text-sm text-ink-500">
              No money was captured. Your cart items and stock reservation are held briefly — you can try again.
            </p>
            <div className="mt-6 flex flex-col gap-2">
              <Link href="/checkout" className="btn-primary btn-md w-full">Try again</Link>
              <Link href="/collections" className="btn-ghost btn-md w-full">Back to shopping</Link>
            </div>
          </div>
        )}

        {status === 'ABANDONED' && (
          <div className="card p-10">
            <XCircle className="mx-auto text-ink-300" size={44} aria-hidden />
            <h1 className="mt-5 font-display text-2xl text-burgundy-900">Payment abandoned</h1>
            <p className="mt-2 text-sm text-ink-500">The payment session expired without completing. No charge was made.</p>
            <Link href="/cart" className="btn-primary btn-md mt-6 w-full">Return to cart</Link>
          </div>
        )}

        {status === 'ERROR' && (
          <div className="card p-10" role="alert">
            <h1 className="font-display text-2xl text-burgundy-900">We can’t show this payment</h1>
            <p className="mt-2 text-sm text-ink-500">
              This link is missing or expired. If you paid, don’t worry — verified payments always confirm the order.
              Contact support with your order reference.
            </p>
            <Link href="/track" className="btn-primary btn-md mt-6 w-full">Go to Track Order</Link>
          </div>
        )}
      </div>
    </div>
  );
}
