'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Loader2 } from 'lucide-react';

export function AuthForm({ mode }: { mode: 'login' | 'signup' }) {
  const router = useRouter();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const res = await fetch(mode === 'login' ? '/api/auth/login' : '/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, phone, password }),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.message ?? 'Something went wrong.');
        setBusy(false);
        return;
      }
      router.push('/account');
      router.refresh();
    } catch {
      setError('Could not reach the server. Please try again.');
      setBusy(false);
    }
  }

  return (
    <div className="shell flex min-h-[70vh] items-center justify-center py-16">
      <div className="w-full max-w-md">
        <div className="card p-8">
          <p className="eyebrow text-center">RV Gift Collection</p>
          <h1 className="mt-2 text-center font-display text-2xl text-burgundy-900">
            {mode === 'login' ? 'Welcome back' : 'Create your account'}
          </h1>
          <p className="mt-1 text-center text-xs text-ink-400">
            {mode === 'login' ? 'Log in to view orders, addresses and faster checkout.' : 'Save addresses and track orders in one place.'}
          </p>

          <form onSubmit={submit} className="mt-6 space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="label" htmlFor="name">Full name</label>
                <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" required minLength={2} />
              </div>
            )}
            <div>
              <label className="label" htmlFor="email">Email</label>
              <input id="email" type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required />
            </div>
            {mode === 'signup' && (
              <div>
                <label className="label" htmlFor="phone">Phone (optional)</label>
                <input id="phone" inputMode="numeric" className="input" value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))} autoComplete="tel" />
              </div>
            )}
            <div>
              <label className="label" htmlFor="password">Password</label>
              <input id="password" type="password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required minLength={8} />
              {mode === 'signup' && <p className="mt-1 text-[11px] text-ink-400">At least 8 characters.</p>}
            </div>
            {error && (
              <p className="rounded-lg bg-burgundy-50 p-3 text-xs font-medium text-burgundy-700" role="alert">{error}</p>
            )}
            <button type="submit" className="btn-primary btn-lg w-full" disabled={busy}>
              {busy && <Loader2 size={16} className="animate-spin" aria-hidden />}
              {mode === 'login' ? 'Log In' : 'Create Account'}
            </button>
          </form>

          <p className="mt-5 text-center text-xs text-ink-500">
            {mode === 'login' ? (
              <>New here? <Link href="/signup" className="font-semibold text-burgundy-700 underline">Create an account</Link></>
            ) : (
              <>Already have an account? <Link href="/login" className="font-semibold text-burgundy-700 underline">Log in</Link></>
            )}
          </p>
        </div>
        <p className="mt-4 text-center text-[11px] leading-relaxed text-ink-400">
          Demo build: accounts are stored in-memory. Production uses Supabase Auth with MFA — passwords never live in custom tables.
        </p>
      </div>
    </div>
  );
}
