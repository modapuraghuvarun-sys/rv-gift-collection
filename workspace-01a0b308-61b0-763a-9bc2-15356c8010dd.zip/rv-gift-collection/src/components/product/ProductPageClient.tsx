'use client';

import { useMemo, useState } from 'react';
import Image from 'next/image';
import { Check, ChevronDown, ChevronUp, ShoppingBag, X } from 'lucide-react';
import { PinChecker } from '@/components/PinChecker';
import { PersonalizationStudio, QtyPicker } from '@/components/personalization/PersonalizationStudio';
import { useCart } from '@/components/cart/CartProvider';
import type { CartLine, Product, ProductVariant } from '@/lib/types';
import { formatINR } from '@/lib/money';
import { cn, uid } from '@/lib/utils';

interface VariantWithStock extends ProductVariant {
  stockAvailable: number;
  lowStock: boolean;
}

export function ProductPageClient({ product }: { product: Product }) {
  const variants = product.variants as VariantWithStock[];
  const { addLine } = useCart();

  const [activeImage, setActiveImage] = useState(0);
  const [variantId, setVariantId] = useState(variants.find((v) => v.available)?.id ?? variants[0].id);
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const [studioOpen, setStudioOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState<string | null>('description');

  const variant = useMemo(() => variants.find((v) => v.id === variantId) ?? variants[0], [variants, variantId]);

  function selectVariant(v: VariantWithStock) {
    if (!v.available) return;
    setVariantId(v.id);
    setAdded(false);
  }

  function addPlainToCart() {
    if (!variant.available) return;
    const line: CartLine = {
      id: uid('line'),
      productId: product.id,
      slug: product.slug,
      variantId: variant.id,
      qty,
      addedAt: new Date().toISOString(),
    };
    addLine(line);
    setAdded(true);
    window.setTimeout(() => setAdded(false), 2600);
  }

  return (
    <>
      <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
        {/* ── Gallery ─────────────────────────────────────────────────── */}
        <div>
          <div className="group relative aspect-square overflow-hidden rounded-xl2 bg-cream-100 shadow-soft">
            <Image
              src={product.images[activeImage]}
              alt={`${product.name} — image ${activeImage + 1}`}
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover transition-transform duration-700 group-hover:scale-[1.04]"
            />
          </div>
          {product.images.length > 1 && (
            <div className="mt-3 flex gap-3" role="tablist" aria-label="Product images">
              {product.images.map((img, i) => (
                <button
                  key={img + i}
                  role="tab"
                  aria-selected={activeImage === i}
                  aria-label={`View image ${i + 1}`}
                  onClick={() => setActiveImage(i)}
                  className={cn(
                    'relative h-20 w-20 overflow-hidden rounded-xl border-2 transition-all',
                    activeImage === i ? 'border-burgundy-700' : 'border-transparent opacity-70 hover:opacity-100',
                  )}
                >
                  <Image src={img} alt="" fill sizes="80px" className="object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ── Purchase panel ───────────────────────────────────────────── */}
        <div className="pb-24 md:pb-0">
          <p className="eyebrow">{product.category.replace(/-/g, ' ')}</p>
          <h1 className="mt-2 font-display text-3xl text-burgundy-900 md:text-4xl">{product.name}</h1>
          <p className="mt-2 text-sm leading-relaxed text-ink-500">{product.shortDescription}</p>

          <div className="mt-4 flex items-baseline gap-3">
            <p className="text-2xl font-bold text-burgundy-900" aria-live="polite">
              {formatINR(variant.price)}
            </p>
            <p className="text-xs text-ink-400">Inclusive of all taxes</p>
          </div>

          {/* Variant selector */}
          {variants.length > 0 && (
            <div className="mt-6">
              <p className="label">
                Option <span className="normal-case text-ink-400">— {variant.name}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {variants.map((v) => (
                  <button
                    key={v.id}
                    onClick={() => selectVariant(v)}
                    disabled={!v.available}
                    aria-pressed={v.id === variant.id}
                    className={cn(
                      'rounded-full border px-4 py-2 text-sm font-medium transition-all',
                      v.id === variant.id
                        ? 'border-burgundy-800 bg-burgundy-800 text-cream-50'
                        : v.available
                          ? 'border-cream-300 bg-white text-ink-700 hover:border-burgundy-400'
                          : 'cursor-not-allowed border-cream-200 bg-cream-100 text-ink-300 line-through',
                    )}
                  >
                    {v.name}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-xs" aria-live="polite">
                <span className="font-mono text-ink-400">SKU {variant.sku}</span>
                {variant.available ? (
                  variant.lowStock ? (
                    <span className="ml-2 font-semibold text-burgundy-600">
                      Only {variant.stockAvailable} left
                    </span>
                  ) : (
                    <span className="ml-2 inline-flex items-center gap-1 font-semibold text-emerald-700">
                      <Check size={12} aria-hidden /> In stock
                    </span>
                  )
                ) : (
                  <span className="ml-2 font-semibold text-ink-400">Currently unavailable</span>
                )}
              </p>
            </div>
          )}

          {/* Delivery checker */}
          <div className="mt-6">
            <PinChecker productId={product.id} />
          </div>

          {/* Personalization / Add to cart */}
          <div className="mt-6">
            {product.personalisation ? (
              <>
                <div className="mb-3 rounded-xl bg-burgundy-50 p-4 text-sm text-burgundy-900">
                  <p className="font-semibold">This gift is personalized</p>
                  <p className="mt-0.5 text-xs text-burgundy-700">
                    {product.personalisation.photos.count > 0
                      ? `Add ${product.personalisation.photos.count > 1 ? 'photos' : 'a photo'} and text, preview the design, then approve it.`
                      : 'Add your text, preview the design, then approve it.'}{' '}
                    Production takes {product.leadTimeDays} business day{product.leadTimeDays > 1 ? 's' : ''}.
                  </p>
                </div>
                <button className="btn-primary btn-lg w-full" onClick={() => setStudioOpen(true)} disabled={!variant.available}>
                  <ShoppingBag size={18} aria-hidden /> Personalize & Add to Cart
                </button>
              </>
            ) : (
              <div className="flex items-center gap-3">
                <QtyPicker qty={qty} onChange={setQty} />
                <button className="btn-primary btn-lg flex-1" onClick={addPlainToCart} disabled={!variant.available}>
                  {added ? '✓ Added to cart' : variant.available ? 'Add to Cart' : 'Out of stock'}
                </button>
              </div>
            )}
          </div>

          {/* Accordion */}
          <div className="mt-8 divide-y divide-cream-200 border-y border-cream-200">
            <AccordionRow id="description" title="Description" open={infoOpen} setOpen={setInfoOpen}>
              <p className="text-sm leading-relaxed text-ink-500">{product.description}</p>
            </AccordionRow>
            <AccordionRow id="details" title="Dimensions, material & care" open={infoOpen} setOpen={setInfoOpen}>
              <ul className="space-y-1.5 text-sm text-ink-500">
                <li><strong className="text-ink-700">Dimensions:</strong> {product.dimensions}</li>
                <li><strong className="text-ink-700">Material:</strong> {product.material}</li>
                <li><strong className="text-ink-700">Care:</strong> {product.care}</li>
              </ul>
            </AccordionRow>
            <AccordionRow id="policies" title="Shipping & returns" open={infoOpen} setOpen={setInfoOpen}>
              <p className="text-sm leading-relaxed text-ink-500">
                Made to order with a {product.leadTimeDays}-business-day production time, then delivered with tracking.
                Check your PIN code above for the estimated window. Personalized items can only be returned if damaged or
                incorrect — see <a className="text-burgundy-700 underline" href="/policies/shipping">Shipping</a> and{' '}
                <a className="text-burgundy-700 underline" href="/policies/returns">Returns</a>.
              </p>
            </AccordionRow>
          </div>
        </div>
      </div>

      {/* Sticky mobile add-to-cart */}
      <div className="fixed inset-x-0 bottom-14 z-30 border-t border-cream-200 bg-white/95 p-3 backdrop-blur md:hidden">
        {product.personalisation ? (
          <button className="btn-primary btn-md w-full" onClick={() => setStudioOpen(true)} disabled={!variant.available}>
            Personalize & Add · {formatINR(variant.price)}
          </button>
        ) : (
          <button className="btn-primary btn-md w-full" onClick={addPlainToCart} disabled={!variant.available}>
            {added ? '✓ Added' : `Add to Cart · ${formatINR(variant.price * qty)}`}
          </button>
        )}
      </div>

      {/* Personalization studio modal */}
      {studioOpen && product.personalisation && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-ink-900/50 p-0 sm:p-6" role="dialog" aria-modal="true" aria-label="Personalization studio">
          <div className="mx-auto min-h-full max-w-4xl sm:rounded-2xl">
            <div className="relative bg-cream-50 sm:rounded-2xl">
              <button
                className="absolute right-4 top-4 z-10 rounded-full bg-white p-2 shadow-soft hover:bg-cream-200"
                aria-label="Close personalization studio"
                onClick={() => setStudioOpen(false)}
              >
                <X size={18} />
              </button>
              <div className="p-5 sm:p-8">
                <PersonalizationStudio
                  product={product}
                  variantId={variant.id}
                  variantName={variant.name}
                  variantPrice={variant.price}
                  onDone={() => {
                    setStudioOpen(false);
                    setAdded(true);
                    window.setTimeout(() => setAdded(false), 2600);
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function AccordionRow({
  id,
  title,
  open,
  setOpen,
  children,
}: {
  id: string;
  title: string;
  open: string | null;
  setOpen: (v: string | null) => void;
  children: React.ReactNode;
}) {
  const isOpen = open === id;
  return (
    <div>
      <button
        className="flex w-full items-center justify-between py-4 text-left text-sm font-semibold text-ink-900"
        onClick={() => setOpen(isOpen ? null : id)}
        aria-expanded={isOpen}
        aria-controls={`acc-${id}`}
      >
        {title}
        {isOpen ? <ChevronUp size={16} aria-hidden /> : <ChevronDown size={16} aria-hidden />}
      </button>
      {isOpen && (
        <div id={`acc-${id}`} className="pb-4">
          {children}
        </div>
      )}
    </div>
  );
}
