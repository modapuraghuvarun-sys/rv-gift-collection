'use client';

/**
 * Client cart store. Every personalized configuration is its own line.
 * Totals shown here are indicative — the server recomputes authoritative
 * prices via /api/checkout/quote at cart & checkout.
 */

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { CartLine } from '@/lib/types';

const STORAGE_KEY = 'rv_cart_v1';
const GUEST_ORDERS_KEY = 'rv_guest_orders_v1';

interface CartContextValue {
  lines: CartLine[];
  count: number;
  addLine: (line: CartLine) => void;
  updateQty: (lineId: string, qty: number) => void;
  removeLine: (lineId: string) => void;
  replaceLine: (lineId: string, line: CartLine) => void;
  clear: () => void;
  addGuestOrder: (entry: { reference: string; token: string; at: string }) => void;
  guestOrders: { reference: string; token: string; at: string }[];
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [guestOrders, setGuestOrders] = useState<{ reference: string; token: string; at: string }[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setLines(JSON.parse(raw));
      const go = localStorage.getItem(GUEST_ORDERS_KEY);
      if (go) setGuestOrders(JSON.parse(go));
    } catch {
      /* ignore corrupt storage */
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
  }, [lines, loaded]);

  useEffect(() => {
    if (loaded) localStorage.setItem(GUEST_ORDERS_KEY, JSON.stringify(guestOrders));
  }, [guestOrders, loaded]);

  const addLine = useCallback((line: CartLine) => {
    setLines((prev) => [...prev, line]);
  }, []);
  const updateQty = useCallback((lineId: string, qty: number) => {
    setLines((prev) => prev.map((l) => (l.id === lineId ? { ...l, qty: Math.max(1, Math.min(10, qty)) } : l)));
  }, []);
  const removeLine = useCallback((lineId: string) => {
    setLines((prev) => prev.filter((l) => l.id !== lineId));
  }, []);
  const replaceLine = useCallback((lineId: string, line: CartLine) => {
    setLines((prev) => prev.map((l) => (l.id === lineId ? line : l)));
  }, []);
  const clear = useCallback(() => setLines([]), []);
  const addGuestOrder = useCallback((entry: { reference: string; token: string; at: string }) => {
    setGuestOrders((prev) => [entry, ...prev.filter((e) => e.reference !== entry.reference)].slice(0, 10));
  }, []);

  const value = useMemo<CartContextValue>(
    () => ({ lines, count: lines.reduce((a, l) => a + l.qty, 0), addLine, updateQty, removeLine, replaceLine, clear, addGuestOrder, guestOrders }),
    [lines, guestOrders, addLine, updateQty, removeLine, replaceLine, clear, addGuestOrder],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used inside CartProvider');
  return ctx;
}
