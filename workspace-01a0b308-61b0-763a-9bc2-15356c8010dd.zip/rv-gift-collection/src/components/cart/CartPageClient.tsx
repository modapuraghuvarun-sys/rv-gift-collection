'use client';

import Link from 'next/link';
import { useEffect, useMemo, useRef, useState } from 'react';
import Image from 'next/image';
import { AlertTriangle, BadgeCheck, Pencil, ShoppingBag, Tag, Trash2 } from 'lucide-react';
import { useCart } from '@/components/cart/CartProvider';
import type { Quote } from '@/lib/types';
import { formatINR } from '@/lib/money';
import { cn } from '@/lib/utils';

export function CartPageClient() {
  const { lines, updateQty, removeLine } = useCart();
  const [quote, setQuote] = useState<Quote | null>(null);
  const [quoteError, setQuoteError] = useState('');
  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | undefined>();
  const [couponMsg, setCouponMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pincode, setPincode] = useState('');
  const seq = useRef(0);

  const needsApproval = useMemo(
    () => lines.some((l) => l.personalisation && !l.personalisation.approvedAt),
    [lines],
  );

  useEffect(() => {
    if (!lines.length) {
      setQuote(null);
      return;
    }
    const mySeq = ++seq.current;
    const t = window.setTimeout(async () => {
      try {
        const res = await fetch('/api/checkout/quote', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ lines, couponCode: appliedCoupon, pincode: pincode || undefined }),
        });
        const json = await res.json();
        if (mySeq !== seq.current) return;
        if (!res.ok) {
          setQuote(null);
          setQuoteError(json.message ?? 'Your cart needs attention.');
          if (json.error?.startsWith?.('COUPON')) {
            setCouponMsg({ ok: false, text: json.message });
            setAppliedCoupon(undefined);
          }
        } else {
          setQuote(json);
          setQuoteError('');
        }
      } catch {
        if (mySeq === seq.current) setQuoteError('Could not refresh pricing. Please try again.');
      }
    }, 350);
    return () => window.clearTimeout(t);
  }, [lines, appliedCoupon, pincode]);

  function applyCoupon(e: React.FormEvent) {
    e.preventDefault();
    if (!couponInput.trim()) return;
    setAppliedCoupon(couponInput.trim().toUpperCase());
    setCouponMsg({ ok: true, text: 'Checking coupon…' });
  }

  useEffect(() => {
    if (quote?.couponCode) setCouponMsg({ ok: true, text: `Coupon ${quote.couponCode} applied.` });
  }, [quote?.couponCode]);

  if (!lines.length) {
    return (
      <div className="shell flex flex-col items-center py-24 text-center">
        <span className="flex h-16 w-16 items-center justify-center rounded-full bg-burgundy-50 text-burgundy-700">
          <ShoppingBag size={26} aria-hidden />
        </span>
        <h1 className="mt-5 font-display text-2xl text-burgundy-900">Your cart is empty</h1>
        <p className="mt-2 max-w-sm text-sm text-ink-500">
          Find a gift worth personalizing — mugs, frames, lamps, cushions and more.
        </p>
        <Link href="/collections" className="btn-primary btn-lg mt-6">
          Explore Gifts
        </Link>
      </div>
    );
  }

  return (
    <div className="shell py-8 md:py-12">
      <h1 className="section-title">Your Cart</h1>
      {needsApproval && (
        <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-gold-300 bg-gold-200/30 p-4 text-sm text-ink-700" role="alert">
          <AlertTriangle size={16} className="mt-0.5 shrink-0 text-gold-600" aria-hidden />
          <p>
            One or more items need personalization approval before checkout. Use <strong>Edit personalization</strong> to
            review and re-approve.
          </p>
        </div>
      )}
      {quoteError && (
        <div className="mt-4 flex items-start gap-2.5 rounded-xl border border-burgundy-200 bg-burgundy-50 p-4 text-sm text-burgundy-800" role="alert">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" aria-hidden />
          <p>{quoteError}</p>
        </div>
      )}

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
        {/* Lines */}
        <ul className="space-y-4">
          {lines.map((line) => {
            const quoteLine = quote?.lines.find((q) => q.lineId === line.id);
            const img = line.personalisation?.previewThumb ?? quoteLine?.image ?? '/images/hero.jpg';
            return (
              <li key={line.id} className="card flex gap-4 p-4">
                <Link href={`/product/${line.slug}`} className="relative block h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-cream-100 sm:h-28 sm:w-28">
                  {line.personalisation?.previewThumb ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={img} alt="Your approved design" className="h-full w-full object-cover" />
                  ) : (
                    <Image src={img} alt={quoteLine?.name ?? 'Product'} fill sizes="112px" className="object-cover" />
                  )}
                </Link>
                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <Link href={`/product/${line.slug}`} className="text-sm font-semibold text-ink-900 hover:text-burgundy-800">
                        {quoteLine?.name ?? 'Gift'}
                      </Link>
                      <p className="mt-0.5 text-xs text-ink-400">{quoteLine?.variantName}</p>
                    </div>
                    <p className="text-sm font-bold text-burgundy-900">
                      {formatINR((quoteLine?.lineTotal ?? quoteLine?.unitPrice ?? 0) || 0)}
                    </p>
                  </div>

                  {quoteLine?.personalisationSummary && (
                    <div className="mt-2 space-y-0.5 rounded-lg bg-cream-100 p-2.5 text-[11px] text-ink-500">
                      {Object.entries(quoteLine.personalisationSummary).map(([k, v]) => (
                        <p key={k}>
                          <strong className="text-ink-700">{k}:</strong> {v}
                        </p>
                      ))}
                      {line.personalisation?.approvedAt && (
                        <p className="flex items-center gap-1 font-semibold text-emerald-700">
                          <BadgeCheck size={12} aria-hidden /> Personalization approved
                        </p>
                      )}
                    </div>
                  )}

                  <div className="mt-3 flex flex-wrap items-center gap-3">
                    <div className="inline-flex items-center rounded-full border border-cream-300 text-sm">
                      <button className="px-2.5 py-1 text-ink-500 disabled:opacity-30" onClick={() => updateQty(line.id, line.qty - 1)} disabled={line.qty <= 1} aria-label="Decrease quantity">−</button>
                      <span className="min-w-7 text-center font-semibold">{line.qty}</span>
                      <button className="px-2.5 py-1 text-ink-500 disabled:opacity-30" onClick={() => updateQty(line.id, line.qty + 1)} disabled={line.qty >= 10} aria-label="Increase quantity">+</button>
                    </div>
                    {quoteLine?.hasPersonalisation && (
                      <Link href={`/product/${line.slug}?personalise=${line.id}`} className="inline-flex items-center gap-1 text-xs font-semibold text-burgundy-700 hover:underline">
                        <Pencil size={12} aria-hidden /> Edit personalization
                      </Link>
                    )}
                    <button
                      onClick={() => removeLine(line.id)}
                      className="inline-flex items-center gap-1 text-xs font-semibold text-ink-400 hover:text-burgundy-700"
                    >
                      <Trash2 size={12} aria-hidden /> Remove
                    </button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>

        {/* Summary */}
        <aside className="h-fit lg:sticky lg:top-24" aria-label="Order summary">
          <div className="card p-6">
            <h2 className="font-display text-lg text-burgundy-900">Summary</h2>

            <div className="mt-4 space-y-2.5">
              <div>
                <label className="label" htmlFor="cart-pin">Delivery PIN code (optional)</label>
                <input
                  id="cart-pin"
                  className="input"
                  inputMode="numeric"
                  maxLength={6}
                  placeholder="e.g. 500081"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                />
              </div>
              <form onSubmit={applyCoupon}>
                <label className="label" htmlFor="cart-coupon">Coupon</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-300" aria-hidden />
                    <input
                      id="cart-coupon"
                      className="input pl-8 uppercase"
                      placeholder="RVWELCOME"
                      value={couponInput}
                      onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                    />
                  </div>
                  <button type="submit" className="btn-outline btn-sm shrink-0">Apply</button>
                </div>
              </form>
              {couponMsg && (
                <p className={cn('text-xs font-medium', couponMsg.ok ? 'text-emerald-700' : 'text-burgundy-600')} role="status">
                  {couponMsg.text}
                </p>
              )}
            </div>

            <dl className="mt-5 space-y-2 border-t border-cream-200 pt-4 text-sm">
              <Row label="Subtotal" value={quote ? formatINR(quote.subtotal) : '—'} />
              {quote && quote.discount > 0 && <Row label={`Discount${quote.couponCode ? ` (${quote.couponCode})` : ''}`} value={`− ${formatINR(quote.discount)}`} accent />}
              <Row label="Tax (included)" value={quote ? formatINR(quote.taxIncluded) : '—'} muted />
              <Row
                label={`Delivery${quote?.deliveryWindow ? ` · est. ${quote.deliveryWindow}` : ''}`}
                value={quote ? (quote.deliveryFee === 0 ? (pincode ? 'Free' : 'At checkout') : formatINR(quote.deliveryFee)) : 'At checkout'}
              />
              <div className="flex items-baseline justify-between border-t border-cream-200 pt-3">
                <dt className="text-base font-bold text-ink-900">Total</dt>
                <dd className="text-xl font-bold text-burgundy-900">{quote ? formatINR(quote.total) : '—'}</dd>
              </div>
            </dl>

            {quote && (
              <p className="mt-2 text-[11px] text-ink-400" aria-live="polite">
                Quote valid until {new Date(quote.expiresAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}.
                Final amounts are always verified by the server before payment.
              </p>
            )}

            <Link
              href={quote && !needsApproval ? `/checkout?quote=${quote.id}` : '#'}
              aria-disabled={!quote || needsApproval}
              className={cn('btn-primary btn-lg mt-5 w-full', (!quote || needsApproval) && 'pointer-events-none opacity-50')}
            >
              Proceed to Checkout
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Row({ label, value, accent, muted }: { label: string; value: string; accent?: boolean; muted?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <dt className={cn('text-ink-500', muted && 'text-xs text-ink-400')}>{label}</dt>
      <dd className={cn('font-semibold text-ink-900', accent && 'text-emerald-700')}>{value}</dd>
    </div>
  );
}
