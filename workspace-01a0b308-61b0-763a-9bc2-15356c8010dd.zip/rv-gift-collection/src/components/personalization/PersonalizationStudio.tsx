'use client';

/**
 * Personalization studio: per-product required fields, validated photo
 * upload (JPEG/PNG, ≤10MB, magic bytes, decode, pixel checks, metadata-free
 * re-encode), live 2D preview with explicit crop control, and a mandatory
 * "Review Your Personalization" approval step before Add to Cart.
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, ImagePlus, Info, Trash2, X } from 'lucide-react';
import { PreviewCanvas, rasterizePreview, type PreviewState } from '@/components/personalization/PreviewCanvas';
import { useCart } from '@/components/cart/CartProvider';
import type { CartLine, CropConfig, Product } from '@/lib/types';
import { formatINR } from '@/lib/money';
import { uid } from '@/lib/utils';

interface Props {
  product: Product;
  variantId: string;
  variantName: string;
  variantPrice: number;
  editingLine?: CartLine;
  onDone: () => void;
}

interface PhotoSlot {
  dataUrl: string; // preview + cart thumbnail (metadata-free re-encode)
  assetId: string; // server-side private asset
  width: number;
  height: number;
}

export function PersonalizationStudio({ product, variantId, variantName, variantPrice, editingLine, onDone }: Props) {
  const template = product.personalisation!;
  const { addLine, replaceLine } = useCart();

  const [step, setStep] = useState(0);
  const [fields, setFields] = useState<Record<string, string>>(editingLine?.personalisation?.fields ?? {});
  const [photos, setPhotos] = useState<PhotoSlot[]>(
    (editingLine?.personalisation?.photoThumbs ?? []).map((t, i) => ({
      dataUrl: t,
      assetId: editingLine?.personalisation?.assetIds[i] ?? '',
      width: 0,
      height: 0,
    })),
  );
  const [uploadErrors, setUploadErrors] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [textColor, setTextColor] = useState(editingLine?.personalisation?.textColor ?? template.textColors[0]);
  const [crop, setCrop] = useState<CropConfig>(editingLine?.personalisation?.crop ?? { scale: 1, x: 0, y: 0 });
  const [qty, setQty] = useState(editingLine?.qty ?? 1);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [approved, setApproved] = useState(false);
  const svgRef = useRef<SVGSVGElement>(null);
  const fileInputs = useRef<(HTMLInputElement | null)[]>([]);

  const steps = useMemo(() => {
    const s = ['Details'];
    if (template.photos.count > 0) s.push(template.photos.count > 1 ? 'Photos' : 'Photo');
    s.push('Preview');
    return s;
  }, [template]);

  const previewState: PreviewState = {
    template,
    fields,
    photos: photos.map((p) => p.dataUrl),
    textColor,
    crop,
    productName: product.name,
  };

  const fieldIssues = template.fields.filter((f) => f.required && !(fields[f.key] ?? '').trim());
  const photoIssues = template.photos.count > 0 && photos.length < template.photos.count;

  // ── Upload pipeline ────────────────────────────────────────────────────────
  async function handleFile(file: File, index: number) {
    setUploadErrors((prev) => prev.filter((_, i) => i !== index));
    const fail = (message: string) => setUploadErrors((prev) => [...prev.slice(0, index), message, ...prev.slice(index + 1)]);

    // 1. Type + size (client first-pass; server re-validates everything).
    if (!['image/jpeg', 'image/png'].includes(file.type)) {
      fail('Only JPEG or PNG photos are accepted — SVGs and documents are not supported.');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      fail('Please choose a photo under 10 MB.');
      return;
    }

    try {
      // 2. File signature check.
      const head = new Uint8Array(await file.slice(0, 12).arrayBuffer());
      const isJpeg = head[0] === 0xff && head[1] === 0xd8 && head[2] === 0xff;
      const isPng = head[0] === 0x89 && head[1] === 0x50 && head[2] === 0x4e && head[3] === 0x47;
      if (!isJpeg && !isPng) {
        fail('This file is not a genuine JPEG or PNG image.');
        return;
      }

      // 3. Decode + pixel dimension validation.
      const bitmap = await createImageBitmap(file);
      const { minPx, maxPx } = template.photos;
      if (minPx && Math.min(bitmap.width, bitmap.height) < minPx) {
        fail(`This photo is too small for a sharp print — please use one at least ${minPx}px on its shorter side.`);
        bitmap.close();
        return;
      }

      // 4. Safe re-encode through canvas: strips EXIF/metadata; downscales
      //    anything above the max (resize, never crop).
      const overMax = maxPx && Math.max(bitmap.width, bitmap.height) > maxPx;
      const ratio = overMax ? maxPx / Math.max(bitmap.width, bitmap.height) : 1;
      const w = Math.round(bitmap.width * ratio);
      const h = Math.round(bitmap.height * ratio);
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(bitmap, 0, 0, w, h);
      bitmap.close();

      const outType = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, outType, 0.92));
      if (!blob) {
        fail('We could not process this photo. Please try another one.');
        return;
      }

      // 5. Authorise with the server (validates product constraints).
      setUploading(true);
      const authRes = await fetch('/api/uploads/authorise', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contentType: outType, size: blob.size, width: w, height: h, productId: product.id, photoIndex: index }),
      });
      const authJson = await authRes.json();
      if (!authRes.ok) {
        fail(authJson.message ?? 'Upload rejected.');
        setUploading(false);
        return;
      }

      // 6. Deliver bytes (private storage in production; in-memory in demo).
      const doneRes = await fetch(`/api/uploads/${authJson.uploadId}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: blob,
      });
      const doneJson = await doneRes.json();
      if (!doneRes.ok) {
        fail(doneJson.message ?? 'Upload rejected.');
        setUploading(false);
        return;
      }

      const dataUrl = canvas.toDataURL(outType, 0.85);
      setPhotos((prev) => {
        const next = [...prev];
        next[index] = { dataUrl, assetId: doneJson.assetId, width: w, height: h };
        return next;
      });
      setUploading(false);
    } catch {
      fail('This image could not be read. Please choose a different photo.');
    }
  }

  // ── Review + approve ──────────────────────────────────────────────────────
  async function addToCart() {
    const previewThumb = svgRef.current ? await rasterizePreview(svgRef.current) : undefined;
    const line: CartLine = {
      id: editingLine?.id ?? uid('line'),
      productId: product.id,
      slug: product.slug,
      variantId,
      qty,
      addedAt: new Date().toISOString(),
      personalisation: {
        templateId: template.id,
        templateVersion: template.version,
        fields: Object.fromEntries(Object.entries(fields).map(([k, v]) => [k, v.trim()])),
        assetIds: photos.map((p) => p.assetId),
        photoThumbs: photos.map((p) => p.dataUrl),
        previewThumb,
        textColor,
        crop,
        approvedAt: new Date().toISOString(),
      },
    };
    if (editingLine) replaceLine(editingLine.id, line);
    else addLine(line);
    setReviewOpen(false);
    onDone();
  }

  const canContinue =
    step === 0
      ? fieldIssues.length === 0
      : step === steps.length - 1
        ? true
        : photos.filter(Boolean).length >= template.photos.count;

  return (
    <section className="rounded-xl2 border border-cream-300 bg-white p-5 shadow-soft sm:p-6" aria-label="Personalization studio">
      <div className="mb-5 flex items-center justify-between gap-3">
        <h2 className="font-display text-xl text-burgundy-900">Personalize it</h2>
        <ol className="flex items-center gap-1.5" aria-label="Personalization steps">
          {steps.map((label, i) => (
            <li key={label} className="flex items-center gap-1.5">
              <span
                className={`flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-bold ${
                  i === step ? 'bg-burgundy-800 text-cream-50' : i < step ? 'bg-gold-300 text-burgundy-950' : 'bg-cream-200 text-ink-400'
                }`}
                aria-current={i === step ? 'step' : undefined}
              >
                {i < step ? <Check size={12} aria-hidden /> : i + 1}
              </span>
              <span className="hidden text-[11px] font-medium text-ink-500 sm:inline">{label}</span>
            </li>
          ))}
        </ol>
      </div>

      {/* STEP 0 — fields */}
      {step === 0 && (
        <div className="grid gap-4 sm:grid-cols-2">
          {template.fields.map((f) => (
            <div key={f.key} className={f.type === 'message' ? 'sm:col-span-2' : ''}>
              <label className="label" htmlFor={`fld-${f.key}`}>
                {f.label} {f.required && <span className="text-burgundy-600">*</span>}
              </label>
              {f.type === 'message' ? (
                <textarea
                  id={`fld-${f.key}`}
                  className="input min-h-20 resize-y"
                  maxLength={f.maxLength}
                  placeholder={f.placeholder}
                  value={fields[f.key] ?? ''}
                  onChange={(e) => setFields((prev) => ({ ...prev, [f.key]: e.target.value }))}
                />
              ) : (
                <input
                  id={`fld-${f.key}`}
                  className="input"
                  maxLength={f.maxLength}
                  placeholder={f.placeholder}
                  value={fields[f.key] ?? ''}
                  onChange={(e) => setFields((prev) => ({ ...prev, [f.key]: e.target.value }))}
                />
              )}
              <p className="mt-1 text-right text-[11px] text-ink-300">
                {(fields[f.key] ?? '').length}/{f.maxLength}
              </p>
            </div>
          ))}
          {template.textColors.length > 1 && (
            <div className="sm:col-span-2">
              <p className="label">Text / print colour</p>
              <div className="flex gap-2">
                {template.textColors.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setTextColor(c)}
                    className={`h-8 w-8 rounded-full border-2 transition-transform hover:scale-110 ${
                      textColor === c ? 'border-burgundy-700 ring-2 ring-burgundy-200' : 'border-cream-300'
                    }`}
                    style={{ backgroundColor: c }}
                    aria-label={`Colour ${c}`}
                    aria-pressed={textColor === c}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* PHOTO STEP */}
      {step === 1 && template.photos.count > 0 && (
        <div>
          <div className={`grid gap-4 ${template.photos.count > 1 ? 'sm:grid-cols-2' : ''}`}>
            {Array.from({ length: template.photos.count }).map((_, i) => {
              const slot = photos[i];
              return (
                <div key={i}>
                  <input
                    ref={(el) => {
                      fileInputs.current[i] = el;
                    }}
                    type="file"
                    accept="image/jpeg,image/png"
                    className="sr-only"
                    id={`photo-${i}`}
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) handleFile(f, i);
                      e.target.value = '';
                    }}
                  />
                  {slot ? (
                    <div className="relative overflow-hidden rounded-xl border border-cream-300">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={slot.dataUrl} alt={`Uploaded photo ${i + 1}`} className="aspect-square w-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setPhotos((prev) => prev.filter((_, j) => j !== i))}
                        className="absolute right-2 top-2 rounded-full bg-ink-900/70 p-1.5 text-cream-50 hover:bg-ink-900"
                        aria-label={`Remove photo ${i + 1}`}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => fileInputs.current[i]?.click()}
                      disabled={uploading}
                      className="flex aspect-square w-full flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-cream-300 text-ink-400 transition-colors hover:border-burgundy-300 hover:text-burgundy-700"
                    >
                      <ImagePlus size={26} aria-hidden />
                      <span className="text-xs font-semibold">{uploading ? 'Uploading…' : `Add photo ${template.photos.count > 1 ? i + 1 : ''}`}</span>
                      <span className="text-[11px] text-ink-300">JPEG or PNG · up to 10 MB</span>
                    </button>
                  )}
                  {uploadErrors[i] && (
                    <p className="mt-2 rounded-lg bg-burgundy-50 px-3 py-2 text-xs font-medium text-burgundy-700" role="alert">
                      {uploadErrors[i]}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
          <div className="mt-4 flex items-start gap-2 rounded-xl bg-cream-100 p-3 text-xs text-ink-500">
            <Info size={14} className="mt-0.5 shrink-0 text-gold-600" aria-hidden />
            <p>
              Photos are validated and stored privately — they are never public. We remove camera metadata automatically.
              Minimum {template.photos.minPx}px on the shorter side for a crisp print.
            </p>
          </div>
        </div>
      )}

      {/* PREVIEW STEP */}
      {step === steps.length - 1 && (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,420px)_1fr]">
          <div>
            <div className="overflow-hidden rounded-xl border border-cream-300">
              <PreviewCanvas ref={svgRef} state={previewState} className="block w-full" />
            </div>
            <p className="mt-2 flex items-start gap-1.5 text-[11px] leading-relaxed text-ink-400">
              <Info size={12} className="mt-0.5 shrink-0" aria-hidden />
              Approximate preview — final print placement, colours and material finish may vary slightly. What you see
              in the dashed area is the exact crop you approve.
            </p>
          </div>

          {template.photos.count > 0 && photos.length > 0 && (
            <div className="space-y-5">
              <h3 className="text-sm font-semibold text-ink-900">Adjust photo placement</h3>
              <RangeControl
                label="Zoom"
                value={crop.scale}
                min={1}
                max={2.5}
                step={0.01}
                onChange={(v) => setCrop((c) => ({ ...c, scale: v }))}
                format={(v) => `${v.toFixed(2)}×`}
              />
              <RangeControl
                label="Move horizontally"
                value={crop.x}
                min={-1}
                max={1}
                step={0.01}
                onChange={(v) => setCrop((c) => ({ ...c, x: v }))}
                format={(v) => (v === 0 ? 'Centre' : v > 0 ? 'Right' : 'Left')}
              />
              <RangeControl
                label="Move vertically"
                value={crop.y}
                min={-1}
                max={1}
                step={0.01}
                onChange={(v) => setCrop((c) => ({ ...c, y: v }))}
                format={(v) => (v === 0 ? 'Centre' : v > 0 ? 'Down' : 'Up')}
              />
              <button
                className="btn-ghost btn-sm"
                onClick={() => setCrop({ scale: 1, x: 0, y: 0 })}
              >
                Reset placement
              </button>
              <p className="rounded-xl bg-cream-100 p-3 text-xs leading-relaxed text-ink-500">
                We never auto-crop your photo. Use zoom and position so the important parts sit inside the dashed print
                area — this exact placement is what we produce.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Nav */}
      <div className="mt-6 flex items-center justify-between gap-3 border-t border-cream-200 pt-4">
        <button
          type="button"
          className="btn-ghost btn-md"
          onClick={() => (step === 0 ? undefined : setStep((s) => s - 1))}
          disabled={step === 0}
        >
          <ChevronLeft size={16} aria-hidden /> Back
        </button>
        {step < steps.length - 1 ? (
          <button type="button" className="btn-primary btn-md" disabled={!canContinue || uploading} onClick={() => setStep((s) => s + 1)}>
            Continue <ChevronRight size={16} aria-hidden />
          </button>
        ) : (
          <button type="button" className="btn-primary btn-md" onClick={() => { setApproved(false); setReviewOpen(true); }}>
            Review & Approve
          </button>
        )}
      </div>

      {/* REVIEW MODAL */}
      {reviewOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center" role="dialog" aria-modal="true" aria-label="Review your personalization">
          <div className="absolute inset-0 bg-ink-900/50" onClick={() => setReviewOpen(false)} />
          <div className="relative max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-2xl bg-white p-6 shadow-lift sm:rounded-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-display text-xl text-burgundy-900">Review Your Personalization</h3>
              <button className="rounded-lg p-2 hover:bg-cream-200" aria-label="Close review" onClick={() => setReviewOpen(false)}>
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 text-sm">
              <ReviewRow label="Product" value={product.name} />
              <ReviewRow label="Option" value={variantName} />
              {template.fields.map((f) =>
                fields[f.key] ? <ReviewRow key={f.key} label={f.label} value={fields[f.key]} /> : null,
              )}
              {photos.length > 0 && (
                <div className="flex items-center justify-between gap-4">
                  <dt className="text-xs font-semibold uppercase tracking-wider text-ink-400">Photo{photos.length > 1 ? 's' : ''}</dt>
                  <dd className="flex gap-2">
                    {photos.map((p, i) => (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img key={i} src={p.dataUrl} alt={`Approved photo ${i + 1}`} className="h-12 w-12 rounded-lg border border-cream-300 object-cover" />
                    ))}
                  </dd>
                </div>
              )}
              <ReviewRow label="Placement" value={`Zoom ${crop.scale.toFixed(2)}× · ${crop.x === 0 && crop.y === 0 ? 'centred' : 'adjusted'}`} />
              <div className="flex items-center justify-between gap-4">
                <dt className="text-xs font-semibold uppercase tracking-wider text-ink-400">Quantity</dt>
                <dd>
                  <QtyPicker qty={qty} onChange={setQty} />
                </dd>
              </div>
              <div className="flex items-center justify-between border-t border-cream-200 pt-3">
                <dt className="text-sm font-semibold text-ink-900">Total</dt>
                <dd className="text-base font-bold text-burgundy-900">{formatINR(variantPrice * qty)}</dd>
              </div>
            </div>

            <label className="mt-5 flex cursor-pointer items-start gap-3 rounded-xl border border-cream-300 bg-cream-50 p-3.5">
              <input
                type="checkbox"
                checked={approved}
                onChange={(e) => setApproved(e.target.checked)}
                className="mt-0.5 h-4 w-4 rounded accent-burgundy-700"
              />
              <span className="text-xs leading-relaxed text-ink-700">
                <strong className="text-ink-900">I approve this personalization.</strong> I have checked the spelling,
                photos and placement. The preview is approximate; final colours and materials may vary slightly.
              </span>
            </label>

            <div className="mt-5 flex gap-3">
              <button className="btn-outline btn-md flex-1" onClick={() => setReviewOpen(false)}>
                Keep editing
              </button>
              <button className="btn-primary btn-md flex-1" disabled={!approved} onClick={addToCart}>
                Add to Cart
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function ReviewRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <dt className="text-xs font-semibold uppercase tracking-wider text-ink-400">{label}</dt>
      <dd className="max-w-[60%] text-right text-sm text-ink-900">{value}</dd>
    </div>
  );
}

export function QtyPicker({ qty, onChange }: { qty: number; onChange: (n: number) => void }) {
  return (
    <div className="inline-flex items-center rounded-full border border-cream-300">
      <button
        type="button"
        className="px-3 py-1.5 text-ink-500 hover:text-burgundy-800 disabled:opacity-30"
        onClick={() => onChange(Math.max(1, qty - 1))}
        disabled={qty <= 1}
        aria-label="Decrease quantity"
      >
        −
      </button>
      <span className="min-w-8 text-center text-sm font-semibold" aria-live="polite">
        {qty}
      </span>
      <button
        type="button"
        className="px-3 py-1.5 text-ink-500 hover:text-burgundy-800 disabled:opacity-30"
        onClick={() => onChange(Math.min(10, qty + 1))}
        disabled={qty >= 10}
        aria-label="Increase quantity"
      >
        +
      </button>
    </div>
  );
}

function RangeControl({
  label,
  value,
  min,
  max,
  step,
  onChange,
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  format: (v: number) => string;
}) {
  return (
    <div>
      <div className="mb-1 flex items-center justify-between">
        <label className="text-xs font-semibold uppercase tracking-wider text-ink-500">{label}</label>
        <span className="text-xs text-ink-400">{format(value)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full accent-burgundy-700"
        aria-label={label}
      />
    </div>
  );
}
