'use client';

/**
 * 2D personalization preview.
 *
 * Renders an approximate product mockup with the customer's exact text,
 * photos and crop. The preview communicates approximate placement/appearance —
 * final colors and materials can differ slightly. We never auto-crop: the
 * visible crop IS what gets approved and produced.
 */

import { forwardRef } from 'react';
import type { CropConfig, PersonalisationTemplate, PreviewLayout } from '@/lib/types';

export const CANVAS = 600;

export interface PreviewState {
  template: PersonalisationTemplate;
  fields: Record<string, string>;
  photos: string[]; // object/data URLs
  textColor: string;
  crop: CropConfig;
  productName: string;
}

function coverSize(areaW: number, areaH: number, imgW: number, imgH: number): [number, number] {
  const scale = Math.max(areaW / imgW, areaH / imgH);
  return [imgW * scale, imgH * scale];
}

/**
 * Compute the exact drawn image geometry (used by both rendering and the
 * rasterized approval snapshot).
 */
export function imageGeometry(state: PreviewState) {
  const pa = state.template.printArea;
  const X = pa.x * CANVAS;
  const Y = pa.y * CANVAS;
  const W = pa.w * CANVAS;
  const H = pa.h * CANVAS;
  const cx = X + W / 2;
  const cy = Y + H / 2;
  // Assume a 4:3-ish base when image not loaded yet.
  const [w, h] = coverSize(W, H, 4, 3);
  const s = state.crop.scale;
  const dx = state.crop.x * W * 0.5;
  const dy = state.crop.y * H * 0.5;
  return { X, Y, W, H, cx, cy, w, h, s, dx, dy };
}

export const PreviewCanvas = forwardRef<SVGSVGElement, { state: PreviewState; className?: string }>(
  function PreviewCanvas({ state, className }, ref) {
    const { template } = state;
    const pa = template.printArea;
    const g = imageGeometry(state);
    const clipId = `clip-${template.id}`;
    const photo = state.photos[0];
    const primaryText = state.fields[template.fields[0]?.key ?? 'name'] ?? '';
    const secondaryText = template.fields[1] ? state.fields[template.fields[1].key] ?? '' : '';
    const hasPhoto = template.photos.count > 0 && photo;

    return (
      <svg
        ref={ref}
        viewBox={`0 0 ${CANVAS} ${CANVAS}`}
        role="img"
        aria-label={`Approximate preview of personalized ${state.productName}`}
        className={className}
        style={{ background: '#F3EADB' }}
      >
        <defs>
          <clipPath id={clipId}>
            {pa.shape === 'circle' ? (
              <circle cx={g.X + g.W / 2} cy={g.Y + g.H / 2} r={Math.min(g.W, g.H) / 2} />
            ) : (
              <rect x={g.X} y={g.Y} width={g.W} height={g.H} rx={10} />
            )}
          </clipPath>
          <linearGradient id="wood" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#8B5E3C" />
            <stop offset="1" stopColor="#6B4226" />
          </linearGradient>
          <linearGradient id="glow" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#FFE9B8" stopOpacity="0.95" />
            <stop offset="1" stopColor="#F7D488" stopOpacity="0.75" />
          </linearGradient>
          <linearGradient id="ceramic" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#FFFEF9" />
            <stop offset="1" stopColor="#F1E9DA" />
          </linearGradient>
        </defs>

        <ProductShape layout={template.layout} />

        {/* Printed photo, clipped to the print area */}
        {hasPhoto && (
          <g clipPath={`url(#${clipId})`}>
            <rect x={g.X} y={g.Y} width={g.W} height={g.H} fill="#FFFFFF" />
            <g transform={`translate(${g.cx + g.dx}, ${g.cy + g.dy}) scale(${g.s}) translate(${-g.cx}, ${-g.cy})`}>
              <image
                href={photo}
                x={g.cx - g.w / 2}
                y={g.cy - g.h / 2}
                width={g.w}
                height={g.h}
                preserveAspectRatio="xMidYMid slice"
              />
            </g>
          </g>
        )}

        {/* Engraved / printed text */}
        <TextLayer state={state} geom={g} hasPhoto={Boolean(hasPhoto)} primary={primaryText} secondary={secondaryText} />

        {/* Print area outline so placement intent is explicit */}
        {pa.shape === 'circle' ? (
          <circle
            cx={g.X + g.W / 2}
            cy={g.Y + g.H / 2}
            r={Math.min(g.W, g.H) / 2}
            fill="none"
            stroke="#A03557"
            strokeOpacity="0.35"
            strokeDasharray="4 4"
          />
        ) : (
          <rect x={g.X} y={g.Y} width={g.W} height={g.H} rx={10} fill="none" stroke="#A03557" strokeOpacity="0.35" strokeDasharray="4 4" />
        )}
      </svg>
    );
  },
);

function TextLayer({
  state,
  geom: g,
  hasPhoto,
  primary,
  secondary,
}: {
  state: PreviewState;
  geom: ReturnType<typeof imageGeometry>;
  hasPhoto: boolean;
  primary: string;
  secondary: string;
}) {
  const color = state.textColor;
  if (hasPhoto) {
    // Caption under the print area.
    const y = g.Y + g.H + 34;
    return (
      <g>
        <text x={CANVAS / 2} y={y} textAnchor="middle" fontFamily="Georgia, 'Times New Roman', serif" fontSize={30} fill={color}>
          {primary || 'Your text'}
        </text>
        {secondary && (
          <text x={CANVAS / 2} y={y + 28} textAnchor="middle" fontFamily="Georgia, serif" fontSize={17} fill={color} opacity={0.85}>
            {secondary}
          </text>
        )}
      </g>
    );
  }
  // Text-only product: centered inside the print area.
  return (
    <g>
      <text
        x={g.X + g.W / 2}
        y={g.Y + g.H / 2 + (secondary ? -6 : 10)}
        textAnchor="middle"
        fontFamily="Georgia, 'Times New Roman', serif"
        fontSize={Math.min(34, (g.W * 1.6) / Math.max(6, primary.length || 6))}
        fill={color}
      >
        {primary || 'Your text'}
      </text>
      {secondary && (
        <text x={g.X + g.W / 2} y={g.Y + g.H / 2 + 30} textAnchor="middle" fontFamily="Georgia, serif" fontSize={19} fill={color} opacity={0.85}>
          {secondary}
        </text>
      )}
    </g>
  );
}

function ProductShape({ layout }: { layout: PreviewLayout }) {
  switch (layout) {
    case 'mug':
      return (
        <g>
          {/* handle */}
          <path d="M 448 250 q 70 10 70 75 q 0 65 -70 75" fill="none" stroke="#E4D8C4" strokeWidth={26} />
          <path d="M 448 250 q 70 10 70 75 q 0 65 -70 75" fill="none" stroke="#D9C8AC" strokeWidth={14} />
          {/* body */}
          <rect x={152} y={170} width={300} height={300} rx={26} fill="url(#ceramic)" stroke="#D9C8AC" strokeWidth={3} />
          <ellipse cx={302} cy={172} rx={148} ry={16} fill="#E9DCC6" />
        </g>
      );
    case 'frame':
      return (
        <g>
          <rect x={104} y={64} width={392} height={472} rx={14} fill="url(#wood)" />
          <rect x={118} y={78} width={364} height={444} rx={8} fill="#F7F0E3" />
          <rect x={126} y={86} width={348} height={428} rx={6} fill="#EFE4CF" opacity={0.6} />
        </g>
      );
    case 'cushion':
      return (
        <g>
          <rect x={110} y={110} width={380} height={380} rx={64} fill="#F4ECDD" stroke="#E0D2B8" strokeWidth={4} />
          <rect x={128} y={128} width={344} height={344} rx={52} fill="none" stroke="#E0D2B8" strokeWidth={2} strokeDasharray="2 6" />
        </g>
      );
    case 'keychain':
      return (
        <g>
          <circle cx={300} cy={300} r={150} fill="#C89B6D" />
          <circle cx={300} cy={300} r={150} fill="none" stroke="#A97C4F" strokeWidth={5} />
          <circle cx={300} cy={128} r={26} fill="none" stroke="#B98A2F" strokeWidth={12} />
        </g>
      );
    case 'lamp':
      return (
        <g>
          <rect x={200} y={70} width={200} height={380} rx={26} fill="url(#glow)" stroke="#E3C27E" strokeWidth={3} />
          <rect x={180} y={450} width={240} height={46} rx={14} fill="url(#wood)" />
          <circle cx={300} cy={520} r={6} fill="#8B5E3C" />
        </g>
      );
    case 'notebook':
      return (
        <g>
          <rect x={170} y={80} width={260} height={440} rx={16} fill="#B2703F" />
          <rect x={170} y={80} width={34} height={440} rx={12} fill="#8F5630" />
          <rect x={230} y={120} width={170} height={70} rx={8} fill="#F4ECDD" opacity={0.9} />
        </g>
      );
    case 'hamper':
      return (
        <g>
          <rect x={110} y={200} width={380} height={290} rx={18} fill="#571531" />
          <rect x={110} y={200} width={380} height={60} rx={18} fill="#6E1B3B" />
          <rect x={278} y={200} width={44} height={290} fill="#D4AF5E" opacity={0.9} />
          <rect x={150} y={140} width={300} height={70} rx={12} fill="url(#ceramic)" stroke="#D9C8AC" strokeWidth={3} />
        </g>
      );
  }
}

/** Rasterize the current SVG preview to a small JPEG data URL. */
export async function rasterizePreview(svgEl: SVGSVGElement): Promise<string | undefined> {
  try {
    const xml = new XMLSerializer().serializeToString(svgEl);
    const svgBlob = new Blob([xml], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error('raster failed'));
      img.src = url;
    });
    const canvas = document.createElement('canvas');
    canvas.width = 420;
    canvas.height = 420;
    const ctx = canvas.getContext('2d');
    if (!ctx) return undefined;
    ctx.drawImage(img, 0, 0, 420, 420);
    URL.revokeObjectURL(url);
    return canvas.toDataURL('image/jpeg', 0.82);
  } catch {
    return undefined;
  }
}
