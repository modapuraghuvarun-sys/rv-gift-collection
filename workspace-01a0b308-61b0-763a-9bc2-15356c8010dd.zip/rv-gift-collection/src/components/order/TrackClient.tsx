'use client';

/**
 * Secure tracking entry point.
 * - Signed-in customers see their own orders (server filters by account).
 * - Guests use the secure tracking link (reference + secret token) from their
 *   confirmation. Order number + email alone NEVER opens an order.
 */

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { KeyRound, PackageSearch } from 'lucide-react';
import { useCart } from '@/components/cart/CartProvider';
import { formatDate } from '@/lib/utils';

interface OrderSummary {
  reference: string;
  createdAt: string;
  status: string;
  statusLabel?: string;
  total: number;
}

export function TrackClient() {
  const { guestOrders } = useCart();
  const [me, setMe] = useState<{ authenticated: boolean; name?: string } | null>(null);
  const [orders, setOrders] = useState<OrderSummary[] | null>(null);

  useEffect(() => {
    fetch('/api/auth/me')
      .then((r) => r.json())
      .then((json) => {
        setMe(json);
        if (json.authenticated && json.role === 'customer') {
          fetch('/api/account/orders')
            .then((r) => (r.ok ? r.json() : null))
            .then((j) => j && setOrders(j.orders ?? []))
            .catch(() => setOrders([]));
        }
      })
      .catch(() => setMe({ authenticated: false }));
  }, []);

  return (
    <div className="shell py-10 md:py-16">
      <div className="mx-auto max-w-2xl">
        <div className="text-center">
          <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-burgundy-50 text-burgundy-700">
            <PackageSearch size={24} aria-hidden />
          </span>
          <h1 className="mt-4 font-display text-3xl text-burgundy-900">Track your order</h1>
          <p className="mx-auto mt-2 max-w-md text-sm text-ink-500">
            For your security, orders open only with a secure tracking link or the account that placed them.
          </p>
        </div>

        {me?.authenticated && orders !== null && (
          <section className="card mt-10 p-6" aria-label="Your orders">
            <h2 className="font-display text-lg text-burgundy-900">Your orders</h2>
            {orders.length === 0 ? (
              <p className="mt-3 text-sm text-ink-500">
                No orders yet on this account. <Link href="/collections" className="text-burgundy-700 underline">Start exploring</Link>.
              </p>
            ) : (
              <ul className="mt-4 divide-y divide-cream-200">
                {orders.map((o) => (
                  <li key={o.reference} className="flex items-center justify-between gap-3 py-3">
                    <div>
                      <p className="text-sm font-semibold text-ink-900">{o.reference}</p>
                      <p className="text-xs text-ink-400">{formatDate(o.createdAt)} · {o.status.replace(/_/g, ' ').toLowerCase()}</p>
                    </div>
                    <Link href={`/order/${o.reference}`} className="btn-outline btn-sm">Open</Link>
                  </li>
                ))}
              </ul>
            )}
          </section>
        )}

        <section className="card mt-6 p-6" aria-label="Guest tracking">
          <h2 className="flex items-center gap-2 font-display text-lg text-burgundy-900">
            <KeyRound size={18} aria-hidden /> Ordered as a guest?
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-ink-500">
            Use the <strong>secure tracking link</strong> from your confirmation email or the link shown right after
            checkout. It contains a private token that proves it’s you — we never open orders with just an order number
            and email.
          </p>
          {guestOrders.length > 0 && (
            <ul className="mt-4 space-y-2" aria-label="Recent guest orders on this device">
              {guestOrders.map((g) => (
                <li key={g.reference} className="flex items-center justify-between gap-3 rounded-xl bg-cream-100 px-4 py-3">
                  <div>
                    <p className="text-sm font-semibold text-ink-900">{g.reference}</p>
                    <p className="text-xs text-ink-400">Placed {formatDate(g.at)} on this device</p>
                  </div>
                  <Link href={`/order/${g.reference}?token=${g.token}`} className="btn-primary btn-sm">Track</Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
