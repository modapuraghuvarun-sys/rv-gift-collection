'use client';

import { Check, Clock } from 'lucide-react';
import { MAIN_TIMELINE, STATUS_LABELS } from '@/lib/order-status';
import type { Order, OrderStatus } from '@/lib/types';
import { formatDateTime } from '@/lib/utils';
import { cn } from '@/lib/utils';

export function OrderTimeline({ order }: { order: Order }) {
  const currentIdx = MAIN_TIMELINE.indexOf(order.status);
  const isException = !['PAYMENT_PENDING', ...MAIN_TIMELINE].includes(order.status);
  const reached = (s: OrderStatus) => {
    const i = MAIN_TIMELINE.indexOf(s);
    if (order.status === s) return true;
    if (isException) {
      // Exception after some stage: mark stages that appear in history.
      return order.history.some((h) => h.status === s);
    }
    return i !== -1 && i <= currentIdx;
  };

  return (
    <ol className="relative space-y-0">
      {MAIN_TIMELINE.map((status, i) => {
        const event = order.history.find((h) => h.status === status);
        const done = reached(status);
        const isLast = i === MAIN_TIMELINE.length - 1;
        return (
          <li key={status} className="relative flex gap-4 pb-6 last:pb-0">
            {!isLast && (
              <span
                className={cn('absolute left-[13px] top-7 h-[calc(100%-12px)] w-0.5', done ? 'bg-burgundy-600' : 'bg-cream-300')}
                aria-hidden
              />
            )}
            <span
              className={cn(
                'z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border-2 transition-colors',
                done ? 'border-burgundy-700 bg-burgundy-700 text-cream-50' : 'border-cream-300 bg-white text-ink-300',
              )}
            >
              {done ? <Check size={13} aria-hidden /> : <Clock size={12} aria-hidden />}
            </span>
            <div className="min-w-0">
              <p className={cn('text-sm font-semibold', done ? 'text-ink-900' : 'text-ink-400')}>
                {STATUS_LABELS[status]}
              </p>
              {event && <p className="text-xs text-ink-400">{formatDateTime(event.at)}{event.note ? ` — ${event.note}` : ''}</p>}
            </div>
          </li>
        );
      })}
      {isException && (
        <li className="relative flex gap-4">
          <span className="z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border-2 border-gold-400 bg-gold-200 text-gold-600">
            !
          </span>
          <div>
            <p className="text-sm font-semibold text-ink-900">{STATUS_LABELS[order.status]}</p>
            {order.history.filter((h) => h.status === order.status).map((h, i) => (
              <p key={i} className="text-xs text-ink-400">{formatDateTime(h.at)}{h.note ? ` — ${h.note}` : ''}</p>
            ))}
          </div>
        </li>
      )}
    </ol>
  );
}
