'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import { MapPin, Package, User, X } from 'lucide-react';
import { formatINR } from '@/lib/money';
import { formatDate } from '@/lib/utils';
import type { Address } from '@/lib/types';

interface Profile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  addresses: Address[];
}

interface OrderRow {
  reference: string;
  createdAt: string;
  status: string;
  statusLabel: string;
  total: number;
}

export function AccountClient() {
  const router = useRouter();
  const [auth, setAuth] = useState<'loading' | 'guest' | 'customer'>('loading');
  const [profile, setProfile] = useState<Profile | null>(null);
  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [tab, setTab] = useState<'orders' | 'profile' | 'addresses'>('orders');
  const [addressFormOpen, setAddressFormOpen] = useState(false);
  const [editing, setEditing] = useState<Address | null>(null);

  useEffect(() => {
    fetch('/api/auth/me')
      .then((r) => r.json())
      .then((json) => {
        if (!json.authenticated || json.role !== 'customer') {
          setAuth('guest');
          return;
        }
        setAuth('customer');
        setProfile(json.profile);
        fetch('/api/account/orders').then((r) => r.json()).then((j) => setOrders(j.orders ?? [])).catch(() => undefined);
      })
      .catch(() => setAuth('guest'));
  }, []);

  const refreshAddresses = useCallback(() => {
    fetch('/api/auth/me').then((r) => r.json()).then((json) => {
      if (json.profile) setProfile(json.profile);
    });
  }, []);

  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/');
    router.refresh();
  }

  if (auth === 'loading') {
    return (
      <div className="shell py-16">
        <div className="skeleton h-8 w-64" />
        <div className="skeleton mt-6 h-64" />
      </div>
    );
  }

  if (auth === 'guest') {
    return (
      <div className="shell flex min-h-[60vh] flex-col items-center justify-center py-16 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-full bg-burgundy-50 text-burgundy-700">
          <User size={24} aria-hidden />
        </span>
        <h1 className="mt-4 font-display text-2xl text-burgundy-900">You’re not logged in</h1>
        <p className="mt-2 max-w-sm text-sm text-ink-500">
          Log in to see your orders, saved addresses and faster checkout. You can still order as a guest anytime.
        </p>
        <div className="mt-6 flex gap-3">
          <Link href="/login" className="btn-primary btn-md">Log In</Link>
          <Link href="/signup" className="btn-outline btn-md">Create Account</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="shell py-8 md:py-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="eyebrow">Your account</p>
          <h1 className="mt-1 font-display text-3xl text-burgundy-900">Hi, {profile?.name.split(' ')[0]}</h1>
          <p className="mt-1 text-sm text-ink-500">{profile?.email}</p>
        </div>
        <button onClick={logout} className="btn-ghost btn-sm">Log out</button>
      </div>

      <div className="mt-8 flex gap-2 border-b border-cream-200" role="tablist" aria-label="Account sections">
        {([
          ['orders', 'Order History', Package],
          ['addresses', 'Saved Addresses', MapPin],
          ['profile', 'Profile', User],
        ] as const).map(([id, label, Icon]) => (
          <button
            key={id}
            role="tab"
            aria-selected={tab === id}
            onClick={() => setTab(id)}
            className={`flex items-center gap-2 border-b-2 px-4 py-3 text-sm font-semibold transition-colors ${
              tab === id ? 'border-burgundy-700 text-burgundy-800' : 'border-transparent text-ink-400 hover:text-ink-700'
            }`}
          >
            <Icon size={15} aria-hidden /> {label}
          </button>
        ))}
      </div>

      {tab === 'orders' && (
        <section className="py-6">
          {orders.length === 0 ? (
            <div className="card p-10 text-center">
              <p className="text-sm text-ink-500">No orders yet on this account.</p>
              <Link href="/collections" className="btn-primary btn-md mt-4">Explore Gifts</Link>
            </div>
          ) : (
            <ul className="space-y-3">
              {orders.map((o) => (
                <li key={o.reference} className="card flex flex-wrap items-center justify-between gap-3 p-5">
                  <div>
                    <p className="text-sm font-bold text-ink-900">{o.reference}</p>
                    <p className="mt-0.5 text-xs text-ink-400">
                      {formatDate(o.createdAt)} · {o.statusLabel} · {formatINR(o.total)}
                    </p>
                  </div>
                  <Link href={`/order/${o.reference}`} className="btn-outline btn-sm">View & Track</Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      {tab === 'addresses' && (
        <section className="py-6">
          <div className="grid gap-4 sm:grid-cols-2">
            {(profile?.addresses ?? []).map((a) => (
              <div key={a.id} className="card relative p-5">
                {a.isDefault && (
                  <span className="absolute right-4 top-4 rounded-full bg-burgundy-50 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-burgundy-700">
                    Default
                  </span>
                )}
                <p className="text-sm font-semibold text-ink-900">{a.fullName}</p>
                <p className="mt-1 text-xs leading-relaxed text-ink-500">
                  {a.line1}
                  {a.line2 ? `, ${a.line2}` : ''}
                  <br />
                  {a.city}, {a.state} {a.pincode}
                  <br />
                  {a.phone}
                </p>
                <div className="mt-3 flex gap-3 text-xs font-semibold">
                  <button className="text-burgundy-700 hover:underline" onClick={() => { setEditing(a); setAddressFormOpen(true); }}>Edit</button>
                  <button
                    className="text-ink-400 hover:text-burgundy-700"
                    onClick={async () => {
                      await fetch('/api/account/addresses', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ deleteId: a.id }),
                      });
                      refreshAddresses();
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
            <button
              onClick={() => { setEditing(null); setAddressFormOpen(true); }}
              className="flex min-h-36 items-center justify-center rounded-xl2 border-2 border-dashed border-cream-300 text-sm font-semibold text-ink-400 transition-colors hover:border-burgundy-300 hover:text-burgundy-700"
            >
              + Add new address
            </button>
          </div>
        </section>
      )}

      {tab === 'profile' && profile && (
        <section className="max-w-md py-6">
          <dl className="card space-y-4 p-6 text-sm">
            <div><dt className="label">Name</dt><dd className="font-semibold text-ink-900">{profile.name}</dd></div>
            <div><dt className="label">Email</dt><dd className="font-semibold text-ink-900">{profile.email}</dd></div>
            <div><dt className="label">Phone</dt><dd className="font-semibold text-ink-900">{profile.phone || 'Not added'}</dd></div>
          </dl>
          <p className="mt-3 text-[11px] text-ink-400">
            Demo build: profile editing is limited. Production accounts are managed through Supabase Auth (email, phone, MFA).
          </p>
        </section>
      )}

      {addressFormOpen && profile && (
        <AddressModal
          initial={editing}
          onClose={() => setAddressFormOpen(false)}
          onSaved={() => {
            setAddressFormOpen(false);
            refreshAddresses();
          }}
        />
      )}
    </div>
  );
}

function AddressModal({ initial, onClose, onSaved }: { initial: Address | null; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState<Address>(
    initial ?? { fullName: '', phone: '', line1: '', line2: '', city: '', state: '', pincode: '', isDefault: false },
  );
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');
    const res = await fetch('/api/account/addresses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    const json = await res.json();
    if (!res.ok) {
      setError(json.message ?? 'Could not save address.');
      setBusy(false);
      return;
    }
    onSaved();
  }

  const set = (k: keyof Address) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-900/50 p-4" role="dialog" aria-modal="true" aria-label="Address form">
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-lift">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl text-burgundy-900">{initial ? 'Edit address' : 'Add address'}</h2>
          <button className="rounded-lg p-2 hover:bg-cream-200" aria-label="Close" onClick={onClose}><X size={18} /></button>
        </div>
        <form onSubmit={save} className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label className="label" htmlFor="a-name">Full name</label>
            <input id="a-name" className="input" value={form.fullName} onChange={(e) => set('fullName')(e.target.value)} required />
          </div>
          <div>
            <label className="label" htmlFor="a-phone">Phone</label>
            <input id="a-phone" className="input" inputMode="numeric" value={form.phone} onChange={(e) => set('phone')(e.target.value.replace(/\D/g, '').slice(0, 10))} required />
          </div>
          <div>
            <label className="label" htmlFor="a-pin">PIN code</label>
            <input id="a-pin" className="input" inputMode="numeric" maxLength={6} value={form.pincode} onChange={(e) => set('pincode')(e.target.value.replace(/\D/g, '').slice(0, 6))} required />
          </div>
          <div className="sm:col-span-2">
            <label className="label" htmlFor="a-l1">Address line 1</label>
            <input id="a-l1" className="input" value={form.line1} onChange={(e) => set('line1')(e.target.value)} required />
          </div>
          <div className="sm:col-span-2">
            <label className="label" htmlFor="a-l2">Address line 2 (optional)</label>
            <input id="a-l2" className="input" value={form.line2 ?? ''} onChange={(e) => set('line2')(e.target.value)} />
          </div>
          <div>
            <label className="label" htmlFor="a-city">City</label>
            <input id="a-city" className="input" value={form.city} onChange={(e) => set('city')(e.target.value)} required />
          </div>
          <div>
            <label className="label" htmlFor="a-state">State</label>
            <input id="a-state" className="input" value={form.state} onChange={(e) => set('state')(e.target.value)} required />
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-700 sm:col-span-2">
            <input type="checkbox" className="h-4 w-4 rounded accent-burgundy-700" checked={Boolean(form.isDefault)} onChange={(e) => setForm((f) => ({ ...f, isDefault: e.target.checked }))} />
            Set as default address
          </label>
          {error && <p className="rounded-lg bg-burgundy-50 p-3 text-xs font-medium text-burgundy-700 sm:col-span-2" role="alert">{error}</p>}
          <div className="flex gap-3 sm:col-span-2">
            <button type="button" className="btn-ghost btn-md flex-1" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary btn-md flex-1" disabled={busy}>{busy ? 'Saving…' : 'Save address'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
