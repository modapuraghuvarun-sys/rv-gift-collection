'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, LayoutGrid, PackageSearch, ShoppingBag, User } from 'lucide-react';
import { useCart } from '@/components/cart/CartProvider';
import { cn } from '@/lib/utils';

const ITEMS = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/collections', label: 'Shop', icon: LayoutGrid },
  { href: '/cart', label: 'Cart', icon: ShoppingBag, badge: true },
  { href: '/track', label: 'Track', icon: PackageSearch },
  { href: '/account', label: 'Account', icon: User },
];

export function MobileNav() {
  const pathname = usePathname();
  const { count } = useCart();
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-cream-200 bg-white/95 backdrop-blur md:hidden"
      aria-label="Bottom navigation"
    >
      <div className="grid grid-cols-5">
        {ITEMS.map((item) => {
          const Icon = item.icon;
          const active = item.href === '/' ? pathname === '/' : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'relative flex flex-col items-center gap-0.5 py-2.5 text-[10px] font-medium',
                active ? 'text-burgundy-800' : 'text-ink-400',
              )}
            >
              <span className="relative">
                <Icon size={20} />
                {item.badge && count > 0 && (
                  <span className="absolute -right-2 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-burgundy-700 px-0.5 text-[9px] font-bold text-cream-50">
                    {count}
                  </span>
                )}
              </span>
              {item.label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
