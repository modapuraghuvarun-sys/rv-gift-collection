'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useCallback, useEffect, useState } from 'react';
import {
  Archive, BarChart3, Boxes, FileText, Gift, KanbanSquare, LayoutDashboard,
  Lock, MapPinned, Percent, ScrollText, Settings, ShieldCheck, Ticket, Truck, Users,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const NAV = [
  { href: '/admin', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/admin/catalogue', label: 'Catalogue & Products', icon: Gift },
  { href: '/admin/collections', label: 'Collections', icon: Archive },
  { href: '/admin/templates', label: 'Personalization Templates', icon: FileText },
  { href: '/admin/inventory', label: 'Inventory', icon: Boxes },
  { href: '/admin/orders', label: 'Orders', icon: KanbanSquare },
  { href: '/admin/production', label: 'Production', icon: ShieldCheck },
  { href: '/admin/delivery', label: 'Delivery', icon: MapPinned },
  { href: '/admin/promotions', label: 'Promotions', icon: Percent },
  { href: '/admin/support', label: 'Support & Refunds', icon: Ticket },
  { href: '/admin/reports', label: 'Reports', icon: BarChart3 },
  { href: '/admin/staff', label: 'Staff & Audit', icon: Users },
  { href: '/admin/content', label: 'Content', icon: ScrollText },
  { href: '/admin/settings', label: 'Settings', icon: Settings },
];

export function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [auth, setAuth] = useState<'loading' | 'gate' | 'staff'>('loading');

  useEffect(() => {
    fetch('/api/auth/me')
      .then((r) => r.json())
      .then((json) => setAuth(json.authenticated && json.role === 'staff' ? 'staff' : 'gate'))
      .catch(() => setAuth('gate'));
  }, []);

  const startDemo = useCallback(async () => {
    const res = await fetch('/api/auth/staff', { method: 'POST' });
    if (res.ok) {
      setAuth('staff');
      router.refresh();
    }
  }, [router]);

  if (auth === 'loading') {
    return (
      <div className="flex min-h-[70vh] items-center justify-center">
        <div className="skeleton h-8 w-64" />
      </div>
    );
  }

  if (auth === 'gate') {
    return (
      <div className="shell flex min-h-[70vh] items-center justify-center py-16">
        <div className="card w-full max-w-md p-10 text-center">
          <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-burgundy-50 text-burgundy-700">
            <Lock size={24} aria-hidden />
          </span>
          <h1 className="mt-4 font-display text-2xl text-burgundy-900">Protected staff area</h1>
          <p className="mt-2 text-sm leading-relaxed text-ink-500">
            Admin access requires a staff role verified on the server. Every action is logged to the audit trail.
          </p>
          <div className="mt-6 rounded-xl border border-gold-300 bg-gold-200/25 p-4 text-left">
            <p className="badge-placeholder mb-1">Demo mode</p>
            <p className="text-xs leading-relaxed text-ink-500">
              Production: Supabase Auth sign-in + protected staff roles + enforced MFA. For this preview you can start a
              time-limited demo staff session:
            </p>
          </div>
          <button className="btn-primary btn-lg mt-5 w-full" onClick={startDemo}>
            Start demo staff session
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream-100">
      <div className="flex">
        <aside className="sticky top-0 hidden h-screen w-64 shrink-0 overflow-y-auto bg-burgundy-950 p-4 text-cream-100 lg:block" aria-label="Admin navigation">
          <Link href="/" className="mb-6 flex items-center gap-2.5 px-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-burgundy-700 font-display text-sm font-semibold text-gold-300">RV</span>
            <span>
              <span className="block text-sm font-semibold text-cream-50">RV Admin</span>
              <span className="block text-[10px] uppercase tracking-widest text-gold-400">Staff console</span>
            </span>
          </Link>
          <nav className="space-y-0.5">
            {NAV.map((item) => {
              const active = item.href === '/admin' ? pathname === '/admin' : pathname.startsWith(item.href);
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'flex items-center gap-2.5 rounded-lg px-3 py-2 text-[13px] font-medium transition-colors',
                    active ? 'bg-burgundy-800 text-cream-50' : 'text-cream-100/70 hover:bg-burgundy-900 hover:text-cream-50',
                  )}
                  aria-current={active ? 'page' : undefined}
                >
                  <Icon size={15} aria-hidden /> {item.label}
                </Link>
              );
            })}
          </nav>
        </aside>

        <div className="min-w-0 flex-1">
          {/* Mobile admin nav */}
          <nav className="rv-scroll sticky top-16 z-30 flex gap-1 overflow-x-auto border-b border-cream-200 bg-white p-2 lg:hidden" aria-label="Admin navigation mobile">
            {NAV.map((item) => {
              const active = item.href === '/admin' ? pathname === '/admin' : pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold',
                    active ? 'bg-burgundy-800 text-cream-50' : 'bg-cream-100 text-ink-500',
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="p-4 sm:p-6 lg:p-8">{children}</div>
        </div>
      </div>
    </div>
  );
}

/** Small shared hooks/utilities for admin pages. */
export function useAdminData<T>(url: string, refreshKey = 0): { data: T | null; error: string; reload: () => void } {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState('');
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let alive = true;
    fetch(url)
      .then(async (r) => {
        if (!r.ok) throw new Error('unauthorized');
        return r.json();
      })
      .then((json) => alive && setData(json))
      .catch(() => alive && setError('Could not load data (check staff session).'));
    return () => {
      alive = false;
    };
  }, [url, tick, refreshKey]);

  return { data, error, reload: () => setTick((t) => t + 1) };
}

export function StatCard({ label, value, tone = 'default', hint }: { label: string; value: string | number; tone?: 'default' | 'warn' | 'danger' | 'good'; hint?: string }) {
  return (
    <div className={cn('card p-5', tone === 'danger' && 'border-l-4 border-l-burgundy-600', tone === 'warn' && 'border-l-4 border-l-gold-400', tone === 'good' && 'border-l-4 border-l-emerald-500')}>
      <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-400">{label}</p>
      <p className="mt-1.5 font-display text-2xl text-burgundy-900">{value}</p>
      {hint && <p className="mt-0.5 text-[11px] text-ink-400">{hint}</p>}
    </div>
  );
}

export function AdminTable({ head, children }: { head: string[]; children: React.ReactNode }) {
  return (
    <div className="rv-scroll card overflow-x-auto">
      <table className="w-full min-w-[640px] text-left text-sm">
        <thead>
          <tr className="border-b border-cream-200 bg-cream-50">
            {head.map((h) => (
              <th key={h} className="whitespace-nowrap px-4 py-3 text-[11px] font-bold uppercase tracking-wider text-ink-400">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-cream-100">{children}</tbody>
      </table>
    </div>
  );
}

export function StatusPill({ status }: { status: string }) {
  const tones: Record<string, string> = {
    PAYMENT_PENDING: 'bg-cream-200 text-ink-500',
    CONFIRMED: 'bg-emerald-100 text-emerald-800',
    PERSONALISATION_REVIEW: 'bg-gold-200 text-gold-600',
    IN_PRODUCTION: 'bg-burgundy-100 text-burgundy-800',
    QUALITY_CHECKED: 'bg-burgundy-100 text-burgundy-800',
    PACKED: 'bg-burgundy-100 text-burgundy-800',
    SHIPPED: 'bg-blue-100 text-blue-800',
    DELIVERED: 'bg-emerald-100 text-emerald-800',
    CORRECTION_HOLD: 'bg-gold-200 text-gold-600',
    CANCELLED: 'bg-burgundy-800 text-cream-50',
    DELIVERY_EXCEPTION: 'bg-red-100 text-red-800',
    published: 'bg-emerald-100 text-emerald-800',
    draft: 'bg-cream-200 text-ink-500',
    archived: 'bg-ink-700 text-cream-50',
    open: 'bg-gold-200 text-gold-600',
    in_progress: 'bg-blue-100 text-blue-800',
    resolved: 'bg-emerald-100 text-emerald-800',
    failed: 'bg-red-100 text-red-800',
    done: 'bg-emerald-100 text-emerald-800',
    queued: 'bg-cream-200 text-ink-500',
    leased: 'bg-blue-100 text-blue-800',
  };
  return (
    <span className={cn('inline-block whitespace-nowrap rounded-full px-2.5 py-0.5 text-[11px] font-bold', tones[status] ?? 'bg-cream-200 text-ink-500')}>
      {status.replace(/_/g, ' ')}
    </span>
  );
}

export function TruckIconLink() {
  return <Truck size={14} aria-hidden />;
}
