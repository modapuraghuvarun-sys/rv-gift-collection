'use client';

/**
 * Checkout: guest or account, buyer vs gift recipient (kept strictly
 * separate), delivery option from PIN check, coupon, server quote review,
 * then order creation + hosted payment. Browser totals are never sent —
 * only references; the server recomputes everything.
 */

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AlertTriangle, Gift, Lock, Truck, User } from 'lucide-react';
import { useCart } from '@/components/cart/CartProvider';
import type { DeliveryOptionId, Quote } from '@/lib/types';
import { formatINR } from '@/lib/money';
import { formatDateRange, isValidEmail, isValidIndianPincode, isValidPhone } from '@/lib/utils';

interface ProfileLite {
  name: string;
  email: string;
  phone?: string;
}

export function CheckoutClient() {
  const { lines, clear, addGuestOrder } = useCart();
  const router = useRouter();

  const [profile, setProfile] = useState<ProfileLite | null>(null);
  const [quote, setQuote] = useState<Quote | null>(null);
  const [quoteMsg, setQuoteMsg] = useState('');
  const [deliveryOption, setDeliveryOption] = useState<DeliveryOptionId>('standard');
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState('');
  const seq = useRef(0);

  // Buyer
  const [buyerName, setBuyerName] = useState('');
  const [buyerEmail, setBuyerEmail] = useState('');
  const [buyerPhone, setBuyerPhone] = useState('');
  // Recipient
  const [recipientIsBuyer, setRecipientIsBuyer] = useState(true);
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [giftMessage, setGiftMessage] = useState('');
  // Address
  const [fullName, setFullName] = useState('');
  const [line1, setLine1] = useState('');
  const [line2, setLine2] = useState('');
  const [city, setCity] = useState('');
  const [stateName, setStateName] = useState('');
  const [pincode, setPincode] = useState('');
  const [coupon, setCoupon] = useState('');

  useEffect(() => {
    fetch('/api/auth/me')
      .then((r) => r.json())
      .then((json) => {
        if (json.authenticated && json.profile) {
          setProfile(json.profile);
          setBuyerName(json.profile.name ?? '');
          setBuyerEmail(json.profile.email ?? '');
          setBuyerPhone(json.profile.phone ?? '');
        }
      })
      .catch(() => undefined);
  }, []);

  const refreshQuote = useCallback(
    (opts?: { silent?: boolean }) => {
      if (!lines.length) return;
      const mySeq = ++seq.current;
      const needsApproval = lines.some((l) => l.personalisation && !l.personalisation.approvedAt);
      if (needsApproval) {
        setQuoteMsg('Personalization approval is missing for one or more items. Go back to the cart to re-approve.');
        setQuote(null);
        return;
      }
      fetch('/api/checkout/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lines,
          couponCode: coupon || undefined,
          deliveryOption,
          pincode: isValidIndianPincode(pincode) ? pincode : undefined,
        }),
      })
        .then(async (res) => {
          const json = await res.json();
          if (mySeq !== seq.current) return;
          if (!res.ok) {
            setQuote(null);
            setQuoteMsg(json.message ?? 'Please review your cart.');
          } else {
            setQuote(json);
            setQuoteMsg('');
          }
        })
        .catch(() => {
          if (mySeq === seq.current) setQuoteMsg('Could not load pricing. Please retry.');
        });
    },
    [lines, coupon, deliveryOption, pincode],
  );

  useEffect(() => {
    const t = window.setTimeout(() => refreshQuote(), 300);
    return () => window.clearTimeout(t);
  }, [refreshQuote]);

  const expressAvailable = useMemo(() => {
    if (!isValidIndianPincode(pincode)) return false;
    // Derived from quote server-side: if express was chosen but server fell
    // back to standard, we still show standard. Availability is re-checked at
    // quote time; this is a UI hint only.
    return true;
  }, [pincode]);

  const addressComplete =
    fullName.trim().length >= 2 &&
    line1.trim().length >= 4 &&
    city.trim().length >= 2 &&
    stateName.trim().length >= 2 &&
    isValidIndianPincode(pincode);

  const buyerComplete = buyerName.trim().length >= 2 && isValidEmail(buyerEmail) && isValidPhone(buyerPhone);
  const recipientComplete = recipientIsBuyer || (recipientName.trim().length >= 2 && (!recipientPhone || isValidPhone(recipientPhone)));

  async function placeOrder() {
    setError('');
    if (!quote) {
      setError('Please wait for the price summary to load.');
      return;
    }
    if (!buyerComplete || !recipientComplete || !addressComplete) {
      setError('Please complete the highlighted sections before paying.');
      return;
    }
    setPlacing(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          quoteId: quote.id,
          lines,
          couponCode: coupon || undefined,
          deliveryOption,
          buyer: { name: buyerName, email: buyerEmail, phone: buyerPhone },
          recipient: recipientIsBuyer
            ? { name: fullName }
            : { name: recipientName, phone: recipientPhone || undefined, giftMessage: giftMessage || undefined },
          address: { fullName, phone: recipientPhone || buyerPhone, line1, line2, city, state: stateName, pincode },
        }),
      });
      const json = await res.json();
      if (!res.ok) {
        if (json.error === 'QUOTE_EXPIRED' || json.error === 'PRICE_CHANGED') {
          setQuoteMsg(json.message);
          refreshQuote();
          setError(json.message);
        } else {
          setError(json.message ?? 'Could not place the order. Please try again.');
        }
        setPlacing(false);
        return;
      }

      if (json.trackingToken) {
        addGuestOrder({ reference: json.reference, token: json.trackingToken, at: new Date().toISOString() });
      }

      const payRes = await fetch('/api/payments/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentId: json.paymentId }),
      });
      const payJson = await payRes.json();
      if (!payRes.ok) {
        setError('Your order was created but payment could not start. Visit the Track page with your order reference.');
        setPlacing(false);
        return;
      }
      clear();
      sessionStorage.setItem('rv_pending_payment', JSON.stringify({ paymentId: json.paymentId, token: json.trackingToken, reference: json.reference }));
      router.push(payJson.checkoutUrl);
    } catch {
      setError('Something went wrong. Please try again.');
      setPlacing(false);
    }
  }

  if (!lines.length) {
    return (
      <div className="shell flex flex-col items-center py-24 text-center">
        <h1 className="font-display text-2xl text-burgundy-900">Nothing to check out yet</h1>
        <p className="mt-2 text-sm text-ink-500">Your cart is empty.</p>
        <Link href="/collections" className="btn-primary btn-lg mt-6">Explore Gifts</Link>
      </div>
    );
  }

  return (
    <div className="shell py-8 md:py-12">
      <h1 className="section-title">Checkout</h1>
      <p className="mt-2 flex items-center gap-1.5 text-xs text-ink-400">
        <Lock size={12} aria-hidden /> Payments happen on a secure hosted page. We never see or store card details.
      </p>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_380px]">
        <div className="space-y-6">
          {/* Buyer */}
          <section className="card p-6" aria-labelledby="buyer-h">
            <h2 id="buyer-h" className="flex items-center gap-2 font-display text-lg text-burgundy-900">
              <User size={18} aria-hidden /> Buyer details
            </h2>
            <p className="mt-1 text-xs text-ink-400">The person paying. Order updates go to this email.</p>
            {profile && (
              <p className="mt-3 rounded-lg bg-emerald-50 px-3 py-2 text-xs font-medium text-emerald-800">
                Logged in as {profile.email}
              </p>
            )}
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <Field label="Full name" required value={buyerName} onChange={setBuyerName} autoComplete="name" invalid={buyerName.length > 0 && buyerName.trim().length < 2} />
              <Field label="Email" required type="email" value={buyerEmail} onChange={setBuyerEmail} autoComplete="email" invalid={buyerEmail.length > 0 && !isValidEmail(buyerEmail)} />
              <Field label="Phone" required inputMode="numeric" value={buyerPhone} onChange={(v) => setBuyerPhone(v.replace(/\D/g, '').slice(0, 10))} autoComplete="tel" invalid={buyerPhone.length > 0 && !isValidPhone(buyerPhone)} />
            </div>
          </section>

          {/* Recipient */}
          <section className="card p-6" aria-labelledby="recipient-h">
            <h2 id="recipient-h" className="flex items-center gap-2 font-display text-lg text-burgundy-900">
              <Gift size={18} aria-hidden /> Gift recipient
            </h2>
            <p className="mt-1 text-xs text-ink-400">
              The person receiving the gift. Recipients are never added to marketing lists — only order-related updates.
            </p>
            <label className="mt-4 flex cursor-pointer items-center gap-2 text-sm text-ink-700">
              <input type="checkbox" checked={recipientIsBuyer} onChange={(e) => setRecipientIsBuyer(e.target.checked)} className="h-4 w-4 rounded accent-burgundy-700" />
              I’m the recipient
            </label>
            {!recipientIsBuyer && (
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <Field label="Recipient name" required value={recipientName} onChange={setRecipientName} />
                <Field label="Recipient phone (optional)" inputMode="numeric" value={recipientPhone} onChange={(v) => setRecipientPhone(v.replace(/\D/g, '').slice(0, 10))} />
                <div className="sm:col-span-2">
                  <label className="label" htmlFor="gift-msg">Gift message (optional, hand-written card)</label>
                  <textarea id="gift-msg" className="input min-h-20" maxLength={300} value={giftMessage} onChange={(e) => setGiftMessage(e.target.value)} placeholder="A short note we’ll write on a card…" />
                </div>
              </div>
            )}
          </section>

          {/* Delivery */}
          <section className="card p-6" aria-labelledby="delivery-h">
            <h2 id="delivery-h" className="flex items-center gap-2 font-display text-lg text-burgundy-900">
              <Truck size={18} aria-hidden /> Delivery address
            </h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <Field label="Full name at address" required value={fullName} onChange={setFullName} autoComplete="name" />
              <Field label="Phone" inputMode="numeric" value={recipientPhone || buyerPhone} onChange={() => undefined} disabled hint="Uses recipient/buyer phone" />
              <div className="sm:col-span-2">
                <Field label="Address line 1" required value={line1} onChange={setLine1} autoComplete="address-line1" />
              </div>
              <div className="sm:col-span-2">
                <Field label="Address line 2 (optional)" value={line2} onChange={setLine2} autoComplete="address-line2" />
              </div>
              <Field label="City" required value={city} onChange={setCity} autoComplete="address-level2" />
              <Field label="State" required value={stateName} onChange={setStateName} autoComplete="address-level1" />
              <Field
                label="PIN code"
                required
                inputMode="numeric"
                value={pincode}
                onChange={(v) => setPincode(v.replace(/\D/g, '').slice(0, 6))}
                autoComplete="postal-code"
                invalid={pincode.length === 6 && !isValidIndianPincode(pincode)}
                hint={isValidIndianPincode(pincode) && quote?.deliveryWindow ? `Estimated delivery: ${quote.deliveryWindow}` : undefined}
              />
            </div>

            {/* Delivery option */}
            <fieldset className="mt-5">
              <legend className="label">Delivery option</legend>
              <div className="grid gap-3 sm:grid-cols-2">
                <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 transition-colors ${deliveryOption === 'standard' ? 'border-burgundy-700 bg-burgundy-50' : 'border-cream-300'}`}>
                  <input type="radio" name="delivery" checked={deliveryOption === 'standard'} onChange={() => setDeliveryOption('standard')} className="mt-1 accent-burgundy-700" />
                  <span>
                    <span className="block text-sm font-semibold text-ink-900">Standard</span>
                    <span className="block text-xs text-ink-500">
                      {quote ? (quote.deliveryFee === 0 ? 'Free' : formatINR(quote.deliveryFee)) : 'Calculated from PIN'}
                      {quote?.deliveryWindow && deliveryOption === 'standard' ? ` · ${quote.deliveryWindow}` : ''}
                    </span>
                  </span>
                </label>
                <label className={`flex items-start gap-3 rounded-xl border p-4 transition-colors ${!expressAvailable ? 'cursor-not-allowed opacity-50' : 'cursor-pointer'} ${deliveryOption === 'express' ? 'border-burgundy-700 bg-burgundy-50' : 'border-cream-300'}`}>
                  <input type="radio" name="delivery" disabled={!expressAvailable} checked={deliveryOption === 'express'} onChange={() => setDeliveryOption('express')} className="mt-1 accent-burgundy-700" />
                  <span>
                    <span className="block text-sm font-semibold text-ink-900">Express</span>
                    <span className="block text-xs text-ink-500">
                      {expressAvailable ? 'Where available for your PIN' : 'Enter PIN code to check'}
                    </span>
                  </span>
                </label>
              </div>
            </fieldset>
          </section>
        </div>

        {/* Summary */}
        <aside className="h-fit lg:sticky lg:top-24" aria-label="Payment summary">
          <div className="card p-6">
            <h2 className="font-display text-lg text-burgundy-900">Order review</h2>
            {quoteMsg && (
              <p className="mt-3 flex items-start gap-2 rounded-lg bg-gold-200/40 p-3 text-xs font-medium text-ink-700" role="alert">
                <AlertTriangle size={14} className="mt-0.5 shrink-0 text-gold-600" aria-hidden /> {quoteMsg}
              </p>
            )}
            {quote ? (
              <>
                <ul className="mt-4 space-y-2.5">
                  {quote.lines.map((l) => (
                    <li key={l.lineId} className="flex justify-between gap-3 text-sm">
                      <span className="text-ink-700">
                        {l.name} <span className="text-ink-400">· {l.variantName} × {l.qty}</span>
                      </span>
                      <span className="font-semibold text-ink-900">{formatINR(l.lineTotal)}</span>
                    </li>
                  ))}
                </ul>
                <form
                  className="mt-4 flex gap-2"
                  onSubmit={(e) => {
                    e.preventDefault();
                    refreshQuote();
                  }}
                >
                  <input className="input uppercase" placeholder="Coupon code" aria-label="Coupon code" value={coupon} onChange={(e) => setCoupon(e.target.value.toUpperCase())} />
                  <button className="btn-outline btn-sm shrink-0" type="submit">Apply</button>
                </form>
                <dl className="mt-4 space-y-2 border-t border-cream-200 pt-4 text-sm">
                  <SummaryRow label="Subtotal" value={formatINR(quote.subtotal)} />
                  {quote.discount > 0 && <SummaryRow label={`Discount${quote.couponCode ? ` (${quote.couponCode})` : ''}`} value={`− ${formatINR(quote.discount)}`} />}
                  <SummaryRow label="Tax (included)" value={formatINR(quote.taxIncluded)} muted />
                  <SummaryRow label="Delivery" value={quote.deliveryFee === 0 ? 'Free' : formatINR(quote.deliveryFee)} />
                  <div className="flex items-baseline justify-between border-t border-cream-200 pt-3">
                    <dt className="text-base font-bold">Total</dt>
                    <dd className="text-xl font-bold text-burgundy-900">{formatINR(quote.total)}</dd>
                  </div>
                </dl>
                <p className="mt-2 text-[11px] leading-relaxed text-ink-400">
                  This quote expires in 10 minutes. If prices change, you’ll be asked to review the new total before paying.
                </p>
              </>
            ) : (
              <div className="skeleton mt-4 h-32" aria-label="Loading summary" />
            )}

            {error && (
              <p className="mt-3 rounded-lg bg-burgundy-50 p-3 text-xs font-medium text-burgundy-700" role="alert">
                {error}
              </p>
            )}
            <button className="btn-primary btn-lg mt-5 w-full" onClick={placeOrder} disabled={placing || !quote}>
              {placing ? 'Preparing secure payment…' : quote ? `Pay ${formatINR(quote.total)}` : 'Loading…'}
            </button>
            <p className="mt-2 text-center text-[11px] text-ink-400">
              You’ll be redirected to a hosted payment page. Your order confirms only after payment is verified.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  required,
  type = 'text',
  inputMode,
  autoComplete,
  invalid,
  hint,
  disabled,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
  type?: string;
  inputMode?: 'numeric' | 'text';
  autoComplete?: string;
  invalid?: boolean;
  hint?: string;
  disabled?: boolean;
}) {
  const id = label.replace(/\W/g, '-').toLowerCase();
  return (
    <div>
      <label className="label" htmlFor={id}>
        {label} {required && <span className="text-burgundy-600">*</span>}
      </label>
      <input
        id={id}
        type={type}
        inputMode={inputMode}
        autoComplete={autoComplete}
        className={`input ${invalid ? 'border-burgundy-500 ring-2 ring-burgundy-100' : ''} ${disabled ? 'bg-cream-100 text-ink-400' : ''}`}
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
        aria-invalid={invalid || undefined}
      />
      {invalid && <p className="mt-1 text-[11px] font-medium text-burgundy-600">Please check this field.</p>}
      {hint && !invalid && <p className="mt-1 text-[11px] text-emerald-700">{hint}</p>}
    </div>
  );
}

function SummaryRow({ label, value, muted }: { label: string; value: string; muted?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <dt className={`text-ink-500 ${muted ? 'text-xs text-ink-400' : ''}`}>{label}</dt>
      <dd className="font-semibold text-ink-900">{value}</dd>
    </div>
  );
}
