import { Reveal } from '@/components/Reveal';

export interface PolicySection {
  heading: string;
  body: string[];
}

/**
 * Shared layout for policy pages. Policy copy ships as owner-reviewable
 * drafts (PRD §39 — no invented legal details); each page carries a visible
 * draft banner until the owner finalizes it in Admin → Content.
 */
export function PolicyLayout({ title, updated, intro, sections }: { title: string; updated: string; intro: string; sections: PolicySection[] }) {
  return (
    <div className="shell py-10 md:py-16">
      <div className="mx-auto max-w-3xl">
        <p className="eyebrow">RV Gift Collection</p>
        <h1 className="mt-2 font-display text-3xl text-burgundy-900 md:text-4xl">{title}</h1>
        <p className="mt-2 text-xs text-ink-400">Last updated: {updated}</p>
        <Reveal>
          <div className="mt-5 rounded-xl border border-gold-300 bg-gold-200/25 p-4">
            <p className="badge-placeholder mb-1">Draft for owner review</p>
            <p className="text-xs text-ink-500">
              This policy text is a starting template. Legal specifics (registered entity, jurisdiction, contact
              details) will be finalized by the store owner before publication.
            </p>
          </div>
        </Reveal>
        <p className="mt-6 text-sm leading-relaxed text-ink-700">{intro}</p>
        <div className="mt-8 space-y-8">
          {sections.map((s) => (
            <section key={s.heading}>
              <h2 className="font-display text-xl text-burgundy-900">{s.heading}</h2>
              {s.body.map((p, i) => (
                <p key={i} className="mt-2.5 text-sm leading-relaxed text-ink-500">
                  {p}
                </p>
              ))}
            </section>
          ))}
        </div>
      </div>
    </div>
  );
}
