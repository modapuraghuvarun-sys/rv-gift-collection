'use client';

import { useState } from 'react';
import { CheckCircle2 } from 'lucide-react';

const TYPES = [
  { id: 'order-issue', label: 'Order-related issue' },
  { id: 'personalization-correction', label: 'Personalization correction' },
  { id: 'delivery-issue', label: 'Delivery issue' },
  { id: 'damaged-product', label: 'Damaged product' },
  { id: 'incorrect-product', label: 'Incorrect product received' },
  { id: 'other', label: 'Something else' },
];

export function ContactClient({ orderReference }: { orderReference?: string }) {
  const [type, setType] = useState('order-issue');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [orderRef, setOrderRef] = useState(orderReference ?? '');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [caseRef, setCaseRef] = useState('');

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/support', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, name, email, orderReference: orderRef || undefined, message }),
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.message ?? 'Could not submit your request.');
        setBusy(false);
        return;
      }
      setCaseRef(json.caseReference);
    } catch {
      setError('Could not reach support. Please try again.');
      setBusy(false);
    }
  }

  if (caseRef) {
    return (
      <div className="shell flex min-h-[60vh] items-center justify-center py-16">
        <div className="card w-full max-w-md p-10 text-center">
          <CheckCircle2 className="mx-auto text-emerald-600" size={44} aria-hidden />
          <h1 className="mt-4 font-display text-2xl text-burgundy-900">Request received</h1>
          <p className="mt-2 text-sm text-ink-500">
            Your case reference is <strong className="text-burgundy-800">{caseRef}</strong>. Keep it handy — our team
            will reply to your email.
          </p>
          <p className="mt-4 rounded-lg bg-cream-100 p-3 text-xs text-ink-500">
            A confirmation email has been queued to you. Transactional updates are separate from marketing — we never
            mix the two.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="shell py-10 md:py-16">
      <div className="mx-auto max-w-2xl">
        <p className="eyebrow text-center">Support</p>
        <h1 className="mt-2 text-center font-display text-3xl text-burgundy-900 md:text-4xl">How can we help?</h1>
        <p className="mx-auto mt-2 max-w-md text-center text-sm text-ink-500">
          Every request gets a case reference so nothing gets lost.
        </p>

        <form onSubmit={submit} className="card mt-8 space-y-5 p-6 sm:p-8">
          <div>
            <label className="label" htmlFor="c-type">What is this about?</label>
            <select id="c-type" className="input" value={type} onChange={(e) => setType(e.target.value)}>
              {TYPES.map((t) => (
                <option key={t.id} value={t.id}>{t.label}</option>
              ))}
            </select>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="c-name">Your name</label>
              <input id="c-name" className="input" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} />
            </div>
            <div>
              <label className="label" htmlFor="c-email">Email</label>
              <input id="c-email" type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} required />
            </div>
          </div>
          <div>
            <label className="label" htmlFor="c-order">Order reference (if you have one)</label>
            <input id="c-order" className="input uppercase" placeholder="RV-XXXX-XXXX" value={orderRef} onChange={(e) => setOrderRef(e.target.value.toUpperCase())} />
          </div>
          <div>
            <label className="label" htmlFor="c-msg">Tell us more</label>
            <textarea id="c-msg" className="input min-h-32" required minLength={10} maxLength={2000} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="What happened, and how can we make it right?" />
          </div>
          {error && <p className="rounded-lg bg-burgundy-50 p-3 text-xs font-medium text-burgundy-700" role="alert">{error}</p>}
          <button type="submit" className="btn-primary btn-lg w-full" disabled={busy}>
            {busy ? 'Submitting…' : 'Submit request'}
          </button>
        </form>

        {/* Contact details placeholder — PRD §39: never invent contact details */}
        <div className="mt-6 rounded-xl2 border border-gold-300 bg-gold-200/25 p-5 text-center">
          <p className="badge-placeholder mb-1">Owner content placeholder</p>
          <p className="text-xs text-ink-500">
            Phone, WhatsApp and email support details will appear here once added by the store owner in Admin → Content.
          </p>
        </div>
      </div>
    </div>
  );
}
