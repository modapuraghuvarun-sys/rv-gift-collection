'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { Menu, Search, ShoppingBag, User, X } from 'lucide-react';
import { useCart } from '@/components/cart/CartProvider';
import { cn } from '@/lib/utils';

const NAV = [
  { href: '/collections', label: 'All Gifts' },
  { href: '/occasion/birthday', label: 'Birthday' },
  { href: '/occasion/anniversary', label: 'Anniversary' },
  { href: '/occasion/wedding', label: 'Wedding' },
  { href: '/occasion/festive', label: 'Festive' },
  { href: '/collections?personalised=true', label: 'Personalized' },
];

export function Header() {
  const { count } = useCart();
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState('');
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    if (searchOpen) searchRef.current?.focus();
  }, [searchOpen]);

  return (
    <header className="sticky top-0 z-40 border-b border-cream-200 bg-cream-50/90 backdrop-blur">
      <div className="shell flex h-16 items-center justify-between gap-4 md:h-20">
        <div className="flex items-center gap-2 md:hidden">
          <button
            className="rounded-lg p-2 hover:bg-cream-200"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        <Link href="/" className="group flex items-center gap-2.5" aria-label="RV Gift Collection — home">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-burgundy-800 font-display text-sm font-semibold text-gold-300 transition-transform group-hover:scale-105 md:h-10 md:w-10 md:text-base">
            RV
          </span>
          <span className="leading-tight">
            <span className="block font-display text-base font-semibold tracking-wide text-burgundy-900 md:text-lg">
              RV Gift Collection
            </span>
            <span className="hidden text-[10px] uppercase tracking-[0.28em] text-gold-600 sm:block">
              Make every gift personal
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          {NAV.map((item) => (
            <Link
              key={item.href + item.label}
              href={item.href}
              className={cn(
                'rounded-full px-3.5 py-2 text-sm text-ink-700 transition-colors hover:bg-cream-200 hover:text-burgundy-900',
                pathname === item.href && 'bg-cream-200 text-burgundy-900',
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1">
          <button
            className="rounded-lg p-2 hover:bg-cream-200"
            aria-label="Search gifts"
            onClick={() => setSearchOpen((v) => !v)}
          >
            <Search size={20} />
          </button>
          <Link href="/account" className="hidden rounded-lg p-2 hover:bg-cream-200 md:block" aria-label="Your account">
            <User size={20} />
          </Link>
          <Link href="/cart" className="relative rounded-lg p-2 hover:bg-cream-200" aria-label={`Cart, ${count} items`}>
            <ShoppingBag size={20} />
            {count > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-burgundy-700 px-1 text-[10px] font-bold text-cream-50">
                {count}
              </span>
            )}
          </Link>
        </div>
      </div>

      {searchOpen && (
        <form
          className="border-t border-cream-200 bg-white"
          role="search"
          onSubmit={(e) => {
            e.preventDefault();
            if (q.trim()) {
              window.location.href = `/search?q=${encodeURIComponent(q.trim())}`;
            }
          }}
        >
          <div className="shell flex items-center gap-3 py-3">
            <Search size={18} className="text-ink-400" aria-hidden />
            <input
              ref={searchRef}
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search mugs, frames, lamps, hampers…"
              className="w-full bg-transparent text-sm outline-none placeholder:text-ink-300"
              aria-label="Search products"
            />
            <button type="submit" className="btn-primary btn-sm">
              Search
            </button>
          </div>
        </form>
      )}

      {open && (
        <nav className="border-t border-cream-200 bg-white lg:hidden" aria-label="Mobile">
          <div className="shell flex flex-col py-3">
            {NAV.map((item) => (
              <Link
                key={item.href + item.label}
                href={item.href}
                className="rounded-lg px-3 py-3 text-sm font-medium text-ink-900 hover:bg-cream-100"
              >
                {item.label}
              </Link>
            ))}
            <Link href="/account" className="rounded-lg px-3 py-3 text-sm font-medium text-ink-900 hover:bg-cream-100 md:hidden">
              Account
            </Link>
          </div>
        </nav>
      )}
    </header>
  );
}
