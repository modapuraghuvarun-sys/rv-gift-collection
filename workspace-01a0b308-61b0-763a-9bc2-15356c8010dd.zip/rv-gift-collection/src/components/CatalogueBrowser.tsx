'use client';

/**
 * Client-side catalogue browser: search, category/occasion/recipient/collection
 * filters, price band, personalization filter, sort, pagination and
 * loading/empty/error states. Data comes from GET /api/products
 * (published products only).
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { AlertTriangle, SearchX, SlidersHorizontal, X } from 'lucide-react';
import { ProductCard, ProductCardSkeleton, type ProductCardData } from '@/components/ProductCard';
import { formatINR } from '@/lib/money';

interface Facets {
  categories: { slug: string; name: string }[];
  occasions: { slug: string; name: string }[];
  recipients: { slug: string; name: string }[];
}

interface ApiResponse {
  products: ProductCardData[];
  total: number;
  page: number;
  totalPages: number;
  facets: Facets;
}

const PRICE_BANDS = [
  { id: '', label: 'Any price', min: 0, max: 0 },
  { id: 'under-500', label: 'Under ₹500', min: 0, max: 500 },
  { id: '500-1000', label: '₹500 – ₹1,000', min: 500, max: 1000 },
  { id: '1000-2000', label: '₹1,000 – ₹2,000', min: 1000, max: 2000 },
  { id: 'above-2000', label: 'Above ₹2,000', min: 2000, max: 0 },
];

export function CatalogueBrowser({ title, subtitle }: { title?: string; subtitle?: string }) {
  const router = useRouter();
  const params = useSearchParams();
  const [data, setData] = useState<ApiResponse | null>(null);
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [mobileFilters, setMobileFilters] = useState(false);
  const requestSeq = useRef(0);

  const q = params.get('q') ?? '';
  const category = params.get('category') ?? '';
  const occasion = params.get('occasion') ?? '';
  const recipient = params.get('recipient') ?? '';
  const collection = params.get('collection') ?? '';
  const personalised = params.get('personalised') === 'true';
  const price = params.get('price') ?? '';
  const sort = params.get('sort') ?? 'featured';
  const page = Number(params.get('page') ?? 1) || 1;

  const setParam = useCallback(
    (key: string, value: string) => {
      const next = new URLSearchParams(params.toString());
      if (value) next.set(key, value);
      else next.delete(key);
      if (key !== 'page') next.delete('page');
      router.replace(`?${next.toString()}`, { scroll: false });
    },
    [params, router],
  );

  useEffect(() => {
    const seq = ++requestSeq.current;
    setState('loading');
    const band = PRICE_BANDS.find((b) => b.id === price);
    const usp = new URLSearchParams();
    if (q) usp.set('q', q);
    if (category) usp.set('category', category);
    if (occasion) usp.set('occasion', occasion);
    if (recipient) usp.set('recipient', recipient);
    if (collection) usp.set('collection', collection);
    if (personalised) usp.set('personalisable', 'true');
    if (band) {
      if (band.min) usp.set('min', String(band.min));
      if (band.max) usp.set('max', String(band.max));
    }
    usp.set('sort', sort);
    usp.set('page', String(page));
    usp.set('pageSize', '12');

    fetch(`/api/products?${usp.toString()}`)
      .then(async (res) => {
        if (!res.ok) throw new Error('Failed to load products');
        return (await res.json()) as ApiResponse;
      })
      .then((json) => {
        if (seq === requestSeq.current) {
          setData(json);
          setState('ready');
        }
      })
      .catch(() => {
        if (seq === requestSeq.current) setState('error');
      });
  }, [q, category, occasion, recipient, collection, personalised, price, sort, page]);

  const activeFilters = [
    category && { key: 'category', label: `Category: ${data?.facets.categories.find((c) => c.slug === category)?.name ?? category}` },
    occasion && { key: 'occasion', label: `Occasion: ${data?.facets.occasions.find((o) => o.slug === occasion)?.name ?? occasion}` },
    recipient && { key: 'recipient', label: `For: ${data?.facets.recipients.find((r) => r.slug === recipient)?.name ?? recipient}` },
    collection && { key: 'collection', label: `Collection: ${collection}` },
    personalised && { key: 'personalised', label: 'Personalizable' },
    price && { key: 'price', label: PRICE_BANDS.find((b) => b.id === price)?.label ?? '' },
  ].filter(Boolean) as { key: string; label: string }[];

  const Filters = (
    <div className="space-y-6">
      <fieldset>
        <legend className="label">Category</legend>
        <div className="space-y-1.5">
          <FilterLink active={!category} onClick={() => setParam('category', '')} label="All categories" />
          {(data?.facets.categories ?? []).map((c) => (
            <FilterLink key={c.slug} active={category === c.slug} onClick={() => setParam('category', c.slug)} label={c.name} />
          ))}
        </div>
      </fieldset>
      <fieldset>
        <legend className="label">Occasion</legend>
        <div className="space-y-1.5">
          <FilterLink active={!occasion} onClick={() => setParam('occasion', '')} label="All occasions" />
          {(data?.facets.occasions ?? []).map((o) => (
            <FilterLink key={o.slug} active={occasion === o.slug} onClick={() => setParam('occasion', o.slug)} label={o.name} />
          ))}
        </div>
      </fieldset>
      <fieldset>
        <legend className="label">Recipient</legend>
        <div className="space-y-1.5">
          <FilterLink active={!recipient} onClick={() => setParam('recipient', '')} label="Everyone" />
          {(data?.facets.recipients ?? []).map((r) => (
            <FilterLink key={r.slug} active={recipient === r.slug} onClick={() => setParam('recipient', r.slug)} label={r.name} />
          ))}
        </div>
      </fieldset>
      <fieldset>
        <legend className="label">Price</legend>
        <div className="space-y-1.5">
          {PRICE_BANDS.map((b) => (
            <FilterLink key={b.id} active={price === b.id} onClick={() => setParam('price', b.id)} label={b.label} />
          ))}
        </div>
      </fieldset>
      <fieldset>
        <legend className="label">Personalization</legend>
        <label className="flex cursor-pointer items-center gap-2 text-sm text-ink-700">
          <input
            type="checkbox"
            checked={personalised}
            onChange={(e) => setParam('personalised', e.target.checked ? 'true' : '')}
            className="h-4 w-4 rounded accent-burgundy-700"
          />
          Personalizable only
        </label>
      </fieldset>
    </div>
  );

  return (
    <div className="shell py-8 md:py-12">
      {(title || subtitle) && (
        <div className="mb-8">
          {title && <h1 className="section-title">{title}</h1>}
          {subtitle && <p className="mt-2 max-w-2xl text-sm text-ink-500">{subtitle}</p>}
        </div>
      )}

      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <button className="btn-outline btn-sm lg:hidden" onClick={() => setMobileFilters(true)}>
            <SlidersHorizontal size={14} aria-hidden /> Filters
          </button>
          {activeFilters.map((f) => (
            <button key={f.key} className="chip" onClick={() => setParam(f.key, '')} aria-label={`Remove filter ${f.label}`}>
              {f.label} <X size={12} aria-hidden />
            </button>
          ))}
        </div>
        <div className="flex items-center gap-3">
          {data && <p className="hidden text-xs text-ink-400 sm:block">{data.total} gifts</p>}
          <label className="sr-only" htmlFor="sort">Sort products</label>
          <select id="sort" className="input w-auto py-2 text-xs" value={sort} onChange={(e) => setParam('sort', e.target.value)}>
            <option value="featured">Sort: Featured</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
          </select>
        </div>
      </div>

      <div className="grid gap-8 lg:grid-cols-[220px_1fr]">
        <aside className="hidden lg:block" aria-label="Filters">
          {Filters}
        </aside>

        <div>
          {state === 'loading' && (
            <div className="grid grid-cols-2 gap-4 md:grid-cols-3" aria-busy="true" aria-label="Loading products">
              {Array.from({ length: 6 }).map((_, i) => (
                <ProductCardSkeleton key={i} />
              ))}
            </div>
          )}

          {state === 'error' && (
            <div className="card flex flex-col items-center gap-3 px-6 py-16 text-center" role="alert">
              <AlertTriangle className="text-burgundy-400" size={32} aria-hidden />
              <p className="font-semibold text-ink-900">We couldn’t load the catalogue</p>
              <p className="max-w-sm text-sm text-ink-500">Something went wrong on our side. Please try again in a moment.</p>
              <button className="btn-primary btn-md mt-2" onClick={() => window.location.reload()}>
                Retry
              </button>
            </div>
          )}

          {state === 'ready' && data && data.products.length === 0 && (
            <div className="card flex flex-col items-center gap-3 px-6 py-16 text-center">
              <SearchX className="text-ink-300" size={36} aria-hidden />
              <p className="font-semibold text-ink-900">No gifts match those filters</p>
              <p className="max-w-sm text-sm text-ink-500">
                Try removing a filter or searching for something simpler — like “mug”, “frame” or “lamp”.
              </p>
              <button
                className="btn-outline btn-md mt-2"
                onClick={() => {
                  for (const f of activeFilters) setParam(f.key, '');
                }}
              >
                Clear all filters
              </button>
            </div>
          )}

          {state === 'ready' && data && data.products.length > 0 && (
            <>
              <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
                {data.products.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
              {data.totalPages > 1 && (
                <nav className="mt-10 flex items-center justify-center gap-2" aria-label="Pagination">
                  <button
                    className="btn-outline btn-sm"
                    disabled={page <= 1}
                    onClick={() => setParam('page', String(page - 1))}
                  >
                    Previous
                  </button>
                  <span className="px-3 text-xs text-ink-500">
                    Page {data.page} of {data.totalPages}
                  </span>
                  <button
                    className="btn-outline btn-sm"
                    disabled={page >= data.totalPages}
                    onClick={() => setParam('page', String(page + 1))}
                  >
                    Next
                  </button>
                </nav>
              )}
            </>
          )}
        </div>
      </div>

      {mobileFilters && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="Filters">
          <div className="absolute inset-0 bg-ink-900/40" onClick={() => setMobileFilters(false)} />
          <div className="absolute inset-y-0 left-0 w-80 max-w-[85vw] overflow-y-auto bg-white p-6 shadow-lift">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="font-display text-lg text-burgundy-900">Filters</h2>
              <button className="rounded-lg p-2 hover:bg-cream-200" aria-label="Close filters" onClick={() => setMobileFilters(false)}>
                <X size={18} />
              </button>
            </div>
            {Filters}
            <button className="btn-primary btn-md mt-8 w-full" onClick={() => setMobileFilters(false)}>
              Show results
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function FilterLink({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`block w-full rounded-lg px-2.5 py-1.5 text-left text-sm transition-colors ${
        active ? 'bg-burgundy-50 font-semibold text-burgundy-800' : 'text-ink-500 hover:bg-cream-100'
      }`}
      aria-pressed={active}
    >
      {label}
    </button>
  );
}
