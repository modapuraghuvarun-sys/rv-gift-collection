import Link from 'next/link';

const COLS: { title: string; links: { href: string; label: string }[] }[] = [
  {
    title: 'Shop',
    links: [
      { href: '/collections', label: 'All Gifts' },
      { href: '/collections?category=mugs', label: 'Mugs' },
      { href: '/collections?category=frames', label: 'Frames' },
      { href: '/collections?category=cushions', label: 'Cushions' },
      { href: '/collections?category=lamps', label: 'Lamps' },
      { href: '/collections?category=gift-hampers', label: 'Gift Hampers' },
    ],
  },
  {
    title: 'Occasions',
    links: [
      { href: '/occasion/birthday', label: 'Birthday' },
      { href: '/occasion/anniversary', label: 'Anniversary' },
      { href: '/occasion/wedding', label: 'Wedding' },
      { href: '/occasion/festive', label: 'Festive' },
      { href: '/occasion/housewarming', label: 'Housewarming' },
    ],
  },
  {
    title: 'Customer Support',
    links: [
      { href: '/track', label: 'Track Your Order' },
      { href: '/faq', label: 'FAQ' },
      { href: '/contact', label: 'Contact Us' },
      { href: '/policies/shipping', label: 'Shipping Policy' },
      { href: '/policies/returns', label: 'Returns & Cancellation' },
    ],
  },
  {
    title: 'Company',
    links: [
      { href: '/about', label: 'About Us' },
      { href: '/policies/privacy', label: 'Privacy Policy' },
      { href: '/policies/terms', label: 'Terms & Conditions' },
      { href: '/admin', label: 'Staff Dashboard' },
    ],
  },
];

export function Footer() {
  return (
    <footer className="mt-20 bg-burgundy-950 text-cream-100">
      <div className="shell grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-6">
        <div className="sm:col-span-2">
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-burgundy-700 font-display text-base font-semibold text-gold-300">
              RV
            </span>
            <div>
              <p className="font-display text-lg font-semibold text-cream-50">RV Gift Collection</p>
              <p className="text-[10px] uppercase tracking-[0.28em] text-gold-400">Make every gift personal</p>
            </div>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-cream-100/70">
            Personalized gifts made for birthdays, anniversaries, weddings and every special moment —
            designed, personalized and packed with care in India.
          </p>
          {/* Social links render only when configured in Admin → Settings (none configured yet). */}
        </div>
        {COLS.map((col) => (
          <nav key={col.title} aria-label={col.title}>
            <h3 className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-400">{col.title}</h3>
            <ul className="mt-4 space-y-2.5">
              {col.links.map((l) => (
                <li key={l.href + l.label}>
                  <Link href={l.href} className="text-sm text-cream-100/80 transition-colors hover:text-gold-300">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>
        ))}
      </div>
      <div className="border-t border-burgundy-800/60">
        <div className="shell flex flex-col items-center justify-between gap-2 py-5 text-xs text-cream-100/50 sm:flex-row">
          <p>© {new Date().getFullYear()} RV Gift Collection. All rights reserved.</p>
          <p>Prices include GST · Payments secured by hosted checkout</p>
        </div>
      </div>
    </footer>
  );
}
