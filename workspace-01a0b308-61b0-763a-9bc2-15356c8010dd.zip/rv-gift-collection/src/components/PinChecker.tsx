'use client';

import { useState } from 'react';
import { CheckCircle2, MapPin, XCircle } from 'lucide-react';
import type { DeliveryCheckResult } from '@/lib/types';
import { formatINR } from '@/lib/money';
import { formatDateRange } from '@/lib/utils';

/**
 * Delivery availability checker. The window shown is a computed ESTIMATE from
 * production lead time, business days, cut-off and transit — never a promise
 * like "arrives tomorrow".
 */
export function PinChecker({ productId, compact }: { productId: string; compact?: boolean }) {
  const [pin, setPin] = useState('');
  const [result, setResult] = useState<DeliveryCheckResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function check(e?: React.FormEvent) {
    e?.preventDefault();
    setError('');
    setResult(null);
    if (!/^[1-9][0-9]{5}$/.test(pin)) {
      setError('Please enter a valid 6-digit PIN code.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/delivery/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pincode: pin, productId }),
      });
      setResult(await res.json());
    } catch {
      setError('Could not check delivery right now. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={compact ? '' : 'rounded-xl2 border border-cream-300 bg-cream-100/60 p-4'}>
      <form onSubmit={check} className="flex gap-2">
        <div className="relative flex-1">
          <MapPin size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-400" aria-hidden />
          <input
            value={pin}
            onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 6))}
            inputMode="numeric"
            autoComplete="postal-code"
            placeholder="Enter delivery PIN code"
            className="input pl-9"
            aria-label="Delivery PIN code"
          />
        </div>
        <button type="submit" className="btn-outline btn-md shrink-0" disabled={loading}>
          {loading ? 'Checking…' : 'Check'}
        </button>
      </form>
      {error && (
        <p className="mt-2 text-xs font-medium text-burgundy-600" role="alert">
          {error}
        </p>
      )}
      <div aria-live="polite">
        {result && result.serviceable && (
          <div className="mt-3 flex items-start gap-2.5 rounded-xl bg-white p-3.5 shadow-soft">
            <CheckCircle2 className="mt-0.5 shrink-0 text-emerald-600" size={18} aria-hidden />
            <div className="text-xs leading-relaxed text-ink-700">
              <p className="font-semibold text-ink-900">Delivery available to {pin}</p>
              <p className="mt-0.5">
                Estimated delivery: <strong>{formatDateRange(result.windowStart, result.windowEnd)}</strong>
                {result.expressAvailable && result.expressWindowStart && (
                  <>
                    {' '}
                    · Express: <strong>{formatDateRange(result.expressWindowStart, result.expressWindowEnd)}</strong>
                  </>
                )}
              </p>
              <p className="mt-0.5 text-ink-400">
                Includes {result.productionDays} day{result.productionDays > 1 ? 's' : ''} personalization time · Standard
                delivery {formatINR(result.standardFee)} (free above {formatINR(99900)})
                {result.expressAvailable && result.expressFee !== undefined && <> · Express {formatINR(result.expressFee)}</>}
              </p>
            </div>
          </div>
        )}
        {result && !result.serviceable && (
          <div className="mt-3 flex items-start gap-2.5 rounded-xl bg-white p-3.5 shadow-soft" role="alert">
            <XCircle className="mt-0.5 shrink-0 text-burgundy-500" size={18} aria-hidden />
            <p className="text-xs leading-relaxed text-ink-700">{result.reason}</p>
          </div>
        )}
      </div>
    </div>
  );
}
