-- ═══════════════════════════════════════════════════════════════════════════
-- RV Gift Collection — Supabase PostgreSQL schema (0001)
--
-- Conventions:
--   • UUID primary keys for all internal identifiers
--   • Money stored as BIGINT integer PAISE
--   • Separate non-sequential public order references
--   • Purchase-time snapshots so historical orders never depend on live data
-- ═══════════════════════════════════════════════════════════════════════════

create extension if not exists pgcrypto;

-- ── updated_at helper ────────────────────────────────────────────────────────
create or replace function set_updated_at() returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ── profiles (1:1 with auth.users; NO passwords here — Supabase Auth only) ─
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null,
  phone text,
  marketing_consent boolean not null default false, -- separate from transactional email
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger profiles_touch before update on profiles for each row execute function set_updated_at();

-- ── staff roles (protected; MFA enforced at the auth layer) ─────────────────
create table staff_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','catalogue','production','delivery','support')),
  granted_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique (user_id, role)
);

create or replace function is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from staff_roles sr where sr.user_id = auth.uid());
$$;

create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from staff_roles sr where sr.user_id = auth.uid() and sr.role = 'admin');
$$;

-- ── addresses ────────────────────────────────────────────────────────────────
create table addresses (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  full_name text not null,
  phone text not null,
  line1 text not null,
  line2 text,
  city text not null,
  state text not null,
  pincode char(6) not null check (pincode ~ '^[1-9][0-9]{5}$'),
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger addresses_touch before update on addresses for each row execute function set_updated_at();

-- ── collections ──────────────────────────────────────────────────────────────
create table collections (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  featured boolean not null default false,
  created_at timestamptz not null default now()
);

create table product_collections (
  product_id uuid not null,
  collection_id uuid not null references collections(id) on delete cascade,
  primary key (product_id, collection_id)
);

-- ── products / variants / images ─────────────────────────────────────────────
create table products (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  short_description text not null default '',
  description text not null default '',
  category text not null,
  material text not null default '',
  dimensions text not null default '',
  care text not null default '',
  lead_time_days int not null default 1 check (lead_time_days >= 0),
  status text not null default 'draft' check (status in ('draft','published','archived')),
  featured boolean not null default false,
  occasions text[] not null default '{}',
  recipients text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger products_touch before update on products for each row execute function set_updated_at();
create index products_status_idx on products(status);
-- archived products remain referenced by historical order snapshots, never deleted.

create table product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  sku text not null unique,
  name text not null,
  attributes jsonb not null default '{}',
  price int8 not null check (price >= 0),          -- integer paise, GST inclusive
  tax_rate numeric(5,2) not null default 18,
  available boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger variants_touch before update on product_variants for each row execute function set_updated_at();
alter table product_collections add constraint pc_product_fk foreign key (product_id) references products(id) on delete cascade;

create table product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  storage_path text not null,                      -- object path inside product-images bucket
  alt text not null default '',
  position int not null default 0,
  created_at timestamptz not null default now()
);

-- ── personalisation templates (versioned) ────────────────────────────────────
create table personalisation_templates (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  version int not null default 1,
  layout text not null,
  fields jsonb not null default '[]',              -- [{key,label,type,required,maxLength}]
  photos jsonb not null default '{"count":0}',     -- {count,minPx,maxPx}
  print_area jsonb not null,                       -- {x,y,w,h,shape}
  text_colors text[] not null default '{}',
  config jsonb not null default '{}',
  created_at timestamptz not null default now(),
  unique (product_id, version)
);

create table personalisation_assets (
  id uuid primary key default gen_random_uuid(),     -- opaque id = storage path; never PII
  upload_session uuid not null,
  order_id uuid,                                     -- linked after purchase
  product_id uuid references products(id),
  width int not null,
  height int not null,
  bytes int8 not null,
  content_type text not null check (content_type in ('image/jpeg','image/png')),
  status text not null default 'stored' check (status in ('stored','processed','rejected','purged')),
  created_at timestamptz not null default now()
);

-- ── inventory & expiring reservations ───────────────────────────────────────
create table inventory (
  sku text primary key references product_variants(sku),
  on_hand int not null default 0 check (on_hand >= 0),
  updated_at timestamptz not null default now()
);

create table inventory_reservations (
  id uuid primary key default gen_random_uuid(),
  order_id uuid,
  status text not null default 'held' check (status in ('held','allocated','released','expired')),
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

create table reservation_items (
  reservation_id uuid not null references inventory_reservations(id) on delete cascade,
  sku text not null references inventory(sku),
  qty int not null check (qty > 0),
  primary key (reservation_id, sku)
);

-- Atomic stock reservation: prevents two customers buying the final unit.
create or replace function reserve_stock(p_reservation uuid, p_sku text, p_qty int)
returns void language plpgsql as $$
declare updated_rows int;
begin
  update inventory
     set on_hand = on_hand                    -- reservation tracked separately
   where sku = p_sku;
  insert into reservation_items (reservation_id, sku, qty) values (p_reservation, p_sku, p_qty);
  -- Guard: total held + allocated for this SKU must not exceed on_hand.
  select count(*) into updated_rows
    from inventory i
   where i.sku = p_sku
     and i.on_hand - coalesce((
        select sum(ri.qty) from reservation_items ri
        join inventory_reservations r on r.id = ri.reservation_id
        where ri.sku = p_sku and r.status = 'held'
     ), 0) >= 0;
  if updated_rows = 0 then
    raise exception 'OUT_OF_STOCK';
  end if;
end $$;

-- Expiry sweeper (schedule via pg_cron: select expire_reservations() every minute)
create or replace function expire_reservations() returns int
language plpgsql as $$
declare n int;
begin
  with due as (
    update inventory_reservations
       set status = 'expired'
     where status = 'held' and expires_at < now()
     returning id
  )
  select count(*) into n from due;
  return n;
end $$;

-- ── carts ────────────────────────────────────────────────────────────────────
create table carts (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references profiles(id),
  session_key text,                                 -- guest carts
  coupon_code text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table cart_items (
  id uuid primary key default gen_random_uuid(),
  cart_id uuid not null references carts(id) on delete cascade,
  product_id uuid not null references products(id),
  variant_id uuid not null references product_variants(id),
  qty int not null check (qty between 1 and 10),
  personalisation jsonb,                            -- approved design (fields, asset ids, crop, template version)
  created_at timestamptz not null default now()
);

-- ── orders (purchase-time snapshots) ─────────────────────────────────────────
create or replace function generate_order_reference() returns text
language plpgsql volatile as $$
declare alphabet text := '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
        out text := '';
        i int;
begin
  for i in 1..8 loop
    out := out || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
    if i = 4 then out := out || '-'; end if;
  end loop;
  return 'RV-' || out;
end $$;

create table orders (
  id uuid primary key default gen_random_uuid(),
  reference text not null unique default generate_order_reference(), -- non-sequential public ref
  tracking_token text not null default encode(gen_random_bytes(16), 'hex'),
  status text not null default 'PAYMENT_PENDING',
  profile_id uuid references profiles(id),          -- null for guests
  buyer jsonb not null,                             -- snapshot {name,email,phone}
  recipient jsonb not null,                         -- snapshot {name,phone?,giftMessage?}
  address jsonb not null,                           -- snapshot at purchase time
  subtotal int8 not null check (subtotal >= 0),
  discount int8 not null default 0,
  coupon_code text,
  tax_included int8 not null default 0,
  delivery_fee int8 not null default 0,
  delivery_option text not null default 'standard',
  delivery_window text,
  total int8 not null check (total >= 0),
  is_guest boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create trigger orders_touch before update on orders for each row execute function set_updated_at();
create index orders_profile_idx on orders(profile_id);
create index orders_status_idx on orders(status);

create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid references products(id),          -- soft reference; product may archive
  name text not null,                               -- snapshot
  sku text not null,                                -- snapshot
  variant_name text not null,                       -- snapshot
  options jsonb not null default '{}',              -- snapshot
  qty int not null,
  unit_price int8 not null,                         -- snapshot paise
  tax_rate numeric(5,2) not null,
  tax_included int8 not null,
  line_total int8 not null,
  image_path text,
  approved_design jsonb                             -- snapshot: fields, asset ids, crop, template version
);

create table order_status_history (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  status text not null,
  note text,
  actor text not null default 'system',
  at timestamptz not null default now()
);
create index osh_order_idx on order_status_history(order_id, at);

-- ── payments (webhook idempotency) ──────────────────────────────────────────
create table payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id),
  provider text not null default 'razorpay',
  provider_order_id text not null unique,
  amount int8 not null check (amount >= 0),
  currency text not null default 'INR',
  status text not null default 'CREATED' check (status in ('CREATED','CAPTURED','FAILED','ABANDONED')),
  provider_payment_id text,
  created_at timestamptz not null default now(),
  captured_at timestamptz
);

create table payment_events (
  id uuid primary key default gen_random_uuid(),
  provider_event_id text not null unique,           -- idempotency: duplicate webhooks are no-ops
  payment_id uuid references payments(id),
  payload jsonb not null,
  processed_at timestamptz not null default now()
);

create table refunds (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id),
  amount int8 not null check (amount > 0),
  reason text not null,
  provider_refund_id text,
  status text not null default 'initiated' check (status in ('initiated','processed','failed')),
  initiated_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

-- ── delivery rules ───────────────────────────────────────────────────────────
create table delivery_rules (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('zone','unsupported_pin','calendar','capacity')),
  name text,
  pin_prefixes text[] not null default '{}',
  transit_min int,
  transit_max int,
  fee int8,
  express_fee int8,
  express_transit_min int,
  express_transit_max int,
  cutoff_hour int,
  capacity_per_day int,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

create table shipments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references orders(id),
  courier text,
  awb text,
  shipped_at timestamptz,
  delivered_at timestamptz,
  tracking_events jsonb not null default '[]'
);

-- ── coupons ──────────────────────────────────────────────────────────────────
create table coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  description text not null default '',
  kind text not null check (kind in ('flat','percent')),
  value int8 not null check (value > 0),            -- flat: paise; percent: 1..90
  max_discount int8,
  min_subtotal int8 not null default 0,
  starts_at timestamptz not null default now(),
  expires_at timestamptz not null,
  usage_limit int not null default 1000,
  per_customer_limit int not null default 1,
  redeemed int not null default 0,
  active boolean not null default true
);

create table coupon_redemptions (
  id uuid primary key default gen_random_uuid(),
  coupon_id uuid not null references coupons(id) on delete cascade,
  order_id uuid not null references orders(id),
  email text not null,
  created_at timestamptz not null default now()
);

-- ── support ──────────────────────────────────────────────────────────────────
create or replace function generate_case_reference() returns text
language plpgsql volatile as $$
declare alphabet text := '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
        out text := '';
        i int;
begin
  for i in 1..6 loop
    out := out || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
  end loop;
  return 'RVC-' || out;
end $$;

create table support_tickets (
  id uuid primary key default gen_random_uuid(),
  reference text not null unique default generate_case_reference(),
  profile_id uuid references profiles(id),
  type text not null,
  order_id uuid references orders(id),
  name text not null,
  email text not null,
  message text not null,
  status text not null default 'open' check (status in ('open','in_progress','resolved')),
  created_at timestamptz not null default now()
);

-- ── audit / outbox / jobs ────────────────────────────────────────────────────
create table audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor uuid references auth.users(id),
  actor_label text not null default 'system',
  action text not null,
  detail text not null default '',
  at timestamptz not null default now()
);

create table outbox_events (
  id uuid primary key default gen_random_uuid(),
  aggregate text not null,                          -- e.g. order:<id>
  event_type text not null,                         -- email.send, courier.sync…
  payload jsonb not null,
  published_at timestamptz                          -- null = pending
);

create table job_attempts (
  id uuid primary key default gen_random_uuid(),
  job_type text not null,
  idempotency_key text unique,                      -- retries never double-apply
  state text not null default 'queued' check (state in ('queued','leased','done','failed')),
  attempts int not null default 0,
  max_attempts int not null default 4,
  next_run_at timestamptz not null default now(),
  lease_until timestamptz,
  last_error text,
  payload jsonb not null default '{}',
  created_at timestamptz not null default now()
);
create index job_attempts_due_idx on job_attempts(state, next_run_at);

-- Worker lease pattern (production background worker):
--   update job_attempts
--      set state='leased', lease_until=now()+interval '30 seconds', attempts=attempts+1
--    where id = (
--      select id from job_attempts
--       where state in ('queued') and next_run_at <= now()
--       order by next_run_at
--       limit 1
--       for update skip locked
--    ) returning *;
