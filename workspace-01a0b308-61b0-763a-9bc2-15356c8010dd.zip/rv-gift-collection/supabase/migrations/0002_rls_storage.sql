-- ═══════════════════════════════════════════════════════════════════════════
-- RV Gift Collection — Row Level Security + Storage (0002)
--
-- Principles:
--   • RLS ENABLED on every Data API table — no exceptions
--   • Customers: strict ownership checks (own profile/addresses/carts/orders)
--   • Staff: role-based access via staff_roles (is_staff()/is_admin())
--   • Order access for guests goes through server-issued signed tokens,
--     never through open RLS (guest orders are read via the service role
--     after the server validates the tracking token)
--   • Customer photos: PRIVATE bucket, no public access, signed URLs only
-- ═══════════════════════════════════════════════════════════════════════════

-- ── Enable RLS everywhere ────────────────────────────────────────────────────
alter table profiles enable row level security;
alter table staff_roles enable row level security;
alter table addresses enable row level security;
alter table collections enable row level security;
alter table product_collections enable row level security;
alter table products enable row level security;
alter table product_variants enable row level security;
alter table product_images enable row level security;
alter table personalisation_templates enable row level security;
alter table personalisation_assets enable row level security;
alter table inventory enable row level security;
alter table inventory_reservations enable row level security;
alter table reservation_items enable row level security;
alter table carts enable row level security;
alter table cart_items enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table order_status_history enable row level security;
alter table payments enable row level security;
alter table payment_events enable row level security;
alter table refunds enable row level security;
alter table delivery_rules enable row level security;
alter table shipments enable row level security;
alter table coupons enable row level security;
alter table coupon_redemptions enable row level security;
alter table support_tickets enable row level security;
alter table audit_logs enable row level security;
alter table outbox_events enable row level security;
alter table job_attempts enable row level security;

-- ── profiles: self read/update; staff read ──────────────────────────────────
create policy "profiles self select" on profiles for select using (auth.uid() = id);
create policy "profiles self update" on profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "profiles staff select" on profiles for select using (is_staff());

-- ── staff_roles: admins only (protecting role escalation) ──────────────────
create policy "staff roles admin read" on staff_roles for select using (is_admin());
create policy "staff roles admin write" on staff_roles for all using (is_admin()) with check (is_admin());

-- ── addresses: owner CRUD ────────────────────────────────────────────────────
create policy "addresses owner all" on addresses for all
  using (profile_id = auth.uid()) with check (profile_id = auth.uid());

-- ── public catalogue: published products readable by everyone (anon too) ───
create policy "collections public read" on collections for select using (true);
create policy "products public read published" on products for select using (status = 'published');
create policy "products staff all" on products for all using (is_staff()) with check (is_staff());
create policy "variants public read" on product_variants for select using (true);
create policy "variants staff write" on product_variants for all using (is_staff()) with check (is_staff());
create policy "images public read" on product_images for select using (true);
create policy "images staff write" on product_images for all using (is_staff()) with check (is_staff());
create policy "product collections public read" on product_collections for select using (true);
create policy "product collections staff write" on product_collections for all using (is_staff()) with check (is_staff());
create policy "templates public read" on personalisation_templates for select using (true);
create policy "templates staff write" on personalisation_templates for all using (is_staff()) with check (is_staff());

-- ── customer personalisation assets: staff only (private!) ─────────────────
create policy "assets staff read" on personalisation_assets for select using (is_staff());
-- inserts/writes happen via service-role from upload endpoints only.

-- ── inventory: public read of availability counts is intentionally NOT
--    exposed; stock is surfaced via server-computed product endpoints.
create policy "inventory staff all" on inventory for all using (is_staff()) with check (is_staff());
create policy "reservations staff read" on inventory_reservations for select using (is_staff());
create policy "reservation items staff read" on reservation_items for select using (is_staff());

-- ── carts: owner only ────────────────────────────────────────────────────────
create policy "carts owner all" on carts for all
  using (profile_id = auth.uid()) with check (profile_id = auth.uid());
create policy "cart items owner all" on cart_items for all
  using (exists (select 1 from carts c where c.id = cart_id and c.profile_id = auth.uid()))
  with check (exists (select 1 from carts c where c.id = cart_id and c.profile_id = auth.uid()));

-- ── orders: owner (account orders). Guest orders stay hidden from anon —
--    the tracking endpoint validates the token server-side (service role).
create policy "orders owner select" on orders for select
  using (profile_id = auth.uid() or is_staff());
create policy "orders staff update" on orders for update using (is_staff()) with check (is_staff());

create policy "order items owner select" on order_items for select
  using (exists (
    select 1 from orders o where o.id = order_id and (o.profile_id = auth.uid() or is_staff())
  ));
create policy "order history owner select" on order_status_history for select
  using (exists (
    select 1 from orders o where o.id = order_id and (o.profile_id = auth.uid() or is_staff())
  ));

-- ── payments: owner read (their order), staff full ──────────────────────────
create policy "payments owner select" on payments for select
  using (exists (select 1 from orders o where o.id = order_id and o.profile_id = auth.uid()) or is_staff());
create policy "payment events staff only" on payment_events for select using (is_staff());
create policy "refunds staff only" on refunds for all using (is_staff()) with check (is_staff());

-- ── delivery rules: public read of zones (used by PIN checker UI), staff write
create policy "delivery rules public read" on delivery_rules for select using (active = true);
create policy "delivery rules staff write" on delivery_rules for all using (is_staff()) with check (is_staff());
create policy "shipments owner select" on shipments for select
  using (exists (select 1 from orders o where o.id = order_id and o.profile_id = auth.uid()) or is_staff());
create policy "shipments staff write" on shipments for all using (is_staff()) with check (is_staff());

-- ── coupons: validation happens server-side; public read of nothing.
create policy "coupons staff only" on coupons for all using (is_staff()) with check (is_staff());
create policy "redemptions staff only" on coupon_redemptions for all using (is_staff()) with check (is_staff());

-- ── support tickets: creator + staff ────────────────────────────────────────
create policy "tickets owner select" on support_tickets for select
  using (profile_id = auth.uid() or is_staff());
create policy "tickets staff update" on support_tickets for update using (is_staff()) with check (is_staff());

-- ── audit / outbox / jobs: staff & service only ────────────────────────────
create policy "audit staff read" on audit_logs for select using (is_staff());
create policy "outbox staff read" on outbox_events for select using (is_staff());
create policy "jobs staff read" on job_attempts for select using (is_staff());

-- ═══════════════════════════════════════════════════════════════════════════
-- STORAGE BUCKETS
-- ═══════════════════════════════════════════════════════════════════════════
-- 1. product-images    → public read (catalogue photography)
-- 2. website-assets    → public read (hero/lifestyle imagery)
-- 3. customer-uploads  → PRIVATE (customer photos; signed URLs only)
-- 4. production-files  → PRIVATE (print-ready files for production staff)
-- Object paths use opaque UUIDs — never customer names/addresses/emails.

insert into storage.buckets (id, name, public) values
  ('product-images', 'product-images', true),
  ('website-assets', 'website-assets', true),
  ('customer-uploads', 'customer-uploads', false),
  ('production-files', 'production-files', false)
on conflict (id) do nothing;

-- Public buckets: anyone can read; only staff upload/manage.
create policy "product images public read" on storage.objects for select
  using (bucket_id in ('product-images','website-assets'));
create policy "public buckets staff write" on storage.objects for insert
  with check (bucket_id in ('product-images','website-assets') and is_staff());
create policy "public buckets staff update" on storage.objects for update
  using (bucket_id in ('product-images','website-assets') and is_staff());
create policy "public buckets staff delete" on storage.objects for delete
  using (bucket_id in ('product-images','website-assets') and is_staff());

-- Private buckets: NO direct browser policies. Access is granted exclusively
-- through short-lived signed URLs minted by the server (service role) for:
--   • production staff viewing approved artwork (least privilege)
--   • support staff investigating damage claims
-- This guarantees customer images are never publicly accessible.

-- ── Scheduled maintenance (pg_cron) ─────────────────────────────────────────
-- select cron.schedule('expire-reservations', '* * * * *', $$select expire_reservations()$$);
