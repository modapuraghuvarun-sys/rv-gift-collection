import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        burgundy: {
          50: '#FBF3F5',
          100: '#F5E3E8',
          200: '#EAC3CD',
          300: '#D994A6',
          400: '#C05E7A',
          500: '#A03557',
          600: '#8A2549',
          700: '#6E1B3B',
          800: '#571531',
          900: '#431026',
          950: '#2A0816',
        },
        cream: {
          50: '#FDFBF7',
          100: '#FAF6EF',
          200: '#F3EADB',
          300: '#EADCC4',
          400: '#DCC8A4',
        },
        gold: {
          200: '#F0DFB6',
          300: '#E6C987',
          400: '#D4AF5E',
          500: '#C29A3B',
          600: '#A87F2A',
        },
        ink: {
          300: '#AB9D93',
          400: '#8A7B70',
          500: '#6B5D53',
          700: '#3E332C',
          900: '#241C18',
        },
      },
      fontFamily: {
        display: ['var(--font-display)', 'Georgia', 'serif'],
        sans: ['var(--font-sans)', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        soft: '0 2px 16px rgba(42, 8, 22, 0.07)',
        card: '0 4px 24px rgba(42, 8, 22, 0.08)',
        lift: '0 12px 32px rgba(42, 8, 22, 0.14)',
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(18px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-400px 0' },
          '100%': { backgroundPosition: '400px 0' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.7s cubic-bezier(0.22, 1, 0.36, 1) both',
        'fade-in': 'fade-in 0.6s ease both',
        'fade-up-slow': 'fade-up 1s cubic-bezier(0.22, 1, 0.36, 1) both',
        shimmer: 'shimmer 1.4s linear infinite',
      },
    },
  },
  plugins: [],
};

export default config;
